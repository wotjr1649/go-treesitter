import difflib
import json
import subprocess
from pathlib import Path
from receipt import ROOT, OUT, ENV, run, save, sha

runtime = ROOT / 'internal/runtime'
manifest = ROOT / 'internal/provenance/runtime.json'
old_manifest = json.loads(manifest.read_text(encoding='utf-8'))
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-reviewed-candidate/overlay.json').read_text(encoding='utf-8'))
changed = {}
patch = ''
for target, backing in overlay['Replace'].items():
    path = Path(target)
    if path.name == 'parser_result_csharp.go':
        continue  # KR-0004 remains a separate verified work unit.
    relative = path.relative_to(runtime).as_posix()
    original = path.read_bytes()
    assert sha(original) == old_manifest['files'][relative]['sha256']
    content = Path(backing).read_bytes()
    changed[relative] = {'before': sha(original), 'after': sha(content)}
    patch += ''.join(difflib.unified_diff(original.decode().splitlines(True), content.decode().splitlines(True),
                                        'a/' + relative, 'b/' + relative))
patch_name = 'KR-0002-csharp-recovery-transaction.patch'
patch_path = ROOT / 'tools/runtime-bundle/patches' / patch_name
with patch_path.open('x', encoding='utf-8', newline='\n') as output:
    output.write(patch)
config = ROOT / 'tools/runtime-bundle/source.json'
source = json.loads(config.read_text(encoding='utf-8'))
assert patch_name not in source['patches']
source['patches'].append(patch_name)
config.write_text(json.dumps(source, indent=2) + '\n', encoding='utf-8', newline='\n')
destination = ROOT / '.scratch/full-pass/runtime-kr2'
receipt = ROOT / '.scratch/full-pass/runtime-kr2-manifest.json'
run('03-kr2-product/reproduce', ['python', 'tools/runtime-bundle/import.py', '--archive',
    str(ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'),
    '--output', str(destination), '--manifest', str(receipt)], timeout=90)
new_manifest = json.loads(receipt.read_text(encoding='utf-8'))
assert new_manifest['files'].keys() == old_manifest['files'].keys()
for name, record in new_manifest['files'].items():
    candidate = (destination / name).read_bytes()
    expected = changed[name]['after'] if name in changed else old_manifest['files'][name]['sha256']
    assert sha(candidate) == record['sha256'] == expected, name
for name in changed:
    (runtime / name).write_bytes((destination / name).read_bytes())
manifest.write_bytes(receipt.read_bytes())
pins_path = ROOT / 'internal/provenance/identities.json'
pins = json.loads(pins_path.read_text(encoding='utf-8'))
pins['runtime']['manifest_sha256'] = sha(manifest.read_bytes())
pins_path.write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8', newline='\n')
save(OUT / '03-kr2-product/adoption.json', {'runtime_manifest_sha256': sha(manifest.read_bytes()),
     'patch_sha256': sha(patch_path.read_bytes()), 'changed_files': changed,
     'reproduced_files': len(new_manifest['files']), 'excluded_kr4_overlay': 'parser_result_csharp.go'})
print('Adopted', len(changed), 'changed files with exact', len(new_manifest['files']), 'file reproduction')
