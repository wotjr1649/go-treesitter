import difflib
import json
import subprocess
from receipt import ROOT, OUT, run, save, sha

name = 'parser_result_csharp.go'
runtime = ROOT / 'internal/runtime'
path = runtime / name
manifest = ROOT / 'internal/provenance/runtime.json'
old = json.loads(manifest.read_text(encoding='utf-8'))
original = path.read_bytes()
assert sha(original) == old['files'][name]['sha256']
fixed = (ROOT / '.scratch/full-pass/csharp-reviewed-candidate' / (name + '.txt')).read_bytes()
patch_name = 'KR-0004-csharp-preserve-recovery-errors.patch'
patch_path = ROOT / 'tools/runtime-bundle/patches' / patch_name
with patch_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(''.join(difflib.unified_diff(original.decode().splitlines(True), fixed.decode().splitlines(True), 'a/' + name, 'b/' + name)))
config = ROOT / 'tools/runtime-bundle/source.json'
source = json.loads(config.read_text(encoding='utf-8'))
source['patches'].append(patch_name)
config.write_text(json.dumps(source, indent=2) + '\n', encoding='utf-8', newline='\n')
destination = ROOT / '.scratch/full-pass/runtime-kr4'
receipt = ROOT / '.scratch/full-pass/runtime-kr4-manifest.json'
run('03-kr4-product/reproduce', ['python', 'tools/runtime-bundle/import.py', '--archive',
    str(ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'),
    '--output', str(destination), '--manifest', str(receipt)], timeout=90)
new = json.loads(receipt.read_text(encoding='utf-8'))
assert new['files'].keys() == old['files'].keys()
for item, record in new['files'].items():
    expected = sha(fixed) if item == name else old['files'][item]['sha256']
    assert sha((destination / item).read_bytes()) == record['sha256'] == expected, item
path.write_bytes(fixed)
manifest.write_bytes(receipt.read_bytes())
# Preserve the original compact JSON formatting, changing only the carrier hash.
pins_path = ROOT / 'internal/provenance/identities.json'
previous_pins = subprocess.check_output(['git', 'show', 'HEAD:internal/provenance/identities.json'], cwd=ROOT).decode()
prior_hash = json.loads(previous_pins)['runtime']['manifest_sha256']
pins_path.write_text(previous_pins.replace(prior_hash, sha(manifest.read_bytes())), encoding='utf-8', newline='\n')
save(OUT / '03-kr4-product/adoption.json', {'runtime_manifest_sha256': sha(manifest.read_bytes()),
    'patch_sha256': sha(patch_path.read_bytes()), 'before_sha256': sha(original), 'after_sha256': sha(fixed),
    'reproduced_files': len(new['files'])})
print('Adopted reconstruction guard with exact', len(new['files']), 'file reproduction')
