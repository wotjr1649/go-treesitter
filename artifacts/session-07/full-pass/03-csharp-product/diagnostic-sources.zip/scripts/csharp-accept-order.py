import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-accept-order'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-shared-error-prefix/overlay.json').read_text(encoding='utf-8'))

def read(name):
    original = ROOT / 'internal/runtime' / name
    return original, Path(overlay['Replace'].get(str(original), original)).read_text(encoding='utf-8')

def write(original, source):
    backing = work / (original.name + '.txt')
    backing.write_text(source, encoding='utf-8', newline='\n')
    overlay['Replace'][str(original)] = str(backing)

p,s = read('glr.go')
assert s.count('\taccepted bool') == 1
s=s.replace('\taccepted bool','\taccepted bool\n\tcAcceptOrder uint64')
# Clone structs already preserve pending-token state at all three fork sites.
needle='cRecoverPendingToken: '
lines=s.splitlines(keepends=True)
for i in range(len(lines)-1,-1,-1):
    if needle in lines[i]:
        indent=lines[i][:len(lines[i])-len(lines[i].lstrip())]
        lines.insert(i+1,indent+'cAcceptOrder: s.cAcceptOrder,\n')
s=''.join(lines)
write(p,s)
p,s=read('parser.go')
needle='type Parser struct {'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n\tcNextAcceptOrder uint64')
needle='\tstacks, maxStacksSeen = p.newInitialParseStacks('
assert s.count(needle)==1
s=s.replace(needle,'\tp.cNextAcceptOrder = 0\n'+needle)
s=s.replace('\t\t\ts.accepted = true','\t\t\tp.acceptStack(s)')
write(p,s)
p,s=read('parser_reduce.go')
assert s.count('s.accepted = true')==2
s=s.replace('s.accepted = true','p.acceptStack(s)')
needle='func (p *Parser) applyAcceptAction(s *glrStack) {'
helper='''func (p *Parser) acceptStack(s *glrStack) {
	if !s.accepted && p != nil {
		p.cNextAcceptOrder++
		s.cAcceptOrder = p.cNextAcceptOrder
	}
	s.accepted = true
}

'''
s=s.replace(needle,helper+needle)
write(p,s)
p,s=read('parser_recover_c.go')
assert s.count('v.accepted = true')==1
s=s.replace('v.accepted = true','p.acceptStack(v)')
write(p,s)
p,s=read('parser_result.go')
needle='''		} else if ac > 0 {
			return 1
		}'''
assert s.count(needle)==1
s=s.replace(needle,'''		} else if ac > 0 {
			if p.compactPackedGSSVersionOrderEnabled() && a.cAcceptOrder != b.cAcceptOrder {
				if a.cAcceptOrder < b.cAcceptOrder {
					return -1
				}
			}
			return 1
		}''')
write(p,s)
candidate.check('03-csharp-accept-order', overlay, work)
