import json
from pathlib import Path
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

def check(name, overlay, work):
    save(work / 'overlay.json', overlay)
    exe = work / 'candidate.exe'
    run(name + '/build', ['go', 'build', '-trimpath', '-overlay=' + str(work / 'overlay.json'), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
    cases = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
    cases += json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
    for path in ('03-csharp-transaction-candidate/zero-identifier-reduction.json',
                 '03-csharp-transaction-candidate/else-declaration-reduction.json',
                 '03-csharp-keep-first-recovery-v3/pointer-argument-reduction.json'):
        record = json.loads((OUT / path).read_text(encoding='utf-8'))['best']
        cases.append(dict(record, id=Path(path).stem))
    requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in cases]
    result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=120)
    actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
    rows = [{'id': r['id'], 'source_sha256': r['source_sha256'], 'equal_c': actual[r['id']]['Nodes'] == r['c']['nodes'], 'go': actual[r['id']]} for r in cases]
    save(OUT / name / 'comparison.json', {'candidate_sha256': sha(exe.read_bytes()),
        'overlays': {key: sha(Path(path).read_bytes()) for key, path in overlay['Replace'].items()}, 'rows': rows})
    for row in rows:
        print(row['id'], row['equal_c'], row['go']['Observations'][0]['Outcome'], len(row['go']['Nodes'] or []))
