import json
import re
import subprocess
from pathlib import Path
from receipt import ROOT, OUT, ENV, save, sha

cases = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
cases += json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
sources = [(row['id'].replace('.', '-'), row['source']) for row in cases]
for path in ('03-csharp-transaction-candidate/zero-identifier-reduction.json',
             '03-csharp-transaction-candidate/else-declaration-reduction.json',
             '03-csharp-keep-first-recovery-v3/pointer-argument-reduction.json'):
    row = json.loads((OUT / path).read_text(encoding='utf-8'))['best']
    name, source = Path(path).stem, row['source']
    for suffix, text in [('original', source), ('comment', '// recovery control\n' + source),
                         ('crlf', source.replace('\n', '\r\n')), ('leading-line', '\n' + source),
                         ('renamed', re.sub(r'\b(?:dateParseHandling|srcOffset|Newtonsoft)\b', 'LongerIdentifier', source)),
                         ('unicode', source.replace('dateParseHandling', '변수').replace('srcOffset', '변수'))]:
        sources.append((name + '-' + suffix, text))
sources += [
    ('valid-pointer', 'unsafe class C { void M(int* p) { F(p); } void F(int* p) {} }\n'),
    ('valid-products', 'class C { void M() { Buffer.BlockCopy(a, b * c, d, e * f, g * h); } }\n'),
    ('valid-products-renamed', 'class Container { void Method() { G(first, factor * count, fourth); } }\n'),
    ('valid-out-var', 'class C { void M() { if (int.TryParse(s, out int value)) { F(value); } } }\n'),
    ('valid-else', 'class C { void M() { if (x) { F(); } else { G(); } } }\n'),
    ('valid-preprocessor', 'class C { void M() {\n#if X\nF();\n#else\nG();\n#endif\n} }\n'),
]
assert len({name for name, _ in sources}) == len(sources)
exe = ROOT / '.scratch/full-pass/csharp-reviewed-candidate/candidate.exe'
native = ROOT / '.scratch/oracle/build-full-pass-v2/c_sharp.exe'
records = []
for name, source in sources:
    attempts = [json.loads(subprocess.run([str(native)], input=source.encode(), env=ENV,
                capture_output=True, check=True, timeout=10).stdout) for _ in range(3)]
    assert attempts[0] == attempts[1] == attempts[2], name
    records.append({'id': name, 'source': source, 'sha256': sha(source.encode()), 'c': attempts[0]})
previous = 'class Before {}\n'
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'],
             'Repeat': 100 if r['c']['has_error'] else 20, 'Previous': previous,
             'Edit': {'StartByte': 0, 'OldEndByte': len(previous), 'NewEndByte': len(r['source'].encode())}}
            for r in records]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), env=ENV,
                        capture_output=True, check=True, timeout=180)
actual = {row['ID']: row for row in map(json.loads, result.stdout.splitlines())}
rows = []
for record in records:
    go = actual[record['id']]
    stable = all(item == go['Observations'][0] for item in go['Observations'])
    passed = (go['Nodes'] == record['c']['nodes'] and stable and go['IncrementalEqual'] and
              len(go['Observations']) == (100 if record['c']['has_error'] else 20) and go['Observations'][0]['Complete'])
    rows.append(dict(record, go=go, deterministic=stable, passed=passed))
save(OUT / '03-csharp-reviewed-candidate/expanded.json', {'go_exe_sha256': sha(exe.read_bytes()),
     'c_exe_sha256': sha(native.read_bytes()), 'c_repeats': 3, 'clean_repeats': 20, 'recovery_repeats': 100, 'rows': rows})
for row in rows:
    if not row['passed']:
        print(row['id'], 'C exact', row['go']['Nodes'] == row['c']['nodes'], 'stable', row['deterministic'],
              'edit', row['go']['IncrementalEqual'], 'Go/C nodes', len(row['go']['Nodes'] or []), len(row['c']['nodes']))
print('PASS', sum(r['passed'] for r in rows), '/', len(rows))
