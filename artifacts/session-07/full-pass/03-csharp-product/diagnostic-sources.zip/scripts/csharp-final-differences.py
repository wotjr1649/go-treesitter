import difflib
import json
from receipt import ROOT, OUT, save

go = json.loads((OUT / '03-csharp-pending-raw/comparison.json').read_text(encoding='utf-8'))
c = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))
by_id = {row['id']: row for row in c['rows']}
rows = []
for row in go['rows']:
    if row['equal_c']:
        continue
    oracle = by_id[row['id']]
    left, right = row['go']['Nodes'], oracle['c']['nodes']
    match = difflib.SequenceMatcher(a=[json.dumps(n, sort_keys=True) for n in left], b=[json.dumps(n, sort_keys=True) for n in right], autojunk=False)
    blocks = []
    for action, a, b, x, y in match.get_opcodes():
        if action != 'equal':
            blocks.append({'action': action, 'go_range': [a, b], 'c_range': [x, y], 'go': left[a:b], 'c': right[x:y]})
    rows.append({'id': row['id'], 'blocks': blocks})
    print(row['id'], 'blocks', len(blocks))
    for block in blocks[:12]:
        print(json.dumps(block, ensure_ascii=True)[:4500])
save(OUT / '03-csharp-pending-raw/differences.json', rows)
