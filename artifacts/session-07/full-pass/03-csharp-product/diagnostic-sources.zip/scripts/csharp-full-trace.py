import json
import subprocess
import zipfile
from receipt import ROOT, OUT, ENV, save, sha

go_exe = ROOT / '.scratch/full-pass/csharp-v3-reduced-trace/trace.exe'
c_exe = ROOT / '.scratch/session07-probe/trace-c.exe'
case = next(r for r in json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows'] if r['id'] == 'CS-excerpt-no-enum')
request = [{'ID': case['id'], 'Filename': 'x.cs', 'Source': case['source'], 'Repeat': 1}]
go = subprocess.run([str(go_exe)], input=json.dumps(request).encode(), env=ENV, capture_output=True, check=True, timeout=30)
c = subprocess.run([str(c_exe)], input=case['source'].encode(), env=ENV, capture_output=True, check=True, timeout=30)
assert len(go.stdout) + len(go.stderr) + len(c.stderr) < 32_000_000
go_trace = [line for line in go.stdout.decode().splitlines() if not line.startswith('{')]
results = [json.loads(line) for line in go.stdout.decode().splitlines() if line.startswith('{')]
assert len(results) == 1 and json.loads(c.stdout)['nodes'] == case['c']['nodes']
directory = OUT / '03-csharp-full-trace'
directory.mkdir(exist_ok=False)
save(directory / 'comparison.json', {'source': case['source'], 'source_sha256': case['source_sha256'],
    'go_exe_sha256': sha(go_exe.read_bytes()), 'c_exe_sha256': sha(c_exe.read_bytes()),
    'go': results[0], 'c': json.loads(c.stdout), 'go_trace': go_trace, 'c_trace': c.stderr.decode().splitlines()})
print('passes', sum(line.startswith('[GLR] iter=0 ') for line in go_trace),
      'Go lines', len(go_trace), 'C lines', len(c.stderr.splitlines()),
      'equal', results[0]['Nodes'] == case['c']['nodes'])
with zipfile.ZipFile(directory / 'command-output.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('go-stdout.log', go.stdout)
    archive.writestr('go-stderr.log', go.stderr)
    archive.writestr('c-stdout.log', c.stdout)
    archive.writestr('c-stderr.log', c.stderr)
