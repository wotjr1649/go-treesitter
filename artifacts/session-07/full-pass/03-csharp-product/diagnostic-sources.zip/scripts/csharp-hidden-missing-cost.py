import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-hidden-missing-cost'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-transaction-candidate/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_reduce.go'
s = original.read_text(encoding='utf-8')
start = s.index('func (p *Parser) rawStackEntryErrorCost(')
end = s.index('\nfunc ', start + 1)
part = s[start:end]
needle = '\t\tchildCount := stackEntryNodeChildCount(item.entry)'
assert part.count(needle) == 1
part = part.replace(needle, '\t\t_, childCount, _ := rawStackWalkEntryHeader(arena, item)')
s = s[:start] + part + s[end:]
backing = work / 'reduce.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
original = ROOT / 'internal/runtime/parser_recover_c.go'
s = Path(overlay['Replace'][str(original)]).read_text(encoding='utf-8')
start = s.index('func (p *Parser) cNodeErrorCost(n *Node) uint32 {')
needle = '''		if n.isMissing() {
			return cErrCostPerMissingTree + cErrCostPerRecovery
		}
		return 0'''
end = s.index('\nfunc ', start + 1)
part = s[start:end]
assert part.count(needle) == 1
part = part.replace(needle, '''		if n.isMissing() {
			return cErrCostPerMissingTree + cErrCostPerRecovery
		}
		if n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
			return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
		}
		return 0''')
s = s[:start] + part + s[end:]
start = s.index('func (p *Parser) cNodeErrorCostAndVisibleSubtreeCount(')
end = s.index('\nfunc ', start + 1)
part = s[start:end]
needle = '''		if n.isMissing() {
			cost = cErrCostPerMissingTree + cErrCostPerRecovery
		}'''
assert part.count(needle) == 1
part = part.replace(needle, '''		if n.isMissing() {
			cost = cErrCostPerMissingTree + cErrCostPerRecovery
		} else if n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
			cost = p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
		}''')
s = s[:start] + part + s[end:]
backing = work / 'recover.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-hidden-missing-cost', overlay, work)
