import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

cases = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
cases += json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
previous = 'class Before {}\n'
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1,
             'Previous': previous, 'Edit': {'StartByte': 0, 'OldEndByte': len(previous), 'NewEndByte': len(r['source'].encode())}}
            for r in cases]
exe = ROOT / '.scratch/full-pass/csharp-accept-order/candidate.exe'
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), env=ENV, capture_output=True, check=True, timeout=90)
rows = list(map(json.loads, result.stdout.splitlines()))
save(OUT / '03-csharp-accept-order/incremental.json', {'executable_sha256': sha(exe.read_bytes()), 'requests': requests, 'rows': rows})
for row in rows:
    if not row['IncrementalEqual']:
        print(row['ID'], 'incremental differs', row['Incremental'], len(row['Nodes'] or []), len(row['IncrementalNodes'] or []))
print('equal', sum(r['IncrementalEqual'] for r in rows), 'of', len(rows))
