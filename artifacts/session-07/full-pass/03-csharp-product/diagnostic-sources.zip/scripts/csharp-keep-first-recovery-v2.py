import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-keep-first-recovery-v2'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-preserve-condense-order/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/grammars/runtime/runtime_profiles.go'
s = Path(overlay['Replace'][str(original)]).read_text(encoding='utf-8')
start = s.index('\t"c_sharp": {')
end = s.index('\n\t"', start + 1)
part = s[start:end]
needle = '\t\t\tSkipCompleteMaxEntryScratchPeak:            csharpAcceptedErrorRetryMaxEntryScratchPeak,\n'
assert part.count(needle) == 1
part = part.replace(needle, '')
s = s[:start] + part + s[end:]
backing = work / 'profiles.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-keep-first-recovery-v2', overlay, work)
