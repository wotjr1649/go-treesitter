import importlib.util
import json
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-kr2-only'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-accept-order/overlay.json').read_text(encoding='utf-8'))
del overlay['Replace'][str(ROOT / 'internal/runtime/parser_result_csharp.go')]
candidate.check('03-csharp-kr2-only', overlay, work)
