import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

sources = [
    ('qualified-case', 'class C { void M() { switch (x) { case T.A: break; } } }'),
    ('qualified-two', 'class C { void M() { switch (x) { case T.A: case T.B: break; } } }'),
    ('invoke', 'class C { void M() { F(true); G(a, b); } }'),
    ('conditional-else', 'class C { void M() { if(x) {\n#if X\nF();\n#else\nG();\n#endif\n} else { H(); } } }'),
    ('else-after-endif', 'class C { void M() {\n#if X\nif(x) { F(); }\n#endif\nelse { H(); } } }'),
    ('switch-directives', 'class C { void M() { switch (x) { case T.A:\n#if X\nif(x) { F(); }\n#endif\nelse { H(); }\nbreak; } } }'),
    ('error-before-switch', 'class C { void M() { @@@; switch(x) { case T.A: break; } } }'),
]
requests = [{'ID': name, 'Filename': 'x.cs', 'Source': source, 'Repeat': 1} for name, source in sources]
executables = {'baseline': ROOT / '.scratch/full-pass/bundled-probe.exe',
               'pending': ROOT / '.scratch/full-pass/csharp-pending-02/pending.exe',
               'preserve-structure': ROOT / '.scratch/full-pass/csharp-pending-raw/pending-raw.exe'}
actual = {}
for name, exe in executables.items():
    result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=60)
    actual[name] = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
oracle = ROOT / '.scratch/oracle/build-full-pass-v2/c_sharp.exe'
rows = []
for name, source in sources:
    native = json.loads(subprocess.run([str(oracle)], input=source.encode(), capture_output=True, env=ENV, check=True, timeout=15).stdout)
    row = {'id': name, 'source': source, 'source_sha256': sha(source.encode()), 'c': native, 'go': {label: values[name] for label, values in actual.items()}}
    rows.append(row)
    print(name, 'c_error', native['has_error'], ' '.join(label + '=' + str(values[name]['Nodes'] == native['nodes']) for label, values in actual.items()))
    for label, values in actual.items():
        if values[name]['Nodes'] != native['nodes']:
            a, b = values[name]['Nodes'], native['nodes']
            first = next((i for i in range(min(len(a), len(b))) if a[i] != b[i]), min(len(a), len(b)))
            print(label, len(a), len(b), 'first', first, a[first:first+1], b[first:first+1])
save(OUT / '03-csharp-pending-raw/patterns.json', rows)
