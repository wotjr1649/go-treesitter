"""A single, falsifiable ordering hypothesis in an isolated runtime overlay."""
import json
from pathlib import Path
import subprocess
import zipfile
from receipt import ROOT, OUT, ENV, run, save, sha

runtime = ROOT / '.scratch/session07-runtime'
work = ROOT / '.scratch/full-pass/csharp'
work.mkdir(exist_ok=False)
archive = ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'
prefix = 'github.com/odvcencio/gotreesitter@v0.53.0/'
with zipfile.ZipFile(archive) as zipped:
    for name in zipped.namelist():
        assert (runtime / name.removeprefix(prefix)).read_bytes() == zipped.read(name), name
original = (runtime / 'parser_recover_c.go').read_text(encoding='utf-8')
start = original.index('\t\t\tif !p.compactPackedGSSVersionOrderEnabled() {\n\t\t\t\tif cRecoverVersionShouldStayBefore')
end = original.index('\t\t\tstatusJ :=', start)
patched = original[:start] + original[end:]
backing = work / 'order.go.txt'
backing.write_text(patched, encoding='utf-8', newline='\n')
overlay = work / 'overlay.json'
save(overlay, {'Replace': {str(runtime / 'parser_recover_c.go'): str(backing)}})
save(OUT / '03-csharp-order/hypothesis.json', {
    'hypothesis': 'remove non-C absorber/missing-sibling order exception in cCondenseAndResume',
    'baseline': 'v0.53.0', 'archive_sha256': sha(archive.read_bytes()),
    'before_sha256': sha(original.encode()), 'after_sha256': sha(patched.encode()),
    'removed_source': original[start:end], 'product_adopted': False})
exe = work / 'order.exe'
run('03-csharp-order/build', ['go', 'build', '-trimpath',
    '-modfile=.scratch/session07-runtime.mod', '-overlay=' + str(overlay),
    '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
matrix = json.loads((ROOT / 'artifacts/session-07/phase2-correctness/csharp-reduction-matrix-01.json').read_text(encoding='utf-8'))
cases = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in matrix['comparisons']]
for name in ('JsonPosition.cs', 'JsonTextReader-excerpt.cs', 'MathUtils.cs'):
    cases.append({'ID': name, 'Filename': 'x.cs', 'Source': (ROOT / 'testdata/newtonsoft' / name).read_text(encoding='utf-8'), 'Repeat': 1})
variant = json.loads((ROOT / 'testdata/oracle/csharp-recovery-cases.json').read_text(encoding='utf-8'))[0]
cases.append({'ID': variant['id'], 'Filename': 'x.cs', 'Source': variant['source'], 'Repeat': 1})
results = {}
for label, binary in (('baseline', ROOT / '.scratch/full-pass/probe.exe'), ('order', exe)):
    result = subprocess.run([str(binary)], input=json.dumps(cases).encode(), capture_output=True, env=ENV, check=True, timeout=90)
    results[label] = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
oracle = ROOT / '.scratch/oracle/build-full-pass-v2/c_sharp.exe'
rows = []
for case in cases:
    native = json.loads(subprocess.run([str(oracle)], input=case['Source'].encode(), capture_output=True, env=ENV, check=True, timeout=15).stdout)
    row = {'id': case['ID'], 'source': case['Source'], 'source_sha256': sha(case['Source'].encode()), 'c': native}
    for label in results:
        go = results[label][case['ID']]
        row[label] = go
        row[label + '_equal_c'] = go['Nodes'] == native['nodes']
    rows.append(row)
    print(case['ID'], 'baseline', row['baseline_equal_c'], 'order', row['order_equal_c'], flush=True)
save(OUT / '03-csharp-order/comparison.json', {'oracle_sha256': sha(oracle.read_bytes()),
    'candidate_sha256': sha(exe.read_bytes()), 'rows': rows})
print('matches', sum(r['baseline_equal_c'] for r in rows), '->', sum(r['order_equal_c'] for r in rows), 'of', len(rows))
