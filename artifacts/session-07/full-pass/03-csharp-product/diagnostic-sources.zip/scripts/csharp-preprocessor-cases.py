import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

prefixes = ['', 'namespace N { enum E { A, B } ', 'namespace N { enum E { A,\n#if X\nB,\n#endif\n} ']
bodies = [
    'if(x) { a=T.A; }\n#if X\nelse if(y) { a=T.B; }\n#endif\nelse { a=b; }',
    'if(x) { F(); }\n#if X\nelse if(y) { G(); }\n#endif\nelse { H(); }',
    'if(x) { int a; if(y) { a=T.A; }\n#if X\nelse if(z) { a=T.B; }\n#endif\nelse { a=b; }\nF(); }',
    'switch(x) { default: if(x) { int a; if(y) { a=T.A; }\n#if X\nelse if(z) { a=T.B; }\n#endif\nelse { a=b; }\nF(); } break; }',
]
cases = []
for pi, prefix in enumerate(prefixes):
    for bi, body in enumerate(bodies):
        for name in ('a', 'dateParseHandling'):
            source = prefix + 'class C { void M() { ' + body.replace('a', name) + ' } }' + (' }' if prefix else '')
            cases.append({'ID': f'preproc-{pi}-{bi}-{name}', 'Filename': 'x.cs', 'Source': source, 'Repeat': 1})
exe = ROOT / '.scratch/full-pass/csharp-transaction-candidate/transaction.exe'
result = subprocess.run([str(exe)], input=json.dumps(cases).encode(), capture_output=True, env=ENV, check=True, timeout=90)
actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
oracle = ROOT / '.scratch/oracle/build-full-pass-v2/c_sharp.exe'
rows = []
for case in cases:
    c = json.loads(subprocess.run([str(oracle)], input=case['Source'].encode(), capture_output=True, env=ENV, check=True, timeout=15).stdout)
    g = actual[case['ID']]
    row = {'id': case['ID'], 'source': case['Source'], 'source_sha256': sha(case['Source'].encode()), 'c': c, 'go': g, 'equal_c': g['Nodes'] == c['nodes']}
    rows.append(row)
save(OUT / '03-csharp-transaction-candidate/preprocessor-cases.json', rows)
for row in rows:
    print(row['id'], row['equal_c'], len(row['go']['Nodes'] or []), len(row['c']['nodes']))
