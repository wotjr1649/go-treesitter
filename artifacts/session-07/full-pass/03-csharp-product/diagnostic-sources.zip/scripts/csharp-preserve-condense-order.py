import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-preserve-condense-order'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-hidden-missing-cost/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser.go'
s = Path(overlay['Replace'][str(original)]).read_text(encoding='utf-8')
needle = 'func (p *Parser) promotePrimaryStack(stacks []glrStack) {\n\tif len(stacks) <= 1 {'
assert s.count(needle) == 1
s = s.replace(needle, 'func (p *Parser) promotePrimaryStack(stacks []glrStack) {\n\tif len(stacks) <= 1 || p.compactPackedGSSVersionOrderEnabled() {')
backing = work / 'parser.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-preserve-condense-order', overlay, work)
