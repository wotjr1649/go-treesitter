import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

exe = ROOT / '.scratch/full-pass/csharp-product.exe'
run('03-csharp-product/build', ['go', 'build', '-trimpath', '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
expected = json.loads((OUT / '03-csharp-reviewed-candidate/expanded.json').read_text(encoding='utf-8'))['rows']
previous = 'class Before {}\n'
requests = [{'ID': row['id'], 'Filename': 'x.cs', 'Source': row['source'],
             'Repeat': 100 if row['c']['has_error'] else 20, 'Previous': previous,
             'Edit': {'StartByte': 0, 'OldEndByte': len(previous), 'NewEndByte': len(row['source'].encode())}}
            for row in expected]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=150)
actual = {row['ID']: row for row in map(json.loads, result.stdout.splitlines())}
rows = []
for case in expected:
    row = actual[case['id']]
    count = 100 if case['c']['has_error'] else 20
    passed = len(row['Observations']) == count and row['Observations'][0]['Complete'] and row['IncrementalEqual'] and row['Nodes'] == case['c']['nodes']
    passed &= all(item == row['Observations'][0] for item in row['Observations'])
    rows.append({'id': case['id'], 'source_sha256': case['sha256'], 'passed': passed, 'go': row})
save(OUT / '03-csharp-product/repeated.json', {'executable_sha256': sha(exe.read_bytes()),
    'runtime_manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes()),
    'reference_sha256': sha((OUT / '03-csharp-reviewed-candidate/expanded.json').read_bytes()), 'rows': rows})
print('Product C exact/deterministic/incremental', sum(row['passed'] for row in rows), '/', len(rows))
assert all(row['passed'] for row in rows)
