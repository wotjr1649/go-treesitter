import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-raw-recovery-cost'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-hidden-missing-cost/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_recover_c.go'
s = Path(overlay['Replace'][str(original)]).read_text(encoding='utf-8')
needle = '''	// Ordinary leaves need no subtree walk. Keep them out of the bounded memo.'''
assert s.count(needle) == 1
s = s.replace(needle, '''	if n.symbol != errorSymbol && n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
		return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
	}
''' + needle)
needle = '''func (p *Parser) cNodeErrorCostAndVisibleSubtreeCount(n *Node) (uint32, int) {
	if p == nil || n == nil {
		return 0, 0
	}'''
assert s.count(needle) == 1
s = s.replace(needle, needle + '''
	if n.symbol != errorSymbol && n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
		return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n)), p.cNodeVisibleSubtreeCount(n)
	}''')
backing = work / 'recover.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-raw-recovery-cost', overlay, work)
