import json
from pathlib import Path
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/csharp-repeat-order'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-pending-raw/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_reduce.go'
s = original.read_text(encoding='utf-8')
needle = '''	if p.symbolIsGeneratedRepeatAux(as) &&
		stackEntryNodeStartByte(a.entry) == stackEntryNodeStartByte(b.entry) &&
		stackEntryNodeEndByte(a.entry) != stackEntryNodeEndByte(b.entry) {
		if stackEntryNodeEndByte(a.entry) < stackEntryNodeEndByte(b.entry) {
			return -1
		}
		return 1
	}
'''
assert s.count(needle) == 1
s = s.replace(needle, '')
backing = work / 'parser_reduce.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
save(work / 'overlay.json', overlay)
exe = work / 'repeat-order.exe'
run('03-csharp-repeat-order/build', ['go', 'build', '-trimpath', '-overlay=' + str(work / 'overlay.json'), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
cases = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
cases += json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in cases]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=120)
actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
rows = []
for case in cases:
    g = actual[case['id']]
    row = {'id': case['id'], 'source_sha256': case['source_sha256'], 'equal_c': g['Nodes'] == case['c']['nodes'], 'go': g}
    rows.append(row)
    print(case['id'], row['equal_c'], len(g['Nodes']), len(case['c']['nodes']))
save(OUT / '03-csharp-repeat-order/comparison.json', {'candidate_sha256': sha(exe.read_bytes()),
    'overlays': {name: sha(Path(path).read_bytes()) for name, path in overlay['Replace'].items()}, 'rows': rows})
