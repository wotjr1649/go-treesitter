import importlib.util
import json
from pathlib import Path
from receipt import ROOT, ENV
import subprocess

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-reviewed-candidate'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-accept-order/overlay.json').read_text(encoding='utf-8'))
for original_name, source_name in list(overlay['Replace'].items()):
    original = Path(original_name)
    s = Path(source_name).read_text(encoding='utf-8')
    if original.name == 'glr.go':
        s = s.replace('// Diagnostic: merging clean suffixes over the same immutable error prefix\n// preserves the error history; no error-bearing payload is merged or replaced.',
            '// A shared immutable error prefix has identical recovery history on both\n// paths. Only the clean suffixes may merge; distinct error-bearing payloads\n// and paths that bypass that common prefix remain separate.')
        needle = '\t\tseen[n] = true\n\t\tif stackEntryHasNode(n.entry)'
        assert s.count(needle) == 1
        s = s.replace(needle, '''		seen[n] = true
		if len(seen)&63 == 0 && scratch.parser != nil &&
			resultMaterializationShouldStop(scratch.parser.resultMaterializationStopReason(scratch.arena)) {
			return false
		}
		if stackEntryHasNode(n.entry)''')
        needle = '''	clean := gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a.gss.head) &&
		gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b.gss.head)
	workCountRecordGSSCleanReject'''
        assert s.count(needle) == 1
        s = s.replace(needle, '''	clean := (gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a.gss.head) &&
		gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b.gss.head)) ||
		(a.cRec == nil && b.cRec == nil && !a.cPaused && !b.cPaused &&
		gssSharedClosedErrorPrefix(scratch, a.gss.head, b.gss.head))
	workCountRecordGSSCleanReject''')
        s = s.replace('// The enclosing GSS merge proves that every link is clean. Do not use',
            '// Distinct payloads belong to the clean suffix; a shared error prefix\n\t// matched by identity above. Do not use')
        s = s.replace('\tcAcceptOrder uint64', '\t// C breaks equal positive-cost results by acceptance time, not slice position.\n\tcAcceptOrder uint64', 1)
        s = s.replace('\tcRecoverPendingToken *Token', '\t// A missing-token sibling resumes its previous lookahead next round.\n\tcRecoverPendingToken *Token', 1)
    if original.name == 'runtime_profiles.go':
        s = s.replace("// C#'s certified low-pressure accepted-error trees are authoritative. A", "// C#'s packed version transaction preserves complete recovered trees. A")
    backing = work / (original.name + '.txt')
    backing.write_text(s, encoding='utf-8', newline='\n')
    subprocess.run(['gofmt', '-w', str(backing)], env=ENV, check=True, timeout=20)
    overlay['Replace'][original_name] = str(backing)
candidate.check('03-csharp-reviewed-candidate', overlay, work)
