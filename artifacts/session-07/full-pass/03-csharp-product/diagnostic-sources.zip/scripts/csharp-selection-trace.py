import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save

work = ROOT / '.scratch/full-pass/csharp-selection-trace'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-pattern-trace/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_result.go'
s = original.read_text(encoding='utf-8')
needle = 'func (p *Parser) traceCResultSelectionCompare(candidateIndex, bestIndex, cmp int, candidate, best *glrStack, arena *nodeArena) {'
extra = '''
 for label, stack := range map[string]*glrStack{"candidate": candidate, "best": best} {
  entries, _ := stackMaterializingResultEntries(stack, nil, stackMaterializingResultEntryCount(stack))
  for _, entry := range entries {
   if n := stackEntryNode(entry); n != nil { fmt.Println("TREE", label, n.SExpr(p.language)) }
  }
 }
 fmt.Println("CHOICES", compareAcceptedStackAliasPreference(p, arena, candidate, best), compareAcceptedStackTreeOrderPreference(p, arena, candidate, best), compareAcceptedStackRawShapePreference(p, arena, candidate, best))
 cmpExact, complete := compareRawStackEntriesCExact(arena, candidate.top(), best.top(), cExactParentSelectionWorkLimit)
 fmt.Println("EXACT", cmpExact, complete)
'''
assert s.count(needle) == 1
s = s.replace(needle, needle + extra)
backing = work / 'result.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
save(work / 'overlay.json', overlay)
exe = work / 'trace.exe'
run('03-csharp-selection-trace/build', ['go', 'build', '-trimpath', '-overlay=' + str(work / 'overlay.json'), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
cases = json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
for case in cases:
    if case['id'] not in ('qualified-case', 'qualified-two'):
        continue
    request = [{'ID': case['id'], 'Filename': 'x.cs', 'Source': case['source'], 'Repeat': 1}]
    process = subprocess.run([str(exe)], input=json.dumps(request).encode(), env=ENV, capture_output=True, check=True, timeout=20)
    selected = [line for line in process.stdout.decode().splitlines() if line.startswith(('TREE', 'CHOICES', 'EXACT'))]
    save(OUT / ('03-csharp-selection-trace/' + case['id'] + '.json'), {'trace': selected})
    print(case['id'], '\n'.join(selected))
