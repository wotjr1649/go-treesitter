import importlib.util
import json
from pathlib import Path
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-shared-error-prefix'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-keep-first-recovery-v3/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/glr.go'
s = Path(overlay['Replace'][str(original)]).read_text(encoding='utf-8')
needle = '''	return gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a.gss.head) &&
		gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b.gss.head)'''
assert s.count(needle) == 1
s = s.replace(needle, '''	return (gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a.gss.head) &&
		gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b.gss.head)) ||
		(a.cRec == nil && b.cRec == nil && !a.cPaused && !b.cPaused &&
		gssSharedClosedErrorPrefix(scratch, a.gss.head, b.gss.head))''')
needle = '''	if !gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a) ||
		!gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b) {
		return false
	}'''
assert s.count(needle) == 1
s = s.replace(needle, '''	if (!gssNodeCleanZeroErrorAllLinksWithScratch(scratch, a) ||
		!gssNodeCleanZeroErrorAllLinksWithScratch(scratch, b)) &&
		!gssSharedClosedErrorPrefix(scratch, a, b) {
		return false
	}''')
needle = '''	if !p.cleanZeroErrorAllLinks(a) || !p.cleanZeroErrorAllLinks(b) {
		return false
	}'''
assert s.count(needle) == 1
s = s.replace(needle, '''	if (!p.cleanZeroErrorAllLinks(a) || !p.cleanZeroErrorAllLinks(b)) &&
		!gssSharedClosedErrorPrefix(p.scratch, a, b) {
		return false
	}''')
needle = '\nfunc gssMainCanMergeWithScratch(scratch *glrMergeScratch, a, b *glrStack) bool {'
assert s.count(needle) == 1
helper = '''
// Diagnostic: merging clean suffixes over the same immutable error prefix
// preserves the error history; no error-bearing payload is merged or replaced.
func gssSharedClosedErrorPrefix(scratch *glrMergeScratch, a, b *gssNode) bool {
	if !compactPackedGSSVersionOrderEnabledForMerge(scratch) {
		return false
	}
	var boundary *gssNode
	seen := make(map[*gssNode]bool)
	queue := []*gssNode{a, b}
	for len(queue) > 0 {
		n := queue[len(queue)-1]
		queue = queue[:len(queue)-1]
		if n == nil {
			return false
		}
		if seen[n] {
			continue
		}
		seen[n] = true
		if stackEntryHasNode(n.entry) && (stackEntryNodeHasError(n.entry) ||
			stackEntryNodeIsMissing(n.entry) || stackEntryNodeSymbol(n.entry) == errorSymbol) {
			if boundary != nil && boundary != n {
				return false
			}
			boundary = n
			continue
		}
		for i := 0; i < n.linkCount(); i++ {
			prev, entry := n.link(i)
			if stackEntryHasNode(entry) && (stackEntryNodeHasError(entry) ||
				stackEntryNodeIsMissing(entry) || stackEntryNodeSymbol(entry) == errorSymbol) {
				return false
			}
			queue = append(queue, prev)
		}
	}
	return boundary != nil
}
'''
s = s.replace(needle, helper + needle)
backing = work / 'glr.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-shared-error-prefix', overlay, work)
