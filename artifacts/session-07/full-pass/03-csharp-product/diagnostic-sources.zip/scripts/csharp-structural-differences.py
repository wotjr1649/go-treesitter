import difflib
import json
from receipt import OUT, save

go = json.loads((OUT / '03-csharp-preserve-errors/comparison.json').read_text(encoding='utf-8'))
c = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))
by_id = {row['id']: row for row in c['rows']}
rows = []
for row in go['rows']:
    if row['equal_c']:
        continue
    oracle = by_id[row['id']]
    left, right = row['go']['Nodes'], oracle['c']['nodes']
    signature = lambda n: json.dumps({k: v for k, v in n.items() if k != 'Parent'}, sort_keys=True)
    match = difflib.SequenceMatcher(a=[signature(n) for n in left], b=[signature(n) for n in right], autojunk=False)
    blocks = []
    print(row['id'])
    for action, a, b, x, y in match.get_opcodes():
        if action != 'equal':
            block = {'action': action, 'go_range': [a, b], 'c_range': [x, y], 'go': left[a:b], 'c': right[x:y]}
            blocks.append(block)
            print(action, [a,b], [x,y])
            print('GO', [(n['Type'],n['Field'],n['StartByte'],n['EndByte'],n['Parent'],n['Missing'],n['Extra']) for n in left[a:b]])
            print('C ', [(n['Type'],n['Field'],n['StartByte'],n['EndByte'],n['Parent'],n['Missing'],n['Extra']) for n in right[x:y]])
    rows.append({'id': row['id'], 'blocks': blocks})
save(OUT / '03-csharp-preserve-errors/structural-differences.json', rows)
