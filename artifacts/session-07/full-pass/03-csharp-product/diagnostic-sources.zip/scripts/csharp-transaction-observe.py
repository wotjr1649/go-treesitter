import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

exe = ROOT / '.scratch/full-pass/csharp-transaction-candidate/transaction.exe'
cases = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
cases += json.loads((OUT / '03-csharp-pending-raw/patterns.json').read_text(encoding='utf-8'))
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in cases]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=120)
actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
rows = [{'id': r['id'], 'source_sha256': r['source_sha256'], 'equal_c': actual[r['id']]['Nodes'] == r['c']['nodes'], 'go': actual[r['id']]} for r in cases]
save(OUT / '03-csharp-transaction-candidate/comparison.json', {'candidate_sha256': sha(exe.read_bytes()), 'rows': rows})
for row in rows:
    print(row['id'], row['equal_c'], row['go']['Observations'][0]['Outcome'], len(row['go']['Nodes'] or []))
