import importlib.util
import json
from receipt import ROOT

spec = importlib.util.spec_from_file_location('candidate', ROOT / '.scratch/full-pass/csharp-candidate-check.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
work = ROOT / '.scratch/full-pass/csharp-transaction-raw'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-transaction-candidate/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_result_csharp.go'
s = original.read_text(encoding='utf-8')
needle = 'func normalizeCSharpCompatibility(root *Node, source []byte, p *Parser, lang *Language) {'
assert s.count(needle) == 1
s = s.replace(needle, needle + '\n\treturn // Diagnostic only: observe the raw GLR tree.')
backing = work / 'raw.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(original)] = str(backing)
candidate.check('03-csharp-transaction-raw', overlay, work)
