import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/csharp-v3-reduced-trace'
work.mkdir(exist_ok=False)
overlay = json.loads((ROOT / '.scratch/full-pass/csharp-keep-first-recovery-v3/overlay.json').read_text(encoding='utf-8'))
adapter = ROOT / 'internal/gtsadapter/adapter.go'
s = adapter.read_text(encoding='utf-8')
needle = '\t\tp := gts.NewParser(lang)'
assert s.count(needle) == 1
s = s.replace(needle, needle + '\n\t\tp.SetGLRTrace(true)', 1)
backing = work / 'adapter.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
overlay['Replace'][str(adapter)] = str(backing)
save(work / 'overlay.json', overlay)
exe = work / 'trace.exe'
run('03-csharp-v3-reduced-trace/build', ['go', 'build', '-trimpath', '-overlay=' + str(work / 'overlay.json'), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
native = ROOT / '.scratch/session07-probe/trace-c.exe'
for name in ('zero-identifier', 'else-declaration'):
    case = json.loads((OUT / ('03-csharp-transaction-candidate/' + name + '-reduction.json')).read_text(encoding='utf-8'))['best']
    request = [{'ID': name, 'Filename': 'x.cs', 'Source': case['source'], 'Repeat': 1}]
    go = subprocess.run([str(exe)], input=json.dumps(request).encode(), env=ENV, capture_output=True, check=True, timeout=20)
    c = subprocess.run([str(native)], input=case['source'].encode(), env=ENV, capture_output=True, check=True, timeout=20)
    assert len(go.stdout) + len(go.stderr) + len(c.stderr) < 2_000_000
    trace = [line for line in go.stdout.decode().splitlines() if not line.startswith('{')]
    result = [json.loads(line) for line in go.stdout.decode().splitlines() if line.startswith('{')]
    assert len(result) == 1 and json.loads(c.stdout)['nodes'] == case['c']['nodes']
    save(OUT / ('03-csharp-v3-reduced-trace/' + name + '.json'), {
        'source': case['source'], 'source_sha256': case['source_sha256'], 'go_exe_sha256': sha(exe.read_bytes()),
        'c_exe_sha256': sha(native.read_bytes()), 'go': result[0], 'c': json.loads(c.stdout),
        'go_trace': trace, 'c_trace': c.stderr.decode().splitlines()})
    print(name, 'C equal', result[0]['Nodes'] == case['c']['nodes'], 'Go lines', len(trace), 'C lines', len(c.stderr.splitlines()))
