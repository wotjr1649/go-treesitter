"""Isolated test: dispatch a missing sibling after the absorber's next advance."""
import difflib
import json
from pathlib import Path
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/csharp-pending-02'
work.mkdir(exist_ok=False)
runtime = ROOT / 'internal/runtime'
patched = {}
name = 'glr.go'
s = (runtime / name).read_text(encoding='utf-8')
needle = '\tcRecoverMissingGroup *cRecGroup'
assert s.count(needle) == 1
s = s.replace(needle, needle + '\n\tcRecoverPendingToken *Token', 1)
needle = 'cRecoverMissingGroup:       s.cRecoverMissingGroup,'
assert s.count(needle) == 3
patched[name] = s.replace(needle, needle + '\n\t\tcRecoverPendingToken: s.cRecoverPendingToken,')
name = 'parser_recover_c.go'
s = (runtime / name).read_text(encoding='utf-8')
needle = '''\t\tmissingVersions[vi].cRecoverMissingGroup = group
\t\t*stacks = append(*stacks, missingVersions[vi])
\t\tneedsRedispatch = true'''
assert s.count(needle) == 1
patched[name] = s.replace(needle, '''\t\tmissingVersions[vi].cRecoverMissingGroup = group
\t\t// C resumes recovery at the end of a version round. Its next round
\t\t// advances the absorber before the newly created missing sibling.
\t\t// Queue this lookahead so the shared-token loop preserves that order.
\t\tmissingVersions[vi].cRecoverPendingToken = &tok
\t\tmissingVersions[vi].shifted = true
\t\t*stacks = append(*stacks, missingVersions[vi])''', 1)
name = 'parser.go'
s = (runtime / name).read_text(encoding='utf-8')
needle = '\t\tfor si := 0; si < numStacks || (packedVersionOrder && si < len(stacks)); si++ {'
assert s.count(needle) == 1
s = s.replace(needle, '''\t\tpendingDispatch := false
\t\tpendingSharedToken := Token{}
\t\tpendingSteps := 0
\t\tadvanceVersion := func(si int) int {
\t\t\tif !pendingDispatch { return si + 1 }
\t\t\ttok = pendingSharedToken
\t\t\tstackRelexActive = false
\t\t\tpendingDispatch = false
\t\t\ts := &stacks[si]
\t\t\tif s.dead || s.accepted || s.cPaused {
\t\t\t\ts.cRecoverPendingToken = nil
\t\t\t\treturn si + 1
\t\t\t}
\t\t\tif s.shifted {
\t\t\t\ts.cRecoverPendingToken = nil
\t\t\t\ts.shifted = false
\t\t\t}
\t\t\tpendingSteps++
\t\t\treturn si
\t\t}
\t\tfor si := 0; (si < numStacks || (packedVersionOrder && si < len(stacks))) && pendingSteps < maxConsecutivePrimaryReduces; si = advanceVersion(si) {''', 1)
needle = '\t\t\tif s.cRec != nil && p.errorCostCompetitionEnabled() {'
assert s.count(needle) == 1
s = s.replace(needle, '''\t\t\tif s.cRecoverPendingToken != nil {
\t\t\t\tpendingDispatch = true
\t\t\t\tpendingSharedToken = tok
\t\t\t\ttok = *s.cRecoverPendingToken
\t\t\t}
''' + needle, 1)
needle = '\t\t// The last stack in the loop may have dispatched on its own re-lexed'
assert s.count(needle) == 1
s = s.replace(needle, '''\t\tif pendingSteps >= maxConsecutivePrimaryReduces {
\t\t\treturn finalize(stacks, ParseStopIterationLimit)
\t\t}
''' + needle, 1)
patched[name] = s
mapping = {}
for name, code in patched.items():
    path = work / (name + '.txt')
    path.write_text(code, encoding='utf-8', newline='\n')
    subprocess.run(['gofmt', '-w', str(path)], check=True, env=ENV, timeout=20)
    mapping[str(runtime / name)] = str(path)
    original = (runtime / name).read_text(encoding='utf-8')
    fixed = path.read_text(encoding='utf-8')
    (work / (name + '.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True), fixed.splitlines(True), 'a/' + name, 'b/' + name)), encoding='utf-8', newline='\n')
overlay = work / 'overlay.json'
save(overlay, {'Replace': mapping})
exe = work / 'pending.exe'
run('03-csharp-pending/build', ['go', 'build', '-trimpath', '-overlay=' + str(overlay), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
prior = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in prior['rows']]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=120)
actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
rows = []
for row in prior['rows']:
    g = actual[row['id']]
    rows.append({'id': row['id'], 'source_sha256': row['source_sha256'],
                 'baseline_equal_c': row['baseline_equal_c'], 'pending_equal_c': g['Nodes'] == row['c']['nodes'],
                 'baseline_nodes': len(row['baseline']['Nodes']), 'pending_nodes': len(g['Nodes']),
                 'c_nodes': len(row['c']['nodes']), 'go': g})
    print(row['id'], rows[-1]['baseline_equal_c'], '->', rows[-1]['pending_equal_c'], len(g['Nodes']), len(row['c']['nodes']))
save(OUT / '03-csharp-pending/comparison.json', {
    'candidate_sha256': sha(exe.read_bytes()), 'input_receipt_sha256': sha((OUT / '03-csharp-order/comparison.json').read_bytes()),
    'overlays': {name: sha(Path(path).read_bytes()) for name, path in mapping.items()}, 'rows': rows})
