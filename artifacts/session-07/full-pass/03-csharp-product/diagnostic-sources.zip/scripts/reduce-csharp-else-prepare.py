from receipt import ROOT

s = (ROOT / '.scratch/full-pass/reduce-csharp-zero-identifier.py').read_text(encoding='utf-8')
s = s.replace('csharp-transaction-candidate/transaction.exe', 'csharp-hidden-missing-cost/candidate.exe')
s = s.replace('zero-identifier-reduction.json', 'else-declaration-reduction.json')
needle = "zero = lambda nodes: sum(n['Type'] == 'identifier' and n['StartByte'] == n['EndByte'] and not n['Missing'] for n in (nodes or []))"
assert s.count(needle) == 1
s = s.replace(needle, "zero = lambda nodes: sum(n['Type'] == 'identifier' and n['Field'] == 'type' and source[n['StartByte']:n['EndByte']] == 'else' for n in (nodes or []))")
s = s.replace('count_go > count_c', 'count_go < count_c')
(ROOT / '.scratch/full-pass/reduce-csharp-else.py').write_text(s, encoding='utf-8', newline='\n')
