from receipt import ROOT

s = (ROOT / '.scratch/full-pass/reduce-csharp-else.py').read_text(encoding='utf-8')
s = s.replace('import hashlib', 'import re\nimport hashlib')
needle = "original = next(r['source'] for r in prior if r['id'] == 'JsonTextReader-excerpt.cs')"
assert s.count(needle) == 1
s = s.replace(needle, "original = json.loads((OUT / '03-csharp-transaction-candidate/else-declaration-reduction.json').read_text(encoding='utf-8'))['best']['source']")
s = s.replace('parts = original.splitlines(keepends=True)', "parts = re.findall(r'\\w+|[^\\w]', original)")
s = s.replace("'else-declaration-reduction.json'", "'else-token-reduction.json'")
(ROOT / '.scratch/full-pass/reduce-csharp-else-tokens.py').write_text(s, encoding='utf-8', newline='\n')
