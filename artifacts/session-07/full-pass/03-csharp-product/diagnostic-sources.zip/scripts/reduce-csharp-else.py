import hashlib
import json
import subprocess
import time
from receipt import ROOT, OUT, ENV, save, sha

prior = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))['rows']
original = next(r['source'] for r in prior if r['id'] == 'JsonTextReader-excerpt.cs')
exe = ROOT / '.scratch/full-pass/csharp-hidden-missing-cost/candidate.exe'
oracle = ROOT / '.scratch/oracle/build-full-pass-v2/c_sharp.exe'
started = time.monotonic()
attempts, cache = [], {}
best = None

def observe(source):
    global best
    identity = sha(source.encode())
    if identity in cache:
        return cache[identity]
    if len(attempts) >= 400 or time.monotonic() - started > 300:
        return False
    request = [{'ID': 'reduce', 'Filename': 'x.cs', 'Source': source, 'Repeat': 1}]
    go = subprocess.run([str(exe)], input=json.dumps(request).encode(), env=ENV, capture_output=True, check=True, timeout=15)
    c = subprocess.run([str(oracle)], input=source.encode(), env=ENV, capture_output=True, check=True, timeout=15)
    g, native = json.loads(go.stdout), json.loads(c.stdout)
    zero = lambda nodes: sum(n['Type'] == 'identifier' and n['Field'] == 'type' and source[n['StartByte']:n['EndByte']] == 'else' for n in (nodes or []))
    count_go, count_c = zero(g['Nodes']), zero(native['nodes'])
    mismatch = g['Observations'][0]['Complete'] and count_go < count_c
    cache[identity] = mismatch
    attempts.append({'source_sha256': identity, 'bytes': len(source.encode()), 'go_zero': count_go, 'c_zero': count_c, 'retained': mismatch,
                     'go': g['Observations'][0], 'c_has_error': native['has_error']})
    if mismatch:
        best = {'source': source, 'source_sha256': identity, 'go': g, 'c': native}
        print('retained', len(source), 'after', len(attempts), 'attempts', flush=True)
    return mismatch

assert observe(original)
parts = original.splitlines(keepends=True)
granularity = 2
while len(parts) >= 2 and len(attempts) < 400 and time.monotonic() - started < 300:
    width = (len(parts) + granularity - 1) // granularity
    progress = False
    for start in range(0, len(parts), width):
        candidate = parts[:start] + parts[start + width:]
        if candidate and observe(''.join(candidate)):
            parts = candidate
            granularity = max(2, granularity - 1)
            progress = True
            break
    if progress:
        continue
    if granularity >= len(parts):
        break
    granularity = min(len(parts), granularity * 2)
save(OUT / '03-csharp-transaction-candidate/else-declaration-reduction.json', {
    'candidate_sha256': sha(exe.read_bytes()), 'oracle_sha256': sha(oracle.read_bytes()),
    'elapsed_seconds': time.monotonic() - started, 'attempts': attempts, 'best': best})
print(best['source'])
