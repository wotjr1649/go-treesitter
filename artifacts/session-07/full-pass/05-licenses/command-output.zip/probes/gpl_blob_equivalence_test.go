package gtsadapter

import (
	"os"
	"reflect"
	"testing"

	gts "github.com/wotjr1649/go-treesitter/internal/runtime"
)

func TestGPLBlobTableEquivalence(t *testing.T) {
	for _, name := range []string{"caddy", "disassembly", "jq"} {
		t.Run(name, func(t *testing.T) {
			load := func(path string) reflect.Value {
				data, err := os.ReadFile(path)
				if err != nil { t.Fatal(err) }
				language, err := gts.LoadLanguage(data)
				if err != nil { t.Fatal(err) }
				return reflect.ValueOf(language).Elem()
			}
			a := load("../../grammars/gpl/internal/gtsadapter/grammar_blobs/" + name + ".bin")
			b := load("../../.scratch/full-pass/gpl-source-reproduction-v2/generated/" + name + "/grammar_blobs/" + name + ".bin")
			for i := 0; i < a.NumField(); i++ {
				if a.Field(i).CanInterface() && !reflect.DeepEqual(a.Field(i).Interface(), b.Field(i).Interface()) {
					t.Errorf("decoded field differs: %s", a.Type().Field(i).Name)
				}
			}
		})
	}
}
