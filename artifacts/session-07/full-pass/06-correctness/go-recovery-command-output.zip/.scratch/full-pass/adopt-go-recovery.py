import difflib
import importlib.util
import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

path = 'grammars/runtime/runtime_profiles.go'
target = ROOT / 'internal/runtime' / path
old = target.read_text(encoding='utf-8')
candidate = ROOT / '.scratch/full-pass/go-edit-go-version-order' / path
subprocess.run(['gofmt', '-w', str(candidate)], env=ENV, check=True, timeout=20)
new = candidate.read_text(encoding='utf-8')
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), 'a/' + path, 'b/' + path))
patch_name = 'go-recovery-version-order.patch'
with (ROOT / 'tools/runtime-bundle/patches' / patch_name).open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(patch)
inventory = ROOT / 'tools/runtime-bundle/source.json'
data = json.loads(inventory.read_text(encoding='utf-8'))
data['patches'].append(patch_name)
inventory.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8', newline='\n')
import sys
sys.path.insert(0, str(ROOT / 'tools/runtime-bundle'))
spec = importlib.util.spec_from_file_location('bundle_import', ROOT / 'tools/runtime-bundle/import.py')
bundle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bundle)
output = ROOT / '.scratch/full-pass/go-recovery-product-runtime'
manifest = bundle.build(ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip', output)
old_manifest = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
assert old_manifest['files'].keys() == manifest['files'].keys()
for name, row in old_manifest['files'].items():
    assert sha((ROOT / 'internal/runtime' / name).read_bytes()) == row['sha256'], name
    if name != path:
        assert manifest['files'][name] == row, name
assert (output / path).read_bytes() == candidate.read_bytes()
target.write_bytes(candidate.read_bytes())
data = (json.dumps(manifest, indent=2)+'\n').encode()
(ROOT / 'internal/provenance/runtime.json').write_bytes(data)
identity = ROOT / 'internal/provenance/identities.json'
text = identity.read_text(encoding='utf-8')
old_hash = json.loads(text)['runtime']['manifest_sha256']
identity.write_text(text.replace(old_hash, sha(data)), encoding='utf-8', newline='\n')
optional = ROOT / 'grammars/gpl/provenance.json'
gpl = json.loads(optional.read_text(encoding='utf-8'))
gpl['runtime_manifest_sha256'] = sha(data)
optional.write_text(json.dumps(gpl, indent=2)+'\n', encoding='utf-8', newline='\n')
save(OUT / '06-correctness/go-recovery-adoption.json', {'runtime_manifest_sha256': sha(data),
    'before_manifest_sha256': old_hash, 'patch_sha256': sha(patch.encode()),
    'before_profile_sha256': sha(old.encode()), 'after_profile_sha256': sha(new.encode()),
    'reproduced_files': len(manifest['files'])})
print('Adopted Go recovery profile; reproduced', len(manifest['files']), 'runtime files.')
