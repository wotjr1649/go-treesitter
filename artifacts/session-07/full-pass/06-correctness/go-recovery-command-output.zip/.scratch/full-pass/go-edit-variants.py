import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

names = ['glr.go', 'parser.go', 'parser_recover_c.go', 'parser_reduce.go', 'parser_result.go',
         'parser_result_csharp.go', 'grammars/runtime/runtime_profiles.go']
before = '388f50cb156e13ff2aad0b32e69f102f422199d4'
for variant in ('before-csharp', 'go-version-order'):
    directory = ROOT / '.scratch/full-pass' / ('go-edit-' + variant)
    directory.mkdir(exist_ok=False)
    replacements = {}
    for name in names if variant == 'before-csharp' else [names[-1]]:
        origin = ROOT / 'internal/runtime' / name
        data = subprocess.check_output(['git', 'show', before + ':internal/runtime/' + name], cwd=ROOT) if variant == 'before-csharp' else origin.read_bytes()
        if variant == 'go-version-order':
            anchor = b'\t"go": {\n'
            assert data.count(anchor) == 1
            data = data.replace(anchor, anchor + b'\t\tcompactPackedGSSVersionOrder: true,\n', 1)
        destination = directory / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        replacements[str(origin)] = str(destination)
    save(directory / 'overlay.json', {'Replace': replacements})
    executable = directory / 'probe.exe'
    subprocess.run(['go', 'build', '-overlay=' + str(directory / 'overlay.json'), '-o', str(executable),
                    str(ROOT / '.scratch/full-pass/go_edit_probe.go')], cwd=ROOT, env=ENV, timeout=90, check=True)
    result = subprocess.run([str(executable)], env=ENV, timeout=20, capture_output=True, check=True)
    rows = [json.loads(line) for line in result.stdout.splitlines()]
    c = json.loads((OUT / '06-correctness/go-edit-diagnosis.json').read_text(encoding='utf-8'))['c']
    save(OUT / ('06-correctness/go-edit-' + variant + '.json'), {'variant': variant, 'baseline_commit': before,
         'overlay_files': {str(path): sha(open(backing, 'rb').read()) for path, backing in replacements.items()},
         'exe_sha256': sha(executable.read_bytes()), 'rows': rows})
    print(variant, [{'limits': bool(row['Limits']['MemoryBudgetBytes']), 'fresh_C': row['FreshNodes'] == c['nodes'],
                     'inc_C': row['IncNodes'] == c['nodes'], 'inc_fresh': row['IncNodes'] == row['FreshNodes']} for row in rows], flush=True)
