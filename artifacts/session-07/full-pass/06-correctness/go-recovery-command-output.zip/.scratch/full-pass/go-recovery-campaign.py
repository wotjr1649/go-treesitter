import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

cases = []
requests = []
for label, prefix, newline in [('plain', '', '\n'), ('leading', '\n', '\n'), ('comment', '// header\n', '\n'), ('crlf', '', '\r\n')]:
    old = prefix + ('package p\nvar café = 1\n').replace('\n', newline)
    old_id = 'GO-before-' + label
    cases.append({'id': old_id, 'language': 'go', 'filename': 'x.go', 'group': 'clean', 'source': old, 'sha256': sha(old.encode())})
    for suffix, insert in [('seed', '#i#000'), ('rename', '#z#111'), ('unicode', '#λ#1'),
                           ('at', '@i@000'), ('question', '?i?000'), ('long', '#i#000000')]:
        start = old.encode().index(b'package') + 6
        source = (old.encode()[:start] + insert.encode() + old.encode()[start+1:]).decode()
        case = {'id': 'GO-recovery-' + label + '-' + suffix, 'language': 'go', 'filename': 'x.go',
                'group': 'recovery-order', 'source': source, 'sha256': sha(source.encode()),
                'previous': old_id, 'edit': {'StartByte': start, 'OldEndByte': start+1, 'NewEndByte': start+len(insert.encode())}}
        cases.append(case)
        requests.append({'ID':case['id'], 'Filename':'x.go', 'Source':source, 'Repeat':20, 'Previous':old, 'Edit':case['edit']})
save(ROOT / 'testdata/oracle/go-recovery-cases.json', cases)
candidate = ROOT / '.scratch/full-pass/go-edit-go-version-order'
exe = candidate / 'campaign.exe'
subprocess.run(['go','build','-overlay='+str(candidate/'overlay.json'),'-o',str(exe),str(ROOT/'.scratch/full-pass/probe.go')],cwd=ROOT,env=ENV,timeout=90,check=True)
go = subprocess.run([str(exe)],input=json.dumps(requests,ensure_ascii=False).encode(),env=ENV,capture_output=True,timeout=90,check=True)
rows=[]
for request,line in zip(requests,go.stdout.splitlines(),strict=True):
    result=json.loads(line)
    cs=[]
    for _ in range(3):
        c=subprocess.run([str(ROOT/'.scratch/oracle/build-full-pass-v2/go.exe')],input=request['Source'].encode(),env=ENV,capture_output=True,timeout=10,check=True)
        cs.append(json.loads(c.stdout))
    rows.append({'id':request['ID'],'source':request['Source'],'source_sha256':sha(request['Source'].encode()),
        'go':result,'c':cs[0], 'c_deterministic':cs[0]==cs[1]==cs[2],
        'go_deterministic':all(o==result['Observations'][0] for o in result['Observations']),
        'fresh_C':result['Nodes']==cs[0]['nodes'], 'incremental_C':result['IncrementalNodes']==cs[0]['nodes']})
save(OUT/'06-correctness/go-recovery-candidate.json',{'exe_sha256':sha(exe.read_bytes()),'rows':rows})
failed=[r['id'] for r in rows if not all(r[k] for k in ('c_deterministic','go_deterministic','fresh_C','incremental_C'))]
print('Go recovery cases',len(rows),'passed',len(rows)-len(failed),'failed',failed)
assert not failed
