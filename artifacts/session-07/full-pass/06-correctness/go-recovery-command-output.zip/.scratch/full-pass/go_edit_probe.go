package main

import (
	"context"
	"encoding/json"
	"os"
	"time"

	treesitter "github.com/wotjr1649/go-treesitter"
	"github.com/wotjr1649/go-treesitter/syntax"
)

func main() {
	before := []byte("package p\nvar café = 1\n")
	after := []byte("packag#i#000 p\nvar café = 1\n")
	for _, limits := range []syntax.Limits{{}, {MaxSnapshotNodes:4096, MemoryBudgetBytes:64<<20, IterationLimit:20000, NodeLimit:20000, StackDepthLimit:256}} {
		p := treesitter.New()
		old, err := p.Parse(context.Background(), syntax.Request{Filename:"x.go", Source:before})
		if err != nil { panic(err) }
		inc, e1 := p.Parse(context.Background(), syntax.Request{Filename:"x.go", Source:after, Previous:old.Tree, Edit:&syntax.Edit{StartByte:6,OldEndByte:7,NewEndByte:12},Limits:limits,Timeout:time.Second})
		fresh, e2 := p.Parse(context.Background(), syntax.Request{Filename:"x.go",Source:after,Limits:limits,Timeout:time.Second})
		if e1 != nil || e2 != nil { panic("parse did not complete") }
		row := struct{ Limits syntax.Limits; Incremental, Fresh syntax.Diagnostics; IncNodes, FreshNodes []syntax.Node }{limits,inc.Diagnostics,fresh.Diagnostics,inc.Tree.Nodes(),fresh.Tree.Nodes()}
		if err:=json.NewEncoder(os.Stdout).Encode(row);err!=nil { panic(err) }
		inc.Tree.Close();fresh.Tree.Close();old.Tree.Close()
	}
}
