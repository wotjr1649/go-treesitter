package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"reflect"
	"time"

	treesitter "github.com/wotjr1649/go-treesitter"
	"github.com/wotjr1649/go-treesitter/syntax"
)

type input struct {
	ID, Filename, Source string
	Repeat               int
	Previous             *string
	Edit                 *syntax.Edit
}

type observation struct {
	Digest, Outcome, Stop, Route, Fallback, Reuse string
	Complete, Error, Missing                      bool
}

func observe(r syntax.Result) observation {
	var buffer bytes.Buffer
	encoder := json.NewEncoder(&buffer)
	encoder.SetEscapeHTML(false)
	var nodes []syntax.Node
	if r.Tree != nil {
		nodes = r.Tree.Nodes()
	}
	if err := encoder.Encode(nodes); err != nil {
		panic(err)
	}
	return observation{fmt.Sprintf("%x", sha256.Sum256(bytes.TrimSuffix(buffer.Bytes(), []byte{'\n'}))),
		string(r.Outcome), r.StopReason, r.Route, r.FallbackReason, r.ReuseReason,
		r.Complete(), r.HasError, r.HasMissing}
}

func main() {
	var inputs []input
	if err := json.NewDecoder(io.LimitReader(os.Stdin, 16<<20)).Decode(&inputs); err != nil {
		panic(err)
	}
	if len(inputs) > 200 {
		panic("too many cases")
	}
	parser := treesitter.New()
	for _, c := range inputs {
		if c.Repeat < 1 || c.Repeat > 100 || len(c.Source) > 4<<20 {
			panic("input outside probe bounds")
		}
		row := struct {
			ID               string
			Nodes            []syntax.Node
			Observations     []observation
			Incremental      *observation
			IncrementalNodes []syntax.Node
			IncrementalEqual bool
		}{ID: c.ID}
		for i := 0; i < c.Repeat; i++ {
			r, err := parser.Parse(context.Background(), syntax.Request{Filename: c.Filename,
				Source: []byte(c.Source), Timeout: 10 * time.Second})
			row.Observations = append(row.Observations, observe(r))
			if r.Tree != nil {
				if i == 0 {
					row.Nodes = r.Tree.Nodes()
				}
				r.Tree.Close()
			}
			if err != nil {
				break // Preserve the failure receipt; do not retry it away.
			}
		}
		if c.Previous != nil {
			old, err := parser.Parse(context.Background(), syntax.Request{Filename: c.Filename,
				Source: []byte(*c.Previous), Timeout: 10 * time.Second})
			if err != nil || !old.Complete() || old.Outcome != syntax.AcceptedClean {
				if old.Tree != nil {
					old.Tree.Close()
				}
				panic("initial incremental source is not clean")
			}
			inc, _ := parser.Parse(context.Background(), syntax.Request{Filename: c.Filename,
				Source: []byte(c.Source), Previous: old.Tree, Edit: c.Edit, Timeout: 10 * time.Second})
			o := observe(inc)
			row.Incremental = &o
			if inc.Tree != nil {
				row.IncrementalNodes = inc.Tree.Nodes()
				row.IncrementalEqual = inc.Complete() && reflect.DeepEqual(row.Nodes, row.IncrementalNodes)
				inc.Tree.Close()
			}
			old.Tree.Close()
		}
		encoder := json.NewEncoder(os.Stdout)
		encoder.SetEscapeHTML(false)
		if err := encoder.Encode(row); err != nil {
			panic(err)
		}
	}
}
