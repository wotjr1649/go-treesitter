"""Bounded, offline local checks; never overwrite a receipt."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/session-07/full-pass'
ENV = {k: v for k, v in os.environ.items() if k.upper() in
       ('SYSTEMROOT', 'WINDIR', 'COMSPEC', 'PATHEXT', 'PATH')}
ENV.update(CGO_ENABLED='0', GOENV='off', GOFLAGS='', GOWORK='off',
           GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off',
           GOMODCACHE=str(ROOT / '.scratch/modcache'),
           GOCACHE=str(ROOT / '.scratch/gocache'),
           GOTMPDIR=str(ROOT / '.scratch/tmp'),
           TEMP=str(ROOT / '.scratch/tmp'), TMP=str(ROOT / '.scratch/tmp'),
           PYTHONDONTWRITEBYTECODE='1', GOMAXPROCS='4')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def run(name, command, timeout=180, cwd=ROOT, env=None):
    path = OUT / (name + '.json')
    log = path.with_suffix('.log')
    if path.exists() or log.exists():
        raise ValueError('receipt already exists: ' + name)
    path.parent.mkdir(parents=True, exist_ok=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).decode()
    started = time.time()
    with log.open('xb') as stream:
        process = subprocess.Popen(command, cwd=cwd, env=env or ENV,
                                   stdout=stream, stderr=subprocess.STDOUT)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                           env=ENV, stdout=stream, stderr=subprocess.STDOUT,
                           timeout=15, check=False)
            process.wait(timeout=15)
            code = 'TIMEOUT'
    save(path, {'command': command, 'candidate_commit': head, 'status_before': status,
               'started_unix': started, 'elapsed_seconds': time.time() - started,
               'exit': code, 'cwd': str(cwd),
               'go': subprocess.check_output(['go', 'version'], env=ENV).decode().strip(),
               'environment': {k: (env or ENV)[k] for k in
                               ('CGO_ENABLED', 'GOMAXPROCS', 'GOPROXY', 'GOWORK')},
               'inputs': {p: sha((ROOT / p).read_bytes()) for p in
                          ('go.mod', 'go.sum', 'internal/provenance/identities.json')},
               'log_sha256': sha(log.read_bytes())})
    print(name, 'exit', code, 'elapsed', round(time.time() - started, 2), flush=True)
    if code != 0:
        print(log.read_text(encoding='utf-8', errors='replace')[-12000:], flush=True)
        raise RuntimeError(name + ' failed; original log preserved')


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[3:], timeout=int(sys.argv[2]))
