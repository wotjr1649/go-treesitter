"""Private-free public acquisition; never execute downloaded content."""
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

root = Path(__file__).resolve().parents[2]
destination = root / '.scratch/full-pass/additional-grammars'
destination.mkdir(exist_ok=False)
sources = [
    ('cobol', 'yutaro-sakamoto/tree-sitter-cobol', 'e99dbdc3d800d5fa2796476efd60af91f6b43d93'),
    ('caddyfile', 'caddyserver/tree-sitter-caddyfile', '4ef0479e11161ef4d1b4a89ae966eb1f5f11d764'),
]
paths = ['LICENSE', 'grammar.js', 'src/parser.c', 'src/scanner.c', 'src/tree_sitter/parser.h', 'src/tree_sitter/alloc.h', 'src/tree_sitter/array.h']
rows = []
for name, repository, commit in sources:
    for path in paths:
        url = 'https://raw.githubusercontent.com/' + repository + '/' + commit + '/' + path
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                data = response.read(64 * 1024 * 1024 + 1)
            if len(data) > 64 * 1024 * 1024:
                raise ValueError('public input exceeds acquisition limit')
        except urllib.error.HTTPError as error:
            if error.code != 404:
                raise
            rows.append({'name': name, 'url': url, 'status': 404})
            continue
        out = destination / name / path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        rows.append({'name': name, 'url': url, 'path': str(out.relative_to(root)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        print(name, path, len(data), flush=True)
with (destination / 'acquisition.json').open('x', encoding='utf-8', newline='\n') as file:
    json.dump(rows, file, indent=2)
    file.write('\n')
