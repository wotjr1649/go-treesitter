import base64
import hashlib
import io
from pathlib import Path
import tarfile
import urllib.request

url = 'https://registry.npmjs.org/tree-sitter-javascript/-/tree-sitter-javascript-0.23.1.tgz'
expected = '/bnhbrTD9frUYHQTiYnPcxyHORIw157ERBa6dqzaKxvR/x3PC4Yzd+D1pZIMS6zNg2v3a8BZ0oK7jHqsQo9fWA=='
destination = Path(__file__).resolve().parent / 'sources/typescript/node_modules/tree-sitter-javascript'
if destination.exists():
    raise ValueError('destination exists')
with urllib.request.urlopen(url, timeout=45) as response:
    data = response.read(16 * 1024 * 1024 + 1)
if len(data) > 16 * 1024 * 1024 or base64.b64encode(hashlib.sha512(data).digest()).decode() != expected:
    raise ValueError('archive identity mismatch')
selected = {}
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive:
        if member.name not in ('package/grammar.js', 'package/LICENSE', 'package/package.json'):
            continue
        if not member.isfile() or member.size > 256 * 1024 or member.name in selected:
            raise ValueError('invalid source member')
        selected[member.name] = archive.extractfile(member).read()
if len(selected) != 3:
    raise ValueError('incomplete source selection')
destination.mkdir(parents=True)
for name, content in selected.items():
    (destination / name.removeprefix('package/')).write_bytes(content)
print('tree-sitter-javascript 0.23.1 locked SHA-512 matched; three source files; no package scripts executed')
