import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import urllib.request
import zipfile

OUT = Path('artifacts/session-07/full-pass/05-licenses/acquisition')
OUT.mkdir(parents=True, exist_ok=True)
SOURCES = {
    'caddy': ('opa-oz/tree-sitter-caddy', '9b3fde99d3d74345b85b655a6d8065e004fbe26f'),
    'disassembly': ('ColinKennedy/tree-sitter-disassembly', '0229c0211dba909c5d45129ac784a3f4d49c243a'),
    'jq': ('nverno/tree-sitter-jq', '1e139eba1fd3a9c34a36f0f0f47ed8b73c9b4636'),
    'nim': ('alaviss/tree-sitter-nim', '9b4ede21a6ca866d29263f6b66c070961bc622b4'),
}
rows = []

def fetch(name, url, limit):
    request = urllib.request.Request(url, headers={'User-Agent': 'go-treesitter-license-inventory'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('source too large: ' + name)
    with (OUT / name).open('xb') as stream:
        stream.write(data)
    rows.append({'path': name, 'source': url, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return data

for name, (repo, commit) in SOURCES.items():
    data = fetch(name + '.zip', f'https://codeload.github.com/{repo}/zip/{commit}', 10 * 1024 * 1024)
    with zipfile.ZipFile(io.BytesIO(data)) as zipped:
        expanded = 0
        names = set()
        for item in zipped.infolist():
            path = PurePosixPath(item.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in str(path) or str(path).lower() in names:
                raise ValueError('unsafe/duplicate archive path')
            names.add(str(path).lower())
            expanded += item.file_size
        if expanded > 100 * 1024 * 1024:
            raise ValueError('expanded source exceeds budget')
        rows[-1]['members'] = len(names)
        rows[-1]['expanded_bytes'] = expanded

for name in ('MIT', 'ISC', 'Apache-2.0', 'LLVM-exception', 'GPL-3.0-only'):
    fetch(name + '.txt', 'https://raw.githubusercontent.com/spdx/license-list-data/main/text/' + name + '.txt', 131072)
fetch('eds-Cargo.toml', 'https://raw.githubusercontent.com/uyha/tree-sitter-eds/26d529e6cfecde391a03c21d1474eb51e0285805/Cargo.toml', 131072)
with (OUT / 'inventory.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(rows, stream, indent=2)
    stream.write('\n')
print('Acquired', len(rows), 'public source/notice files; no archive code executed.')
