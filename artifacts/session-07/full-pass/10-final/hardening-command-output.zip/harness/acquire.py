"""Fetch only the two public, immutable grammar archives needed for Candidate C."""
import hashlib
import io
from pathlib import Path, PurePosixPath
import tarfile
import urllib.request

root = Path(__file__).resolve().parent / 'sources'
for name, commit, expected in (
    ('typescript', '75b3874edb2dc714fb1fd77a32013d0f8699989f', '96ce4d1b513767d414bcca408efd9b49879162cceecdbed79a88e8ad2184f385'),
    ('javascript', '58404d8cf191d69f2674a8fd507bd5776f46cb11', 'f3e51e9f7b129f62a817551ae22a878dac5c18d71c456d5ad73e9c82d687f33d')):
    destination = root / name
    if destination.exists():
        raise ValueError('preserve existing sources')
    url = f'https://codeload.github.com/tree-sitter/tree-sitter-{name}/tar.gz/{commit}'
    with urllib.request.urlopen(url, timeout=45) as response:
        data = response.read(64 * 1024 * 1024 + 1)
    if len(data) > 64 * 1024 * 1024 or hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('archive size/hash mismatch')
    files, total = {}, 0
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        for count, member in enumerate(archive, 1):
            total += member.size
            if count > 20000 or total > 256 * 1024 * 1024:
                raise ValueError('archive exceeds limits')
            path = PurePosixPath(member.name)
            if path.is_absolute() or '..' in path.parts or '\\' in member.name or ':' in member.name:
                raise ValueError('unsafe path')
            if member.isdir():
                continue
            if not member.isfile():
                raise ValueError('non-regular member')
            relative = PurePosixPath(*path.parts[1:])
            if (relative.suffix not in ('.js', '.c', '.h', '.json') and
                    not relative.name.startswith('LICENSE')):
                continue
            target = (destination / relative).resolve()
            if not target.is_relative_to(destination.resolve()):
                raise ValueError('outside source root')
            key = str(relative).casefold()
            if key in files:
                raise ValueError('duplicate path')
            files[key] = (target, archive.extractfile(member).read())
    for target, content in files.values():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    print(name, commit, expected, len(files), flush=True)
