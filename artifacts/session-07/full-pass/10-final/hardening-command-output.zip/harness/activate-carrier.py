import json
from receipt import ROOT, sha

path = ROOT / 'internal/provenance/identities.json'
pins = json.loads(path.read_text(encoding='utf-8'))
pins['runtime'] = {'module': 'github.com/wotjr1649/go-treesitter/internal/runtime',
                   'manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes())}
path.write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8', newline='\n')
(ROOT / 'go.sum').write_bytes(b'')
p = ROOT / 'internal/gtsadapter/oracle_test.go'
s = p.read_text(encoding='utf-8').replace('github.com/odvcencio/gotreesitter', 'github.com/wotjr1649/go-treesitter/internal/runtime')
s = s.replace('\t"os/exec"\n', '')
s = s.replace('runOracleRecords(t, false)', 'runOracleRecords(t)').replace('runOracleCorpus(t, false,', 'runOracleCorpus(t,')
s = s.replace('// Candidate mode is called only by the opt-in oracle_experiment build-tag test.\n// Product tests always require the unmodified module and recorded differences.\n', '')
s = s.replace('func runOracleRecords(t *testing.T, candidate bool)', 'func runOracleRecords(t *testing.T)')
s = s.replace('runOracleCorpus(t, candidate,', 'runOracleCorpus(t,')
s = s.replace('func runOracleCorpus(t *testing.T, candidate bool,', 'func runOracleCorpus(t *testing.T,')
s = s.replace('"testdata/oracle/known-differences.json"', '"testdata/oracle/active-differences.json"')
start = s.index('\tctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)')
end = s.index('\tfor language, grammar := range pins.Grammars {', start)
s = s[:start] + '''\tif err := provenance.VerifyRuntime(root); err != nil {
\t\tt.Fatal(err)
\t}
\tt.Logf("runtime origin=%s manifest=%s", pins.Baseline.Version, pins.Runtime.ManifestSHA256)
''' + s[end:]
s = s.replace('filepath.Join(module.Dir, "grammars",', 'filepath.Join(root, "internal/runtime/grammars",')
s = s.replace('if candidate && c.Group == "KR-0001b" {', 'if c.Group == "KR-0001b" {')
s = s.replace('candidate does not correct the equals case', 'bundled scanner regressed on JSX equals text')
s = s.replace('} else if c.Group == "KR-0001a" || c.Group == "KR-0001b" || c.Group == "KR-0004" {', '} else if c.Group == "KR-0001a" || c.Group == "KR-0004" {')
start = s.index('\t\t\tif c.Group == "KR-0001b" {', s.index('bare ampersand characterization'))
end = s.index('\t\t\tif first >= 0 {', start)
s = s[:start] + s[end:]
p.write_text(s, encoding='utf-8', newline='\n')
old = ROOT / 'internal/gtsadapter/oracle_experiment_test.go'
s = old.read_text(encoding='utf-8')
s = s.removeprefix('//go:build oracle_experiment\n\n').replace('\t"flag"\n', '')
start = s.index('var oracleCandidate')
end = s.index('\tfor _, language :=', start)
s = s[:start] + 'func TestJSXEqualsEdits(t *testing.T) {\n' + s[end:]
s = s.replace('candidate incremental', 'JSX incremental')
new = ROOT / 'internal/gtsadapter/jsx_text_test.go'
assert not new.exists()
old.rename(new)
new.write_text(s, encoding='utf-8', newline='\n')
differences = json.loads((ROOT / 'testdata/oracle/known-differences.json').read_text(encoding='utf-8'))
differences = {k: v for k, v in differences.items() if v['Record'] != 'KR-0001b'}
(ROOT / 'testdata/oracle/active-differences.json').write_text(json.dumps(differences, indent=2) + '\n', encoding='utf-8', newline='\n')
for language in ('tsx', 'javascript'):
    for f in ('F4', 'F5'):
        record = json.loads((ROOT / f'testdata/oracle/windows-c-v2/base/{language}-{f}.json').read_text(encoding='utf-8'))
        print(language, f, 'C node count', len(record['nodes']))
