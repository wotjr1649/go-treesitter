import difflib
import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

runtime = ROOT / 'internal/runtime'
path = 'grammars/runtime/c_lexer.go'
original = (runtime / path).read_text(encoding='utf-8')
needle = '''	if target > len(ts.src) {
		target = len(ts.src)
	}

	ts.pending = nil'''
assert original.count(needle) == 1
replacement = '''	if target > len(ts.src) {
		target = len(ts.src)
	}
	// A reused leaf may end inside an already scanned string queue or at
	// the live cursor. Preserve the lexer state and discard only tokens
	// covered by the reused span. A cursor-only skip would lose #include
	// context; clearing the queue would lose the remaining string tokens.
	if target <= ts.cur.offset {
		next := 0
		for next < len(ts.pending) && ts.pending[next].EndByte <= uint32(target) {
			next++
		}
		if target == ts.cur.offset || (next < len(ts.pending) && ts.pending[next].StartByte == uint32(target)) {
			ts.pending = ts.pending[next:]
			return ts.Next()
		}
	}

	ts.pending = nil'''
changed = original.replace(needle, replacement)
patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), changed.splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path))
patch_name = 'catalog-c-family-lexer-reuse.patch'
(ROOT / 'tools/runtime-bundle/patches' / patch_name).write_text(patch, encoding='utf-8', newline='\n')
source_path = ROOT / 'tools/runtime-bundle/source.json'
source = json.loads(source_path.read_text(encoding='utf-8'))
assert source['patches'] == ['KR-0001b-jsx-text.patch']
source['patches'].append(patch_name)
source_path.write_text(json.dumps(source, indent=2) + '\n', encoding='utf-8', newline='\n')
out = ROOT / '.scratch/full-pass/c-family-adopted-runtime'
manifest_path = ROOT / '.scratch/full-pass/c-family-adopted-runtime.json'
run('04-catalog/c-family-reproduction', ['python', 'tools/runtime-bundle/import.py', '--archive',
    '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip', '--output', str(out), '--manifest', str(manifest_path)], timeout=90)
new_manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
old_manifest = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
assert set(new_manifest['files']) == set(old_manifest['files'])
differences = [name for name in new_manifest['files'] if new_manifest['files'][name] != old_manifest['files'][name]]
assert differences == [path]
(runtime / path).write_bytes((out / path).read_bytes())
(ROOT / 'internal/provenance/runtime.json').write_bytes(manifest_path.read_bytes())
pins_path = ROOT / 'internal/provenance/identities.json'
pins = pins_path.read_text(encoding='utf-8')
old_hash = sha(json.dumps(old_manifest, indent=2).encode() + b'\n')
assert pins.count(old_hash) == 1
pins_path.write_text(pins.replace(old_hash, sha(manifest_path.read_bytes())), encoding='utf-8', newline='\n')
save(OUT / '04-catalog/c-family-adoption.json', {'modified_runtime_files': differences,
    'old_manifest_sha256': old_hash, 'new_manifest_sha256': sha(manifest_path.read_bytes()), 'patch_sha256': sha(patch.encode())})
print('adopted one runtime file; exact archive reproduction retained')
