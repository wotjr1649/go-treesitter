"""Land the explicitly approved Candidate C's exact generated inputs."""
import json
from receipt import ROOT, OUT, save, sha

source = ROOT / '.scratch/full-pass/builds/candidate-c'
target = ROOT / 'testdata/oracle/typescript-patched'
if target.exists():
    raise ValueError('preserve existing inputs')
files = ['common/scanner.h', 'typescript/src/grammar.json', 'typescript/src/scanner.c',
         'tsx/src/grammar.json', 'tsx/src/scanner.c']
for name in files:
    p = target / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((source / name).read_bytes())
(target / 'upstream.patch').write_bytes((ROOT / '.scratch/full-pass/typescript-full.patch').read_bytes())
files.append('upstream.patch')
builds = json.loads((OUT / '01-candidate-c/builds.json').read_text())
save(target / 'manifest.json', {
    'schema': 1, 'base_grammar_commit': builds['grammar_commit'],
    'upstream_repository': 'github.com/odvcencio/gotreesitter',
    'upstream_patch_commit': builds['upstream_patch_commit'],
    'upstream_patch_path': 'grammars/patches/tree-sitter-typescript-import-type.patch',
    'upstream_patch_sha256': builds['upstream_patch_file_sha256'],
    'applied_in_full': True, 'generator_version': builds['generator_version'],
    'generator_sha256': builds['generator_sha256'],
    'javascript_base': builds['javascript_base'],
    'javascript_grammar_sha256': builds['javascript_grammar_sha256'],
    'licenses': ['LICENSES/tree-sitter-typescript.txt', 'LICENSES/tree-sitter-javascript.txt', 'LICENSES/gotreesitter.txt'],
    'files': {name: sha((target / name).read_bytes()) for name in files}})
path = ROOT / 'internal/provenance/identities.json'
pins = json.loads(path.read_text())
pins['oracle']['typescript_patch'] = {'commit': builds['upstream_patch_commit'],
    'sha256': builds['upstream_patch_file_sha256'], 'inputs_sha256': sha((target / 'manifest.json').read_bytes())}
path.write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8', newline='\n')
print('approved Candidate C inputs adopted; base runtime and grammar commits unchanged')
