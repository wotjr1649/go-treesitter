from receipt import ROOT

candidate=ROOT/'.scratch/full-pass/reuse-leaf-conflict/incremental.go'
s=candidate.read_text(encoding='utf-8')
needle='\t\taction := p.lookupAction(state, n.Symbol())'
assert s.count(needle)==1
s=s.replace(needle,'\t\t// Reuse must not choose one branch of a shift/reduce conflict.\n\t\t// Normal dispatch owns those reductions and competing versions.\n'+needle)
candidate.write_text(s,encoding='utf-8',newline='\n')
script=(ROOT/'.scratch/full-pass/adopt-long-lookahead.py').read_text(encoding='utf-8')
script=script.replace("path = 'parser_recover_c.go'", "path = 'incremental.go'")
script=script.replace('ts-long-lookahead','reuse-leaf-conflict').replace('recovery-variable-token-width.patch','incremental-leaf-conflict.patch')
script=script.replace('recovery-long-final-runtime','reuse-conflict-final-runtime').replace('recovery-long-adoption.json','reuse-conflict-adoption.json')
script=script.replace('Adopted variable-width recovery','Adopted conflict-safe leaf reuse')
exec(compile(script,'adopt-long-lookahead.py','exec'))
