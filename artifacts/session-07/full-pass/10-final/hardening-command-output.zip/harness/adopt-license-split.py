import hashlib
import json
from pathlib import Path
import shutil
from receipt import ROOT, OUT, save, sha

old = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
new = json.loads((ROOT / '.scratch/full-pass/gpl-separated-manifest.json').read_text(encoding='utf-8'))
for name, row in old['files'].items():
    assert sha((ROOT / 'internal/runtime' / name).read_bytes()) == row['sha256'], name
for name, row in new['files'].items():
    data = (ROOT / '.scratch/full-pass/gpl-separated-runtime' / name).read_bytes()
    assert sha(data) == row['sha256'], name
    if row['sha256'] != old['files'][name]['sha256']:
        (ROOT / 'internal/runtime' / name).write_bytes(data)
removed = sorted(old['files'].keys() - new['files'].keys())
assert len(removed) == 19 and all(name.startswith('grammars/') for name in removed)
for name in removed:
    target = (ROOT / 'internal/runtime' / name).resolve()
    target.relative_to(ROOT / 'internal/runtime/grammars')
    target.unlink()  # Exact files just validated against the committed carrier.
optional = ROOT / 'grammars/gpl/internal/gtsadapter'
assert not optional.exists()
shutil.copytree(ROOT / '.scratch/full-pass/gpl-separated-adapter', optional)
manifest = ROOT / 'internal/provenance/runtime.json'
shutil.copyfile(ROOT / '.scratch/full-pass/gpl-separated-manifest.json', manifest)
identities = ROOT / 'internal/provenance/identities.json'
before = identities.read_text(encoding='utf-8')
old_hash = json.loads(before)['runtime']['manifest_sha256']
identities.write_text(before.replace(old_hash, sha(manifest.read_bytes())), encoding='utf-8', newline='\n')
pack = ROOT / 'grammars/gpl'
notices = OUT / '02-product-runtime/catalog-notices'
shutil.copyfile(notices / 'caddy.txt', pack / 'LICENSE')
source = pack / 'sources'
source.mkdir(exist_ok=False)
for name in ('caddy', 'disassembly', 'jq'):
    shutil.copyfile(OUT / ('05-licenses/acquisition/' + name + '.zip'), source / (name + '.zip'))
    shutil.copyfile(notices / (name + '.txt'), source / (name + '-LICENSE.txt'))
save(OUT / '05-licenses/separation-adoption.json', {
    'old_manifest_sha256': old_hash, 'main_manifest_sha256': sha(manifest.read_bytes()),
    'main_files': len(new['files']), 'removed_main_files': removed,
    'optional_generated_files': {p.relative_to(optional).as_posix(): sha(p.read_bytes()) for p in sorted(optional.rglob('*')) if p.is_file()},
})
print('Main carrier', len(new['files']), 'files; separated', len(removed), 'GPL files.')
