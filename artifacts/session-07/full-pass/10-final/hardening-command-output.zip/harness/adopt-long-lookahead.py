import difflib
import importlib.util
import json
import subprocess
import sys
from receipt import ROOT, OUT, ENV, save, sha

path = 'parser_recover_c.go'
candidate = ROOT / '.scratch/full-pass/ts-long-lookahead' / path
new = candidate.read_text(encoding='utf-8')
new = new.replace('''//   - It requires the re-lexed token to cover exactly the shared token's byte
//     span. Same span means a stack that adopts it advances to the same offset
//     as every stack that took the shared token, so the versions stay in
//     lockstep and no caller has to reason about a ragged frontier.''', '''//   - Ordinary grammars require the same byte span. JS-family internal tokens
//     and stateless JSX text may split or extend it: the dispatch loop replays
//     a shorter token's remainder and skips already-consumed shared tokens for
//     a version that advanced farther. Stateful external tokens keep exact spans.''')
new = new.replace('''// JS-family recovery can split an internal token into shorter tokens.
	// The dispatch loop replays its remainder before advancing the shared
	// stream. Other grammars and external scanner tokens require exact spans.''', '''// JS-family versions can require a different token width (for example a
	// string fragment versus a number). Dispatch reconciles the byte frontier.
	// Other grammars and stateful external scanner tokens require exact spans.''')
candidate.write_text(new, encoding='utf-8', newline='\n')
subprocess.run(['gofmt', '-w', str(candidate)], env=ENV, check=True, timeout=20)
new = candidate.read_text(encoding='utf-8')
target = ROOT / 'internal/runtime' / path
old = target.read_text(encoding='utf-8')
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), 'a/'+path, 'b/'+path))
patch_name = 'recovery-variable-token-width.patch'
with (ROOT/'tools/runtime-bundle/patches'/patch_name).open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(patch)
inventory = ROOT/'tools/runtime-bundle/source.json'
data = json.loads(inventory.read_text(encoding='utf-8'))
data['patches'].append(patch_name)
inventory.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(ROOT/'tools/runtime-bundle'))
spec=importlib.util.spec_from_file_location('bundle_import',ROOT/'tools/runtime-bundle/import.py')
bundle=importlib.util.module_from_spec(spec);spec.loader.exec_module(bundle)
output=ROOT/'.scratch/full-pass/recovery-long-final-runtime'
manifest=bundle.build(ROOT/'.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip',output)
manifest_path=ROOT/'internal/provenance/runtime.json'
old_manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
assert old_manifest['files'].keys()==manifest['files'].keys()
for name,row in old_manifest['files'].items():
    assert sha((ROOT/'internal/runtime'/name).read_bytes())==row['sha256'],name
    if name!=path: assert row==manifest['files'][name],name
assert (output/path).read_bytes()==candidate.read_bytes()
target.write_bytes(candidate.read_bytes())
data=(json.dumps(manifest,indent=2)+'\n').encode()
manifest_path.write_bytes(data)
identity=ROOT/'internal/provenance/identities.json'
text=identity.read_text(encoding='utf-8')
old_hash=json.loads(text)['runtime']['manifest_sha256']
identity.write_text(text.replace(old_hash,sha(data)),encoding='utf-8',newline='\n')
optional=ROOT/'grammars/gpl/provenance.json'
text=optional.read_text(encoding='utf-8')
assert old_hash in text
optional.write_text(text.replace(old_hash,sha(data)),encoding='utf-8',newline='\n')
save(OUT/'06-correctness/recovery-long-adoption.json',dict(previous_runtime_manifest_sha256=old_hash,
    runtime_manifest_sha256=sha(data),patch_sha256=sha(patch.encode()),reproduced_files=len(manifest['files'])))
print('Adopted variable-width recovery; reproduced',len(manifest['files']),'files.')
