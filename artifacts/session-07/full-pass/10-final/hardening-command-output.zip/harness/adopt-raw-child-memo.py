from receipt import ROOT
script=(ROOT/'.scratch/full-pass/adopt-long-lookahead.py').read_text(encoding='utf-8')
script=script.replace("path = 'parser_recover_c.go'", "path = 'parser_reduce.go'")
script=script.replace('ts-long-lookahead','raw-child-memo').replace('recovery-variable-token-width.patch','recovery-raw-child-memo.patch')
script=script.replace('recovery-long-final-runtime','raw-child-final-runtime').replace('recovery-long-adoption.json','raw-child-adoption.json')
script=script.replace('Adopted variable-width recovery','Adopted shape-bound child cost reuse')
exec(compile(script,'adopt-long-lookahead.py','exec'))
