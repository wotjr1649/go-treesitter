"""Adopt the tested overlay through a reproducible, bounded source patch."""
import difflib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import zipfile
from receipt import ROOT, OUT, ENV, save, sha

candidate = ROOT / '.scratch/full-pass/jsx-shared-text-v3'
overlay = json.loads((candidate / 'overlay.json').read_text(encoding='utf-8'))['Replace']
old_manifest_path = ROOT / 'internal/provenance/runtime.json'
old_manifest = json.loads(old_manifest_path.read_text(encoding='utf-8'))
old_manifest_hash = sha(old_manifest_path.read_bytes())
for name, record in old_manifest['files'].items():
    assert sha((ROOT / 'internal/runtime' / name).read_bytes()) == record['sha256'], name

prepared = ROOT / '.scratch/full-pass/recovery-adoption'
prepared.mkdir()
new_files = {}
for target, origin in overlay.items():
    relative = Path(target).relative_to(ROOT / 'internal/runtime').as_posix()
    output = prepared / relative
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(Path(origin).read_bytes())
    new_files[relative] = output

# Formatting only: the reviewed executable's behavior is otherwise unchanged.
subprocess.run(['gofmt', '-w', *[str(p) for p in new_files.values() if p.suffix == '.go']],
               env=ENV, timeout=30, check=True)
patch = ''
for name, path in sorted(new_files.items()):
    if path.suffix != '.go':
        continue
    origin = subprocess.check_output(['git', 'show', 'HEAD:internal/runtime/' + name], cwd=ROOT).decode('utf-8')
    changed = path.read_text(encoding='utf-8')
    patch += ''.join(difflib.unified_diff(origin.splitlines(True), changed.splitlines(True), 'a/' + name, 'b/' + name))

# Git's native binary patch retains both original and replacement identities.
binary_work = prepared / 'binary-patch'
name = 'grammars/grammar_blobs/go.bin'
before = binary_work / 'a' / name
after = binary_work / 'b' / name
before.parent.mkdir(parents=True)
after.parent.mkdir(parents=True)
before.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:internal/runtime/' + name], cwd=ROOT))
after.write_bytes(new_files[name].read_bytes())
diff = subprocess.run(['git', 'diff', '--no-index', '--binary', '--no-prefix', 'a', 'b'],
                      cwd=binary_work, env=ENV, capture_output=True, timeout=30)
assert diff.returncode == 1 and diff.stdout.startswith(b'diff --git a/grammars/grammar_blobs/go.bin b/grammars/grammar_blobs/go.bin\n')
patch += diff.stdout.decode('ascii')
patch_path = ROOT / 'tools/runtime-bundle/patches/recovery-lookahead-and-eof.patch'
with patch_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(patch)

assets = ROOT / 'tools/runtime-bundle/grammars'
assets.mkdir()
source = ROOT / '.scratch/oracle/go/src/parser.c'
source_hash = sha(source.read_bytes())
build = json.loads((ROOT / '.scratch/oracle/build-full-pass-v2/build.json').read_text(encoding='utf-8'))
assert source_hash == build['grammars']['go']['parser_sha256']
archive = assets / 'go-source.zip'
files = {'src/parser.c': source.read_bytes(), 'LICENSE': (ROOT / '.scratch/oracle/go/LICENSE').read_bytes()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path, data in sorted(files.items()):
        item = zipfile.ZipInfo(path, (2026, 9, 23, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        zipped.writestr(item, data)
derived_manifest = assets / 'go.json'
pins = json.loads((ROOT / 'internal/provenance/identities.json').read_text(encoding='utf-8'))
save(derived_manifest, {
    'schema': 1, 'language': 'go', 'grammar_commit': pins['grammars']['go']['commit'],
    'origin_blob_sha256': pins['grammars']['go']['blob_sha256'],
    'product_blob_sha256': sha(after.read_bytes()), 'c_parser_sha256': source_hash,
    'source_archive': {'path': 'tools/runtime-bundle/grammars/go-source.zip', 'sha256': sha(archive.read_bytes()),
                       'files': {name: sha(data) for name, data in sorted(files.items())}},
    'converter': {'baseline': pins['baseline'], 'module_archive_sha256': old_manifest['archive_sha256'],
                  'package': 'cmd/ts2go', 'command': ['ts2go', '-input', 'src/parser.c', '-output', 'output/go.go', '-name', 'go']},
    'reproduction_evidence': 'artifacts/session-07/full-pass/06-correctness/go-c-tables-byte-reproduction.json'})

inventory = ROOT / 'tools/runtime-bundle/source.json'
data = json.loads(inventory.read_text(encoding='utf-8'))
assert data['patches'][-1] == 'go-recovery-shared-lookahead.patch'
data['patches'][-1] = patch_path.name
data['inputs'] = [{'path': str(p.relative_to(ROOT).as_posix()), 'sha256': sha(p.read_bytes())}
                  for p in [derived_manifest, archive]]
inventory.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

sys.path.insert(0, str(ROOT / 'tools/runtime-bundle'))
spec = importlib.util.spec_from_file_location('carrier', ROOT / 'tools/runtime-bundle/import.py')
carrier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(carrier)
output = ROOT / '.scratch/full-pass/recovery-final-runtime'
manifest = carrier.build(ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip', output)
assert manifest['files'].keys() == old_manifest['files'].keys()
for name in manifest['files']:
    expected = new_files[name].read_bytes() if name in new_files else (ROOT / 'internal/runtime' / name).read_bytes()
    assert (output / name).read_bytes() == expected, name
for name, path in new_files.items():
    (ROOT / 'internal/runtime' / name).write_bytes(path.read_bytes())
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
old_manifest_path.write_bytes(manifest_bytes)
pins['runtime']['manifest_sha256'] = sha(manifest_bytes)
pins['runtime']['grammar_blobs'] = {'go': sha(after.read_bytes())}
(ROOT / 'internal/provenance/identities.json').write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8', newline='\n')
optional = ROOT / 'grammars/gpl/provenance.json'
gpl = json.loads(optional.read_text(encoding='utf-8'))
gpl['runtime_manifest_sha256'] = sha(manifest_bytes)
optional.write_text(json.dumps(gpl, indent=2) + '\n', encoding='utf-8', newline='\n')
catalog_path = ROOT / 'LICENSES/catalog.json'
catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
row = next(row for row in catalog['rows'] if row['grammar'] == 'go')
assert row['blob_sha256'] == pins['grammars']['go']['blob_sha256']
row['origin_blob_sha256'] = row['blob_sha256']
row['blob_sha256'] = pins['runtime']['grammar_blobs']['go']
row['derived_artifact_manifest'] = 'tools/runtime-bundle/grammars/go.json'
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
save(OUT / '06-correctness/recovery-candidate-adoption.json', {
    'previous_runtime_manifest_sha256': old_manifest_hash, 'runtime_manifest_sha256': sha(manifest_bytes),
    'patch_sha256': sha(patch_path.read_bytes()), 'reproduced_files': len(manifest['files']),
    'changed_files': sorted(new_files), 'product_grammar': pins['runtime']['grammar_blobs'],
    'candidate_overlay_sha256': sha((candidate / 'overlay.json').read_bytes())})
print('Adopted and reproduced', len(manifest['files']), 'files;', len(new_files), 'changed runtime artifacts.')
