import json
import math
import re
import statistics as s
from receipt import OUT, save

allrows={}
for variant in ('baseline','candidate'):
    runs=[]
    for seed in range(1,6):
        rows={}
        for line in (OUT/'07-performance'/(variant+'-'+str(seed)+'.log')).read_text(encoding='utf-8').splitlines():
            m=re.match(r'^BenchmarkRelease/(\S+)-\d+\s+40\s+(.+)$',line)
            if m:
                fields=m[2].split()
                rows[m[1]]={fields[i+1]:float(fields[i]) for i in range(0,len(fields),2)}
        runs.append(rows)
    assert len(runs[0])==59 and all(r.keys()==runs[0].keys() for r in runs)
    allrows[variant]=runs
assert allrows['baseline'][0].keys()==allrows['candidate'][0].keys()
rows=[]
for name in allrows['baseline'][0]:
    metrics={}
    for metric in ('ns/op','B/op','allocs/op'):
        a=[r[name][metric] for r in allrows['baseline']]
        b=[r[name][metric] for r in allrows['candidate']]
        logratios=[math.log(y/x) for x,y in zip(a,b)] if all(a) and all(b) else []
        ci=[]
        if logratios:
            mean=s.mean(logratios);half=2.776445105*s.stdev(logratios)/math.sqrt(5)
            ci=[math.exp(mean-half),math.exp(mean+half)]
        metrics[metric]=dict(before=a,after=b,before_median=s.median(a),after_median=s.median(b),
                             median_ratio=s.median(b)/s.median(a) if s.median(a) else None,paired_log_t95=ci)
    rows.append(dict(name=name,metrics=metrics))
save(OUT/'07-performance/comparison.json',dict(samples=5,rows=rows,
    caveat='t interval assumes approximately normal paired log ratios; five-pair exact two-sided sign-test cannot yield p below 0.0625; measurements are local and finite'))
for row in sorted(rows,key=lambda r:r['metrics']['ns/op']['median_ratio'],reverse=True)[:16]:
    m=row['metrics']['ns/op'];a=row['metrics']['B/op']
    print(row['name'],'ns',round(m['before_median']),round(m['after_median']),'ratio',round(m['median_ratio'],3),'CI',[round(v,3) for v in m['paired_log_t95']],'B ratio',round(a['median_ratio'] or 0,3))
