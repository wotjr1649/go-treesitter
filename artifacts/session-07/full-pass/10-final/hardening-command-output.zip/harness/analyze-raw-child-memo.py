import json
import math
import statistics as s
from receipt import OUT, save

samples={v:{} for v in ('before','after')}
for v in samples:
    for seed in range(1,6):
        for line in (OUT/'10-final/performance'/f'raw-child-{v}-{seed}.log').read_text(encoding='utf-8').splitlines():
            if line.startswith('BenchmarkRelease/'):
                fields=line.split()
                key=fields[0].removeprefix('BenchmarkRelease/').rsplit('-',1)[0]
                assert fields[1]=='150'
                samples[v].setdefault(key,[]).append({fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)})
rows={}
for key in samples['before']:
    rows[key]={}
    for metric in ('ns/op','B/op','allocs/op'):
        a=[r[metric] for r in samples['before'][key]];b=[r[metric] for r in samples['after'][key]]
        assert len(a)==len(b)==5
        ratio=[math.log(y/x) for x,y in zip(a,b)]
        mean=s.mean(ratio);half=2.776445105*s.stdev(ratio)/math.sqrt(5)
        rows[key][metric]=dict(before=a,after=b,before_median=s.median(a),after_median=s.median(b),
            median_ratio=s.median(b)/s.median(a),paired_log_t95=[math.exp(mean-half),math.exp(mean+half)])
save(OUT/'10-final/performance/raw-child-comparison.json',dict(samples=5,rows=rows))
print(json.dumps(rows,indent=2))
