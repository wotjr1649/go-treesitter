from pathlib import Path
import zipfile
from receipt import ROOT, OUT, sha, save

names = [
    'eof-coverage-tests', 'cobol-completion-witness', 'cobol-baseline-check',
    'catalog-basic', 'catalog-diagnostics', 'catalog-after-fixes', 'catalog-retained-runner',
    'cobol-c-oracle', '04-catalog/build', '04-catalog/build-diagnostics',
    '04-catalog/build-after-fixes', '04-catalog/gofmt-diagnostics',
    '04-catalog/build-cobol-oracle', '04-catalog/cobol-baseline-witness',
]
target = OUT / '04-catalog/completion-command-output.zip'
entries = {}
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        path = OUT / (name + '.log')
        data = path.read_bytes()
        archive.writestr(name + '.log', data)
        entries[name + '.log'] = {'bytes': len(data), 'sha256': sha(data)}
with zipfile.ZipFile(target) as archive:
    for name, item in entries.items():
        assert sha(archive.read(name)) == item['sha256']
save(target.with_suffix('.json'), {'archive_sha256': sha(target.read_bytes()), 'entries': entries})
print('Preserved', len(entries), 'raw command logs')
