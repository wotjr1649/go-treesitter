import difflib
import json
from pathlib import Path
import subprocess
import zipfile
from receipt import ROOT, OUT, save, sha

target = OUT / '03-csharp-product/diagnostic-sources-v2.zip'
entries = {}
omitted = []
base_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    def put(name, data):
        archive.writestr(name, data)
        entries[name] = {'bytes': len(data), 'sha256': sha(data)}
    paths = list((ROOT / '.scratch/full-pass').glob('csharp-*.py'))
    paths += list((ROOT / '.scratch/full-pass').glob('reduce-csharp-*.py'))
    paths += [ROOT / '.scratch/full-pass' / name for name in ('pending-scheduler.py', 'pending-raw.py', 'adopt-kr2.py', 'adopt-kr4.py')]
    for path in sorted(set(paths)):
        put('scripts/' + path.name, path.read_bytes())
    original_files = {}
    for overlay_path in sorted((ROOT / '.scratch/full-pass').glob('csharp*/overlay.json')):
        overlay = json.loads(overlay_path.read_text(encoding='utf-8'))
        candidate = overlay_path.parent.name
        if candidate == 'csharp':
            omitted.append({'candidate': candidate, 'reason': 'Pre-bundle isolated runtime has a different base; source remains in its original scratch location and observations are retained.'})
            continue
        for original, backing in overlay['Replace'].items():
            relative = Path(original).resolve().relative_to(ROOT).as_posix()
            assert relative.startswith('internal/runtime/') or relative == 'internal/gtsadapter/adapter.go'
            replacement = Path(backing).resolve()
            replacement.relative_to(ROOT / '.scratch/full-pass')
            if relative not in original_files:
                original_files[relative] = subprocess.check_output(['git', 'show', base_commit + ':' + relative], cwd=ROOT)
            old, new = original_files[relative], replacement.read_bytes()
            patch = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), 'a/' + relative, 'b/' + relative)).encode()
            put(candidate + '/' + relative + '.patch', patch)
        put(candidate + '/source-hashes.json', json.dumps({Path(name).resolve().relative_to(ROOT).as_posix(): sha(Path(backing).read_bytes())
             for name, backing in overlay['Replace'].items()}, indent=2).encode())
save(target.with_suffix('.json'), {'base_commit': base_commit, 'archive_sha256': sha(target.read_bytes()), 'omitted': omitted, 'entries': entries})

target = OUT / '03-csharp-product/command-output.zip'
entries = {}
logs = []
for path in OUT.rglob('*.log'):
    relative = path.relative_to(OUT).as_posix()
    if relative.startswith(('03-', 'csharp-', 'kr2-', 'kr2-kr4-', 'adopt-kr2', 'adopt-kr4')):
        logs.append(path)
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(logs):
        data = path.read_bytes()
        name = path.relative_to(OUT).as_posix()
        archive.writestr(name, data)
        entries[name] = {'bytes': len(data), 'sha256': sha(data)}
save(target.with_suffix('.json'), {'archive_sha256': sha(target.read_bytes()), 'entries': entries})
for stem in ('diagnostic-sources-v2', 'command-output'):
    target = OUT / ('03-csharp-product/' + stem + '.zip')
    index = json.loads(target.with_suffix('.json').read_text(encoding='utf-8'))
    with zipfile.ZipFile(target) as archive:
        assert set(archive.namelist()) == index['entries'].keys()
        for name, record in index['entries'].items():
            assert sha(archive.read(name)) == record['sha256']
print('Archived candidate source patches and', len(logs), 'original command logs')
