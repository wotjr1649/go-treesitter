from pathlib import Path
import json
import zipfile
from receipt import ROOT, OUT, save, sha

selected={}
for path in OUT.rglob('*.log'):
    selected['logs/'+path.relative_to(OUT).as_posix()]=path
scratch=ROOT/'.scratch/full-pass'
for pattern in ('*.py','*.go','*.c'):
    for path in scratch.glob(pattern):
        selected['harness/'+path.name]=path
for path in scratch.rglob('*overlay*.json'):
    data=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict) or 'Replace' not in data:
        continue
    selected['harness/'+path.relative_to(scratch).as_posix()]=path
    for value in data['Replace'].values():
        if not value:
            continue
        target=Path(value).resolve()
        if target.is_relative_to(scratch) and target.is_file():
            selected['harness/'+target.relative_to(scratch).as_posix()]=target
unused=ROOT/'tools/runtime-bundle/patches/go-recovery-shared-lookahead.patch'
selected['superseded/go-recovery-shared-lookahead.patch']=unused
destination=OUT/'10-final/hardening-command-output.zip'
manifest={}
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(selected.items()):
        data=path.read_bytes()
        assert len(data)<32<<20,(name,len(data))
        archive.writestr(name,data)
        manifest[name]=dict(bytes=len(data),sha256=sha(data))
with zipfile.ZipFile(destination) as archive:
    for name,row in manifest.items():
        assert sha(archive.read(name))==row['sha256']
save(destination.with_suffix('.json'),dict(archive_sha256=sha(destination.read_bytes()),entries=manifest))
assert unused.resolve().is_relative_to(ROOT/'tools/runtime-bundle/patches')
unused.unlink()
print('preserved',len(manifest),'logs and harness sources;',destination.stat().st_size,'compressed bytes')
