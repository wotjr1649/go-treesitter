import subprocess
import zipfile
from receipt import ROOT, OUT, save, sha

paths = sorted(OUT.rglob('*.log')) + [OUT / '02-scanner/baseline.json', OUT / '02-scanner/scanner.json']
archive = OUT / '01-adoption/command-output.zip'
if archive.exists():
    raise ValueError('preserve existing archive')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for path in paths:
        zipped.write(path, path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as zipped:
    assert all(zipped.read(path.relative_to(OUT).as_posix()) == path.read_bytes() for path in paths)
save(OUT / '01-adoption/output-manifest.json', {'archive': archive.relative_to(OUT).as_posix(),
    'archive_sha256': sha(archive.read_bytes()),
    'files': {p.relative_to(OUT).as_posix(): sha(p.read_bytes()) for p in paths}})
# Only new task-owned staged evidence; all original files remain in place.
subprocess.run(['git', 'rm', '--cached', '--', *[p.relative_to(ROOT).as_posix() for p in paths]],
               cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
print('raw files retained locally and byte-checked in immutable ZIP:', len(paths))
