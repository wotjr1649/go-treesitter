import sys
from receipt import ROOT, ENV, run

build = '.scratch/oracle/build-full-pass-v2'
env = ENV | {'TREE_SITTER_CLI': str(ROOT / '.scratch/tools/tree-sitter.exe')}
run('01-adoption/build', [sys.executable, 'tools/native-oracle/run.py', 'build', '--output', build], timeout=240, env=env)
for catalog, name in (('cases.json', 'base'), ('extended-cases.json', 'extended'),
                      ('typescript-contextual-cases.json', 'ts-contextual'), ('csharp-recovery-cases.json', 'cs-recovery')):
    run('01-adoption/record-' + name, [sys.executable, 'tools/native-oracle/run.py', 'record',
        '--build', build, '--cases', 'testdata/oracle/' + catalog,
        '--output', 'testdata/oracle/windows-c-v2/' + name], timeout=90, env=env)
