"""Compare generated unpatched and fully patched C grammars at the same epoch."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

from receipt import ROOT, OUT, ENV, run, save, sha
sys.path.insert(0, str(ROOT / 'tools/native-oracle'))
from identity import identity
from run import source_locks

locks = source_locks()
work = ROOT / '.scratch/full-pass'
source = work / 'sources/typescript'
cli = ROOT / '.scratch/tools/tree-sitter.exe'
cli_receipt = json.loads((ROOT / 'artifacts/session-06/phase4/cli-acquisition.json').read_text())
assert sha(cli.read_bytes()) == cli_receipt['executable_sha256']
version = subprocess.check_output([str(cli), '--version'], env=ENV, timeout=10).decode().strip()
compiler = Path(shutil.which('gcc')).resolve()
compiler_version = subprocess.check_output([str(compiler), '--version'], env=ENV, timeout=10).decode().splitlines()[0]
patch = subprocess.check_output(['git', '-C', 'D:/AIDEV/_ref/gotreesitter', 'show',
    'c871b1f576866c40b1695677fe3512243e266d39:grammars/patches/tree-sitter-typescript-import-type.patch'])
patch_path = work / 'typescript-full.patch'
with patch_path.open('xb') as stream:
    stream.write(patch)
assert patch.count(b'diff --git ') == 2
assert b'diff --git a/common/define-grammar.js b/common/define-grammar.js' in patch
assert b'diff --git a/common/scanner.h b/common/scanner.h' in patch
runtime = ROOT / '.scratch/oracle/runtime/lib'
flags = json.loads((ROOT / 'internal/provenance/identities.json').read_text())['oracle']['build_flags']
builds = {}
for variant in ('regenerated-unpatched-c', 'candidate-c'):
    target = work / 'builds' / variant
    if target.exists():
        raise ValueError('preserve existing build')
    shutil.copytree(source, target)
    if variant == 'candidate-c':
        prefix = target.relative_to(ROOT).as_posix()
        run('01-candidate-c/patch-check', ['git', 'apply', '--check', '--directory=' + prefix, str(patch_path)])
        run('01-candidate-c/patch-apply', ['git', 'apply', '--directory=' + prefix, str(patch_path)])
    artifacts = {}
    for language in ('typescript', 'tsx'):
        grammar = target / language
        run('01-candidate-c/' + variant + '-' + language + '-generate',
            [str(cli), 'generate', '--abi', '15', '--js-runtime', 'node', 'grammar.js'],
            timeout=180, cwd=grammar)
        src = grammar / 'src'
        executable = target / (language + '.exe')
        command = [str(compiler), *flags, '-I' + str(runtime / 'include'),
            '-I' + str(runtime / 'src'), '-I' + str(src),
            '-DORACLE_LANGUAGE=tree_sitter_' + language,
            str(ROOT / 'tools/native-oracle/driver.c'), str(runtime / 'src/lib.c'),
            str(src / 'parser.c'), str(src / 'scanner.c'), '-o', str(executable)]
        run('01-candidate-c/' + variant + '-' + language + '-build', command, timeout=180)
        artifacts[language] = dict(identity(runtime / 'include/tree_sitter/api.h', src / 'parser.c', version),
            grammar_json_sha256=sha((src / 'grammar.json').read_bytes()),
            node_types_sha256=sha((src / 'node-types.json').read_bytes()),
            executable_sha256=sha(executable.read_bytes()), executable=str(executable.relative_to(ROOT)))
    builds[variant] = {'artifacts': artifacts,
        'define_grammar_sha256': sha((target / 'common/define-grammar.js').read_bytes()),
        'scanner_sha256': sha((target / 'common/scanner.h').read_bytes())}
save(OUT / '01-candidate-c/builds.json', {
    'project_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
    'runtime_commit': locks['runtime']['commit'], 'grammar_commit': locks['typescript']['commit'],
    'source_archive_sha256': locks['typescript']['archive_sha256'],
    'upstream_patch_commit': '24e1d3b2b4409ee2ffa63e88abba51a40060e76e',
    'upstream_patch_file_sha256': sha(patch), 'patch_applied_in_full': True,
    'generator_version': version, 'generator_sha256': sha(cli.read_bytes()),
    'javascript_base': json.loads((source / 'package-lock.json').read_text())['packages']['node_modules/tree-sitter-javascript'],
    'javascript_grammar_sha256': sha((source / 'node_modules/tree-sitter-javascript/grammar.js').read_bytes()),
    'compiler': compiler_version, 'compiler_sha256': sha(compiler.read_bytes()),
    'driver_sha256': sha((ROOT / 'tools/native-oracle/driver.c').read_bytes()),
    'flags': flags, 'os': 'windows', 'arch': 'amd64', 'builds': builds})
print('Both grammars generated and built for both variants; official oracle sources unchanged')
