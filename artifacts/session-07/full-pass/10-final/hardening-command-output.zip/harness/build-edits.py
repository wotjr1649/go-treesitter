import json
from pathlib import Path
import shutil
import sys
from receipt import ROOT, OUT, ENV, run, save, sha
sys.path.insert(0, str(ROOT / 'tools/native-oracle'))
from run import source_locks

source_locks()
work = ROOT / '.scratch/full-pass'
runtime = ROOT / '.scratch/oracle/runtime/lib'
compiler = str(Path(shutil.which('gcc')).resolve())
flags = json.loads((ROOT / 'internal/provenance/identities.json').read_text())['oracle']['build_flags']
records = {}
for variant in ('official-c', 'regenerated-unpatched-c', 'candidate-c'):
    for language, extension in (('typescript', 'ts'), ('tsx', 'tsx')):
        source = ((ROOT / '.scratch/oracle/typescript') if variant == 'official-c'
                  else work / 'builds' / variant) / language / 'src'
        exe = work / (variant + '-' + language + '-edit.exe')
        if exe.exists():
            raise ValueError('preserve existing binary')
        command = [compiler, *flags, '-I' + str(runtime / 'include'),
            '-I' + str(runtime / 'src'), '-I' + str(source),
            '-DORACLE_LANGUAGE=tree_sitter_' + language,
            str(ROOT / 'tools/native-oracle/driver.c'), str(runtime / 'src/lib.c'),
            str(source / 'parser.c'), str(source / 'scanner.c'), '-o', str(exe)]
        run('01-candidate-c/' + variant + '-' + language + '-edit-build', command, timeout=120)
        run('01-candidate-c/' + variant + '-' + language + '-edits',
            [sys.executable, 'tools/native-oracle/check_edits.py', '--executable', str(exe),
             '--cases', str(OUT / '01-candidate-c/cases.json'), '--filename', 'x.' + extension], timeout=60)
        records[variant + '/' + language] = {'executable_sha256': sha(exe.read_bytes()),
            'parser_sha256': sha((source / 'parser.c').read_bytes()),
            'driver_sha256': sha((ROOT / 'tools/native-oracle/driver.c').read_bytes())}
save(OUT / '01-candidate-c/edit-builds.json', records)
