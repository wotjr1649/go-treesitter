import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

names = ['cases.json', 'extended-cases.json', 'typescript-contextual-cases.json', 'csharp-recovery-cases.json']
folders = ['base', 'extended', 'ts-contextual', 'cs-recovery']
catalogs = {name: json.loads((ROOT / 'testdata/oracle' / name).read_text(encoding='utf-8')) for name in names}
cases = [case for values in catalogs.values() for case in values]
assert len(cases) == 94
by_id = {case['id']: case for case in cases}
requests = []
for case in cases:
    source = case.get('source')
    if source is None:
        source = (ROOT / case['path']).read_bytes().decode()
    assert sha(source.encode()) == case['sha256']
    request = {'ID': case['id'], 'Filename': case['filename'], 'Source': source,
               'Repeat': 100 if case['group'] in ('KR-0002', 'KR-0004') or case['id'] == 'CS-JsonTextReader-excerpt' else 20}
    if 'previous' in case:
        request.update(Previous=by_id[case['previous']]['source'], Edit=case['edit'])
    requests.append(request)
exe = ROOT / '.scratch/full-pass/bundled-probe.exe'
run('02-product-runtime/probe-build', ['go', 'build', '-trimpath', '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
output = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=300)
results = {r['ID']: r for r in map(json.loads, output.stdout.splitlines())}
save(OUT / '02-product-runtime/results.json', {'executable_sha256': sha(exe.read_bytes()), 'results': results})
candidate = json.loads((OUT / '02-scanner/scanner.json').read_text(encoding='utf-8'))['results']
rows = []
for name, folder in zip(names, folders):
    for case in catalogs[name]:
        current, previous = results[case['id']], candidate[case['id']]
        assert current == previous, 'carrier behavior changed: ' + case['id']
        c = json.loads((ROOT / 'testdata/oracle/windows-c-v2' / folder / (case['id'] + '.json')).read_text(encoding='utf-8'))
        nodes = current['Nodes']
        observations = current['Observations']
        assert all(o == observations[0] and o['Complete'] for o in observations)
        if 'previous' in case:
            assert current['IncrementalEqual']
        rows.append({'id': case['id'], 'source_sha256': case['sha256'], 'repeats': len(observations),
                     'equal_isolated_scanner': current == previous, 'equal_c': nodes == c['nodes'],
                     'digest': observations[0]['Digest'], 'outcome': observations[0]['Outcome'],
                     'incremental_equal': current['IncrementalEqual'] if 'previous' in case else None})
save(OUT / '02-product-runtime/campaign.json', {
    'runtime_manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes()),
    'rows': rows, 'cases': len(rows), 'equal_c': sum(r['equal_c'] for r in rows),
    'equal_isolated_scanner': sum(r['equal_isolated_scanner'] for r in rows), 'failures': []})
print('bundled carrier:', len(rows), 'unchanged from isolated scanner; C exact:', sum(r['equal_c'] for r in rows))
