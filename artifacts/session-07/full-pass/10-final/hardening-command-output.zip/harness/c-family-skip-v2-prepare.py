from receipt import ROOT

old = ROOT / '.scratch/full-pass/c-family-skip-candidate.py'
s = old.read_text(encoding='utf-8')
s = s.replace("c-family-skip'", "c-family-skip-v2'").replace('build-c-family-skip', 'build-c-family-skip-v2').replace('04-catalog/c-family-skip.json', '04-catalog/c-family-skip-v2.json')
needle = '''\t// A reused leaf has already been lexed. Advancing zero bytes must not
\t// erase its preprocessor state or queued string tokens.
\tif target == ts.cur.offset {
\t\treturn ts.Next()
\t}'''
replacement = '''\t// Reuse can stop inside the already scanned string token queue or at
\t// the live cursor. Consume only queued tokens covered by that span;
\t// resetting here would erase preprocessor state after a reused leaf.
\tif target == ts.cur.offset || (len(ts.pending) > 0 && target >= int(ts.pending[0].StartByte) && target < ts.cur.offset) {
\t\tfor len(ts.pending) > 0 && ts.pending[0].EndByte <= uint32(target) {
\t\t\tts.pending = ts.pending[1:]
\t\t}
\t\treturn ts.Next()
\t}'''
assert s.count(needle) == 1
s = s.replace(needle, replacement)
(ROOT / '.scratch/full-pass/c-family-skip-v2.py').write_text(s, encoding='utf-8', newline='\n')
