import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/c-family-skip-v2'
work.mkdir(exist_ok=False)
original = ROOT / 'internal/runtime/grammars/runtime/c_lexer.go'
s = original.read_text(encoding='utf-8')
needle = '''	if target > len(ts.src) {
		target = len(ts.src)
	}

	ts.pending = nil'''
assert s.count(needle) == 1
s = s.replace(needle, '''	if target > len(ts.src) {
		target = len(ts.src)
	}
	// Reuse can stop inside the already scanned string token queue or at
	// the live cursor. Consume only queued tokens covered by that span;
	// resetting here would erase preprocessor state after a reused leaf.
	if target == ts.cur.offset || (len(ts.pending) > 0 && target >= int(ts.pending[0].StartByte) && target < ts.cur.offset) {
		for len(ts.pending) > 0 && ts.pending[0].EndByte <= uint32(target) {
			ts.pending = ts.pending[1:]
		}
		return ts.Next()
	}

	ts.pending = nil''')
backing = work / 'c_lexer.go.txt'
backing.write_text(s, encoding='utf-8', newline='\n')
save(work / 'overlay.json', {'Replace': {str(original): str(backing)}})
exe = work / 'catalog.exe'
run('04-catalog/build-c-family-skip-v2-v2', ['go', 'build', '-trimpath', '-overlay=' + str(work / 'overlay.json'), '-o', str(exe), './tools/catalog'], timeout=120)
sources = [
    '#include <iostream>\nint main() { std::cout << 1; return 0; }\n',
    '#include <stdio.h>\nint main() { return 0; }\n',
    '#include "x.h"\nint x = 1;\n',
    '#define VALUE 1\nint x = VALUE;\n',
    '#define F(x) ((x)+1)\nint x = F(2);\n',
    '#if FLAG\nint x;\n#else\nint y;\n#endif\n',
    'const char *x = "one\\ntwo";\n',
    'int x = 1; /* ordinary */\n',
]
rows = []
for language in ('c', 'cpp'):
    for index, source in enumerate(sources):
        if language == 'c' and index == 0:
            continue
        process = subprocess.run([str(exe), '-language', language, '-repeat', '3'], input=source.encode(), env=ENV, capture_output=True, timeout=20)
        row = {'language': language, 'source': source, 'sha256': sha(source.encode()), 'exit': process.returncode, 'receipt': json.loads(process.stdout)}
        rows.append(row)
save(OUT / '04-catalog/c-family-skip-v2.json', {'overlay_sha256': sha(backing.read_bytes()), 'rows': rows})
for i, row in enumerate(rows):
    print(row['language'], i, row['exit'], row['receipt']['Errors'])
