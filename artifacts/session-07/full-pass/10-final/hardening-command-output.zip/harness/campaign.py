"""Re-execute the canonical 94 inputs, exact edit controls, and fixed repeats."""
import json
import subprocess
import zipfile
from receipt import ROOT, OUT, ENV, save, sha

work = ROOT / '.scratch/full-pass'
names = ['cases.json', 'extended-cases.json', 'typescript-contextual-cases.json', 'csharp-recovery-cases.json']
catalogs = {name: json.loads((ROOT / 'testdata/oracle' / name).read_text(encoding='utf-8')) for name in names}
cases = [case for values in catalogs.values() for case in values]
assert len(cases) == 94 and len({c['id'] for c in cases}) == 94
by_id = {c['id']: c for c in cases}
requests = []
for case in cases:
    source = case.get('source')
    if source is None:
        source = (ROOT / case['path']).read_bytes().decode()
    assert sha(source.encode()) == case['sha256']
    req = {'ID': case['id'], 'Filename': case['filename'], 'Source': source,
           'Repeat': 100 if case['group'] in ('KR-0002', 'KR-0004') or case['id'] == 'CS-JsonTextReader-excerpt' else 20}
    if 'previous' in case:
        req.update(Previous=by_id[case['previous']]['source'], Edit=case['edit'])
    requests.append(req)

archive = ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'
prefix = 'github.com/odvcencio/gotreesitter@v0.53.0/'
candidate = ROOT / '.scratch/kr0001b-candidate'
guard = b"\t\t\tif lexer.Lookahead() == '=' {\n\t\t\t\treturn false\n\t\t\t}\n"
with zipfile.ZipFile(archive) as z:
    original = {name[len(prefix):]: z.read(name) for name in z.namelist()}
actual = {p.relative_to(candidate).as_posix(): p for p in candidate.rglob('*') if p.is_file()}
assert actual.keys() == original.keys()
changes = {}
for name, before in original.items():
    after = actual[name].read_bytes()
    if before != after:
        assert name in ('grammars/runtime/javascript_scanner.go', 'grammars/runtime/tsx_scanner.go')
        assert before.count(guard) == 1 and before.replace(guard, b'') == after
        changes[name] = {'before': sha(before), 'after': sha(after)}
assert len(changes) == 2
save(OUT / '02-scanner/candidate-identity.json', {'archive_sha256': sha(archive.read_bytes()),
    'files': len(original), 'changes': changes})

product = {}
for variant in ('baseline', 'scanner'):
    exe = work / ('probe.exe' if variant == 'baseline' else 'scanner-probe.exe')
    p = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True,
                       env=ENV, timeout=300, check=True)
    results = {r['ID']: r for r in map(json.loads, p.stdout.splitlines())}
    assert set(results) == set(by_id)
    save(OUT / ('02-scanner/' + variant + '.json'), {'executable_sha256': sha(exe.read_bytes()), 'results': results})
    product[variant] = results

official = ROOT / '.scratch/oracle/build-01'
official_build = json.loads((official / 'build.json').read_text())
c_builds = json.loads((OUT / '01-candidate-c/builds.json').read_text())
known = {}
for name in ('known-differences.json', 'typescript-contextual-differences.json', 'csharp-recovery-differences.json'):
    known.update(json.loads((ROOT / 'testdata/oracle' / name).read_text()))
digest = lambda nodes: sha(json.dumps(nodes, ensure_ascii=False, separators=(',', ':')).encode())
rows, failures = [], []
for case, req in zip(cases, requests):
    lang, cid = case['language'], case['id']
    native = {}
    for variant in ('official-c', 'candidate-c'):
        if variant == 'candidate-c' and lang not in ('typescript', 'tsx'):
            native[variant] = native['official-c']
            continue
        artifact = (official_build['grammars'][lang] if variant == 'official-c'
                    else c_builds['builds']['candidate-c']['artifacts'][lang])
        exe = (official if variant == 'official-c' else ROOT) / artifact['executable']
        assert sha(exe.read_bytes()) == artifact['executable_sha256']
        native[variant] = json.loads(subprocess.run([str(exe)], input=req['Source'].encode(),
             capture_output=True, check=True, env=ENV, timeout=15).stdout)
    a, b = product['baseline'][cid], product['scanner'][cid]
    old_c, new_c = native['official-c']['nodes'], native['candidate-c']['nodes']
    for variant, g in (('baseline', a), ('scanner', b)):
        if len(g['Observations']) != req['Repeat'] or not all(o == g['Observations'][0] and o['Complete'] for o in g['Observations']):
            failures.append([cid, variant, 'determinism/completion'])
        if 'Previous' in req and not g['IncrementalEqual']:
            failures.append([cid, variant, 'incremental/fresh'])
    if cid in known:
        k = known[cid]
        if (case['sha256'], digest(a['Nodes']), digest(old_c)) != (k['Source'], k['GoDigest'], k['CDigest']):
            failures.append([cid, 'known signature changed'])
    elif a['Nodes'] != old_c:
        failures.append([cid, 'new baseline/original C mismatch'])
    if case['group'] == 'KR-0001b':
        if b['Nodes'] != old_c or b['Observations'][0]['Outcome'] != 'accepted_clean':
            failures.append([cid, 'scanner correction failed'])
    elif a['Nodes'] != b['Nodes'] or a['Observations'][0] != b['Observations'][0]:
        failures.append([cid, 'scanner changed control'])
    if case['group'] == 'KR-0003':
        if a['Nodes'] != new_c:
            failures.append([cid, 'full TypeScript patch does not agree'])
    elif old_c != new_c:
        failures.append([cid, 'TypeScript patch changed control'])
    row = {'id': cid, 'source_sha256': case['sha256'], 'repeats': req['Repeat'],
        'baseline_digest': digest(a['Nodes']), 'scanner_digest': digest(b['Nodes']),
        'official_c_digest': digest(old_c), 'candidate_c_digest': digest(new_c),
        'baseline_outcome': a['Observations'][0]['Outcome'], 'scanner_outcome': b['Observations'][0]['Outcome'],
        'incremental': a['IncrementalEqual'] if 'Previous' in req else None,
        'baseline_c_equal': a['Nodes'] == old_c, 'scanner_patched_c_equal': b['Nodes'] == new_c}
    rows.append(row)
save(OUT / '02-scanner/comparison.json', {'catalog_hashes': {n: sha((ROOT / 'testdata/oracle' / n).read_bytes()) for n in names},
    'rows': rows, 'failures': failures})
print('cases', len(rows), 'edits', sum(r['incremental'] is not None for r in rows),
      'original C equality', sum(r['baseline_c_equal'] for r in rows),
      'scanner + patched C equality', sum(r['scanner_patched_c_equal'] for r in rows),
      'failures', len(failures), flush=True)
if failures:
    raise RuntimeError(str(failures))
