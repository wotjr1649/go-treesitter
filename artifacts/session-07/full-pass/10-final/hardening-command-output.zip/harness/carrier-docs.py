from receipt import ROOT

p = ROOT / 'docs/specs/baseline-provenance.md'
s = p.read_text(encoding='utf-8')
s = s.replace('**Scope limitation carried by this baseline.** It does not satisfy Release-Critical correctness for\nJSX and TSX.', '**Source origin, not product identity.** The original unmodified runtime does not satisfy\nRelease-Critical correctness for JSX and TSX. The owner-approved internal carrier applies\nseparately identified patches (ADR-0013); its origin remains this baseline.')
s = s.replace('provenance_test.go  # asserts the resolved module matches the file', 'provenance_test.go  # asserts the source carrier and binary identity')
anchor = '## Identity rules\n'
assert anchor in s
s = s.replace(anchor, '''## Internal carrier

The product compiles `internal/runtime`, not a replaced external module.
`identities.json.runtime` records the internal import path and the SHA-256 of
`internal/provenance/runtime.json`. That manifest binds the exact original
archive, source inventory, import relocation tool, patch inventory and every
original/resulting file. The original grammar blob hashes above remain unchanged.
Changing the carrier requires regenerating and reviewing this identity, then
rerunning its affected checks. This is distinct from changing the upstream origin.
See ADR-0013 and `tools/runtime-bundle/README.md` for reproduction and retirement.

''' + anchor)
p.write_text(s, encoding='utf-8', newline='\n')
p = ROOT / 'docs/design/overview.md'
s = p.read_text(encoding='utf-8')
s = s.replace('the ONLY package that imports github.com/odvcencio/gotreesitter', 'the ONLY importer outside the internal runtime carrier')
s = s.replace('gotreesitter v0.53.0  (pinned; see docs/specs/baseline-provenance.md)', 'internal/runtime  (pinned origin + approved patches; ADR-0013)')
s = s.replace('maps gotreesitter state -> syntax.Result. The only importer of upstream.', 'maps runtime state -> syntax.Result. The only external carrier importer.\n  runtime/             identified upstream production sources + approved patches')
s = s.replace('`github.com/odvcencio/gotreesitter`. Enforce', '`internal/runtime` from outside that carrier. Enforce')
s = s.replace('The upstream module graph already guarantees this — upstream confines CGO to a\n   separate module — and we must not reintroduce it.', 'The carrier contains only Go product sources; graph and consumer checks must\n   keep C-dependent packages outside the product.')
start = s.index('## What changes if a fork ever happens')
s = s[:start] + '''## Runtime distribution

The owner-approved internal carrier distributes the tested patches as part of
the ordinary Go module. It uses no consumer replace directive or runtime backend
selector. Its source/patch manifest, import boundary and lifecycle are described
in ADR-0013. The first project version will be `v0.0.1`; a version plan does not
establish release readiness.
'''
p.write_text(s, encoding='utf-8', newline='\n')
p = ROOT / 'docs/reports/release-critical-status.md'
s = p.read_text(encoding='utf-8')
s = s.replace('Last updated: 2026-09-22', 'Last updated: 2026-09-23')
s = s.replace('| JSX | green, ratcheted | **red** | KR-0001b `=` defect remains in the product runtime. |', '| JSX | green | not fully assessed | KR-0001b retired in the approved internal runtime; fresh/edit C comparisons pass. |')
s = s.replace('| TSX | green, ratcheted | **red** | KR-0001b remains; KR-0003 is retired. |', '| TSX | green | not fully assessed | KR-0001b and KR-0003 retired; full release assessment pending. |')
start = s.index('Prefer an upstream contribution')
end = s.index('\nUpdate this board', start)
s = s[:start] + '''The owner approved an internal carrier of the pinned runtime with minimal fixes,
documented in ADR-0013. KR-0001b is now applied to the product and a fresh
94-input campaign matches the isolated scanner candidate in every observation;
86 exact C trees, six preserved bare-ampersand recovery shapes and two C#
regressions remain. The external consumer installs a local `v0.0.1` module ZIP
without replace. The initial release version is `v0.0.1`, not a release claim.
KR-0002 and KR-0004 still require correction and independent evidence. TypeScript
full-patch adoption is recorded in ADR-0012. No remote write or release was made.
''' + s[end:]
p.write_text(s, encoding='utf-8', newline='\n')
