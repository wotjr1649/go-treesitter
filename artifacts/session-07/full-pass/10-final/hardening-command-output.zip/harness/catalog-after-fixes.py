from concurrent.futures import ThreadPoolExecutor
import json
import subprocess
from receipt import ROOT, OUT, ENV, save, run, sha

cases_path = OUT / '04-catalog/cases.json'
cases = json.loads(cases_path.read_text(encoding='utf-8'))['cases']
assert len(cases) == 206 and len({c['language'] for c in cases}) == 206
exe = ROOT / '.scratch/full-pass/catalog-after-fixes.exe'
run('04-catalog/build-after-fixes', ['go', 'build', '-trimpath', '-o', str(exe), './tools/catalog'], timeout=120)

def check(case):
    assert sha(case['source'].encode()) == case['sha256']
    result = subprocess.run([str(exe), '-language', case['language'], '-repeat', '3'], input=case['source'].encode(),
                            capture_output=True, env=ENV, timeout=30, check=False)
    return {'language': case['language'], 'source_sha256': case['sha256'], 'exit': result.returncode, 'receipt': json.loads(result.stdout)}

with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(check, cases))
save(OUT / '04-catalog/after-fixes.json', {'executable_sha256': sha(exe.read_bytes()),
    'cases_sha256': sha(cases_path.read_bytes()),
    'runtime_manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes()),
    'adapter_sha256': sha((ROOT / 'internal/gtsadapter/adapter.go').read_bytes()),
    'completion_sha256': sha((ROOT / 'syntax/result.go').read_bytes()),
    'repeats': 3, 'parallel_processes': 2, 'rows': rows})
print('catalog cases', len(rows), 'pass', sum(r['exit'] == 0 for r in rows))
for row in rows:
    if row['exit']:
        print(row['language'], row['receipt'])
if any(r['exit'] for r in rows):
    raise RuntimeError('catalog failures recorded')
