from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import re
import subprocess
from receipt import ROOT, OUT, ENV, save, run, sha

samples_file = ROOT / 'internal/runtime/grammars/smoke_samples.go'
samples = {name: json.loads(value) for name, value in re.findall(r'^\s*"([a-z0-9_]+)":\s*("(?:\\.|[^"\\])*"),', samples_file.read_text(encoding='utf-8'), re.M)}
grammars = sorted(p.stem for p in (ROOT / 'internal/runtime/grammars/grammar_blobs').glob('*.bin'))
assert len(grammars) == 206
missing = set(grammars) - samples.keys()
if missing:
    raise ValueError('missing authored smoke samples: ' + str(sorted(missing)))
catalog = [{'language': name, 'source': samples[name], 'sha256': sha(samples[name].encode())} for name in grammars]
save(OUT / '04-catalog/cases.json', {'origin': 'gotreesitter v0.53.0 ParseSmokeSamples', 'origin_sha256': sha(samples_file.read_bytes()), 'cases': catalog})
exe = ROOT / '.scratch/full-pass/catalog.exe'
run('04-catalog/build', ['go', 'build', '-trimpath', '-o', str(exe), './tools/catalog'], timeout=120)


def check(case):
    result = subprocess.run([str(exe), '-language', case['language'], '-repeat', '3'], input=case['source'].encode(),
                            capture_output=True, env=ENV, timeout=30, check=False)
    try:
        output = json.loads(result.stdout)
    except ValueError:
        output = {'errors': ['invalid output'], 'stderr': result.stderr.decode(errors='replace')[:2000]}
    return {'language': case['language'], 'source_sha256': case['sha256'], 'exit': result.returncode, 'receipt': output}


with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(check, catalog))
save(OUT / '04-catalog/comparison.json', {'executable_sha256': sha(exe.read_bytes()),
    'runtime_manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes()),
    'repeats': 3, 'parallel_processes': 2, 'rows': rows})
print('catalog cases', len(rows), 'pass', sum(r['exit'] == 0 for r in rows))
for row in rows:
    if row['exit']:
        print(row['language'], row['receipt'])
if any(r['exit'] for r in rows):
    raise RuntimeError('catalog failures recorded')
