import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

run('04-catalog/gofmt-diagnostics', ['gofmt', '-w', 'tools/catalog/main.go'], timeout=30)
exe = ROOT / '.scratch/full-pass/catalog-diagnostics.exe'
run('04-catalog/build-diagnostics', ['go', 'build', '-trimpath', '-o', str(exe), './tools/catalog'], timeout=120)
cases = json.loads((OUT / '04-catalog/cases.json').read_text(encoding='utf-8'))['cases']
for case in cases:
    if case['language'] not in ('cpp', 'cobol'):
        continue
    p = subprocess.run([str(exe), '-language', case['language'], '-repeat', '1'], input=case['source'].encode(),
                       capture_output=True, env=ENV, timeout=30, check=False)
    output = json.loads(p.stdout)
    save(OUT / ('04-catalog/diagnostics-' + case['language'] + '.json'),
         {'source': case['source'], 'source_sha256': case['sha256'], 'exit': p.returncode, 'receipt': output})
    print(case['language'], output['FailureDiagnostics'])
    a, b = output['EditIncremental'], output['EditFresh']
    if a is not None and b is not None:
        print('node counts', len(a), len(b))
        for i in range(min(len(a), len(b))):
            if a[i] != b[i]:
                print('first difference', i, a[i], b[i])
                break
