import json
import urllib.request
from receipt import OUT, save, sha

folder = OUT / '02-product-runtime/catalog-notices'
targets = [('ebnf', 'RubixDev/ebnf', '8e635b0b723c620774dfb8abf382a7f531894b40'),
           ('eds', 'uyha/tree-sitter-eds', '26d529e6cfecde391a03c21d1474eb51e0285805')]
results = []
for grammar, repo, commit in targets:
    url = f'https://api.github.com/repos/{repo}/git/trees/{commit}?recursive=1'
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'public-license-audit'}), timeout=15) as response:
        raw = response.read(2_000_001)
    assert len(raw) <= 2_000_000
    data = json.loads(raw)
    assert not data.get('truncated')
    paths = [r['path'] for r in data['tree'] if r['type'] == 'blob' and
             any(s in r['path'].lower() for s in ('license', 'licence', 'copying', 'notice', 'cargo.toml', 'readme'))]
    results.append({'grammar': grammar, 'source': url, 'tree_sha': data['sha'], 'paths': paths})
    print(grammar, paths)
save(folder / 'final-path-search.json', results)
for filename in ('LICENSE', 'Cargo.toml', 'package.json'):
    url = 'https://raw.githubusercontent.com/RubixDev/ebnf/8e635b0b723c620774dfb8abf382a7f531894b40/crates/tree-sitter-ebnf/' + filename
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            raw = response.read(100_001)
        assert len(raw) <= 100_000
        path = folder / 'additional' / ('ebnf-' + filename)
        with path.open('xb') as stream:
            stream.write(raw)
        save(path.with_name(path.name + '.receipt.json'), {'source': url, 'sha256': sha(raw)})
        print(filename, raw.decode()[:700])
    except urllib.error.HTTPError as error:
        print(filename, error.code)
