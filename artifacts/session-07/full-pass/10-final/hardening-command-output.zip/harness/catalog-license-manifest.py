import json
from pathlib import Path
import shutil
from receipt import ROOT, OUT, save, sha

base = OUT / '02-product-runtime/catalog-notices'
acquired = OUT / '05-licenses/acquisition'
inventory = json.loads((base / 'inventory.json').read_text(encoding='utf-8'))['rows']
extra = json.loads((base / 'additional/inventory.json').read_text(encoding='utf-8'))
gpl = {'caddy', 'disassembly', 'jq'}
declared = {'authzed': 'MIT', 'brightscript': 'ISC', 'cooklang': 'ISC', 'corn': 'MIT',
            'eex': 'MIT', 'elsa': 'MIT', 'facility': 'MIT', 'tmux': 'MIT', 'eds': 'MIT'}
extra_names = {'clojure': 'clojure-COPYING.txt', 'janet': 'janet-COPYING.txt', 'vhdl': 'vhdl-License.md'}
rows = []

def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise ValueError('notice already exists: ' + str(target))
    shutil.copyfile(source, target)
    return {'path': target.relative_to(ROOT).as_posix(), 'sha256': sha(target.read_bytes())}

def classify(data):
    text = data.decode().lower()
    if 'permission is hereby granted, free of charge' in text: return 'MIT'
    if 'apache' in text: return 'Apache-2.0 WITH LLVM-exception' if 'llvm-exception' in text else 'Apache-2.0'
    if 'mozilla public license' in text: return 'MPL-2.0'
    if 'gnu general public license' in text: return 'GPL-3.0'
    if 'creative commons' in text: return 'CC0-1.0'
    if 'unlicense' in text: return 'Unlicense'
    if 'do what the fuck' in text: return 'WTFPL'
    if 'permission to use, copy, modify' in text: return 'ISC'
    raise ValueError('unclassified notice')

for entry in sorted(inventory, key=lambda row: row['grammar']):
    name = entry['grammar']
    distribution = 'gpl' if name in gpl else 'main'
    target_dir = ROOT / ('grammars/gpl/LICENSES' if distribution == 'gpl' else 'LICENSES/grammars')
    if 'path' in entry:
        origin = base / entry['path']
        source = entry['source']
        mode = 'original_notice'
    elif name in extra_names:
        row = next(r for r in extra if r['path'] == extra_names[name])
        origin, source, mode = base / 'additional' / row['path'], row['source'], 'original_notice'
    elif name == 'ebnf':
        origin = base / 'additional/ebnf-LICENSE'
        receipt = json.loads(origin.with_suffix('.receipt.json').read_text(encoding='utf-8'))
        source = receipt.get('source', receipt.get('url'))
        assert source
        mode = 'original_notice'
    elif name == 'eds':
        origin = acquired / 'eds-Cargo.toml'
        source = 'https://raw.githubusercontent.com/uyha/tree-sitter-eds/' + entry['commit'] + '/Cargo.toml'
        mode = 'spdx_declaration'
    else:
        row = next(r for r in extra if r['grammar'] == name and r.get('declared_license'))
        origin, source, mode = base / 'additional' / row['path'], row['source'], 'spdx_declaration'
    license_id = declared[name] if mode == 'spdx_declaration' else classify(origin.read_bytes())
    if name == 'jq': license_id = 'GPL-3.0-or-later'
    suffix = '.json' if origin.suffix == '.json' else '.toml' if origin.suffix == '.toml' else '.txt'
    notice = copy(origin, target_dir / (name + suffix))
    blob = ROOT / ('grammars/gpl/internal/gtsadapter/grammar_blobs' if distribution == 'gpl' else 'internal/runtime/grammars/grammar_blobs') / (name + '.bin')
    rows.append({'grammar': name, 'repository': 'https://github.com/' + entry['repository'],
                 'commit': entry['commit'], 'license': license_id, 'distribution': distribution,
                 'basis': mode, 'source': source, 'notice': notice, 'blob_sha256': sha(blob.read_bytes())})

common = []
sources = {r['path']: r for r in json.loads((acquired / 'inventory.json').read_text(encoding='utf-8'))}
for name in ('MIT', 'ISC', 'Apache-2.0', 'LLVM-exception'):
    row = copy(acquired / (name + '.txt'), ROOT / 'LICENSES/standard' / (name + '.txt'))
    row.update(source=sources[name + '.txt']['source'])
    common.append(row)
nim = copy(acquired / 'nim.zip', ROOT / 'LICENSES/sources/nim.zip')
nim.update(source=sources['nim.zip']['source'])
assert len(rows) == 206 and sum(r['distribution'] == 'main' for r in rows) == 203
save(ROOT / 'LICENSES/catalog.json', {'schema': 1, 'rows': rows, 'standard_texts': common, 'corresponding_sources': [nim]})
print('Recorded 206 fixed grammar licenses: 197 original notices and nine SPDX declarations.')
