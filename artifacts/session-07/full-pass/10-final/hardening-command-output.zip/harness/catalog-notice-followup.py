from concurrent.futures import ThreadPoolExecutor
import json
import re
import urllib.error
import urllib.request
from receipt import ROOT, OUT, save

folder = OUT / '02-product-runtime/catalog-notices'
rows = json.loads((folder / 'inventory.json').read_text(encoding='utf-8'))['rows']
pending = [r for r in rows if 'sha256' not in r]


def inspect(row):
    repo, commit = row['repository'], row['commit']
    assert re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) and re.fullmatch('[a-f0-9]{40}', commit)
    url = f'https://api.github.com/repos/{repo}/git/trees/{commit}'
    result = {key: row[key] for key in ('grammar', 'repository', 'commit')}
    result['source'] = url
    try:
        request = urllib.request.Request(url, headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'public-license-audit'})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = response.read(1_000_001)
        if len(data) > 1_000_000:
            raise ValueError('oversized public directory response')
        data = json.loads(data)
        result['tree_sha'] = data['sha']
        result['entries'] = [{k: entry[k] for k in ('path', 'type', 'sha')} for entry in data['tree']]
    except urllib.error.HTTPError as error:
        result['error'] = error.code
    except (OSError, ValueError) as error:
        result['error'] = type(error).__name__
    return result


with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(inspect, pending))
save(folder / 'missing-notice-root-trees.json', results)
for row in results:
    print(row['grammar'], row.get('error', [r['path'] for r in row['entries'] if re.search(r'licen[cs]e|copy|notice|readme|package', r['path'], re.I)]))
for row in rows:
    if row['grammar'] in ('caddy', 'disassembly', 'jq', 'nim', 'fennel', 'fish', 'twig', 'textproto', 'wat', 'prolog'):
        data = (folder / row['path']).read_text(encoding='utf-8')
        print(row['grammar'], 'LICENSE HEADER:', '\n'.join(data.splitlines()[:12]))
