from concurrent.futures import ThreadPoolExecutor
import json
import re
import urllib.error
import urllib.request
from receipt import ROOT, OUT, save, sha

folder = OUT / '02-product-runtime/catalog-notices'
roots = json.loads((folder / 'missing-notice-root-trees.json').read_text(encoding='utf-8'))
out = folder / 'additional'
out.mkdir(exist_ok=False)


def fetch(row):
    repo, commit, grammar = row['repository'], row['commit'], row['grammar']
    assert re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) and re.fullmatch('[a-f0-9]{40}', commit)
    selected = [e['path'] for e in row.get('entries', []) if e['type'] == 'blob' and
                re.fullmatch(r'([Cc][Oo][Pp][Yy][Ii][Nn][Gg]|[Ll][Ii][Cc][Ee][Nn][SsCc][Ee])(?:\.[A-Za-z]+)?|package\.json|[Rr][Ee][Aa][Dd][Mm][Ee]\.md', e['path'])]
    results = []
    for name in selected:
        url = f'https://raw.githubusercontent.com/{repo}/{commit}/{name}'
        try:
            with urllib.request.urlopen(url, timeout=12) as response:
                data = response.read(100_001)
            assert len(data) <= 100_000
            path = grammar + '-' + name
            with (out / path).open('xb') as stream:
                stream.write(data)
            info = {'grammar': grammar, 'source': url, 'path': path, 'sha256': sha(data)}
            if name == 'package.json':
                package = json.loads(data)
                info['declared_license'] = package.get('license', package.get('licenses'))
                info['author'] = package.get('author')
            results.append(info)
        except (urllib.error.HTTPError, OSError, ValueError) as error:
            results.append({'grammar': grammar, 'source': url, 'error': str(type(error).__name__)})
    return results


with ThreadPoolExecutor(max_workers=4) as pool:
    results = [item for group in pool.map(fetch, roots) for item in group]
save(out / 'inventory.json', results)
for row in results:
    if 'declared_license' in row or re.search('copy|license', row.get('path', ''), re.I):
        print(row)
for row in roots:
    if row['grammar'] == 'ebnf':
        print('EBNF root', [r['path'] for r in row.get('entries', [])])
