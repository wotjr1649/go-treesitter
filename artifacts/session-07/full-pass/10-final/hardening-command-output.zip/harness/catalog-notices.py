"""Read-only public notice acquisition from the pinned upstream lock."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import re
import urllib.error
import urllib.request
from receipt import ROOT, OUT, save, sha

lock = ROOT / 'internal/runtime/grammars/languages.lock'
blobs = {p.stem for p in (ROOT / 'internal/runtime/grammars/grammar_blobs').glob('*.bin')}
entries = []
for line in lock.read_text(encoding='utf-8').splitlines():
    if not line or line.startswith('#'):
        continue
    name, url, commit, *rest = line.split()
    if name not in blobs:
        continue
    match = re.fullmatch(r'https://github.com/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)', url)
    assert match and re.fullmatch('[a-f0-9]{40}', commit) and re.fullmatch('[a-z0-9_]+', name)
    entries.append((name, match[1], commit))
assert {r[0] for r in entries} == blobs, sorted(blobs - {r[0] for r in entries})
directory = OUT / '02-product-runtime/catalog-notices'
directory.mkdir(exist_ok=False)


def fetch(row):
    name, repo, commit = row
    result = {'grammar': name, 'repository': repo, 'commit': commit, 'attempts': []}
    for filename in ('LICENSE', 'LICENSE.md', 'LICENSE.txt', 'COPYING', 'LICENCE', 'LICENSE-MIT'):
        url = f'https://raw.githubusercontent.com/{repo}/{commit}/{filename}'
        try:
            with urllib.request.urlopen(url, timeout=12) as response:
                data = response.read(100_001)
            if len(data) > 100_000:
                raise ValueError('oversized notice')
            result['attempts'].append({'file': filename, 'status': 200})
            result.update(source=url, sha256=sha(data), path=name + '.txt')
            with (directory / (name + '.txt')).open('xb') as stream:
                stream.write(data)
            return result
        except urllib.error.HTTPError as error:
            result['attempts'].append({'file': filename, 'status': error.code})
            if error.code != 404:
                return result
        except (OSError, ValueError) as error:
            result['attempts'].append({'file': filename, 'error': type(error).__name__})
            return result
    return result


with ThreadPoolExecutor(max_workers=6) as pool:
    rows = list(pool.map(fetch, entries))
save(directory / 'inventory.json', {'lock_sha256': sha(lock.read_bytes()), 'rows': rows})
print('notices acquired', sum('sha256' in r for r in rows), '/', len(rows))
for row in rows:
    if 'sha256' not in row:
        print('unresolved', row['grammar'], row['attempts'])
