package main
import _ "github.com/wotjr1649/go-treesitter/grammars/gpl"
