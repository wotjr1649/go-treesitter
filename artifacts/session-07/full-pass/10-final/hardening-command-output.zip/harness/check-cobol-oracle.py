import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/additional-grammars/cobol'
runtime = ROOT / '.scratch/oracle/runtime'
compiler = 'C:/msys64/ucrt64/bin/gcc.exe'
exe = work / 'cobol.exe'
command = [compiler, '-std=c11', '-O0', '-I' + str(work / 'src'), '-I' + str(runtime / 'lib/include'),
           '-I' + str(runtime / 'lib/src'), '-DORACLE_LANGUAGE=tree_sitter_COBOL',
           str(ROOT / 'tools/native-oracle/driver.c'), str(runtime / 'lib/src/lib.c'),
           str(work / 'src/parser.c'), str(work / 'src/scanner.c'), '-o', str(exe)]
run('04-catalog/build-cobol-oracle', command, timeout=150)
source = '       IDENTIFICATION DIVISION.\n       PROGRAM-ID. HELLO.\n'
rows = []
for text in (source, source + '\n', '000100 IDENTIFICATION DIVISION.\n000200 PROGRAM-ID. HELLO.\n'):
    process = subprocess.run([str(exe)], input=text.encode(), env=ENV, capture_output=True, timeout=15, check=True)
    c = json.loads(process.stdout)
    rows.append({'source': text, 'source_sha256': sha(text.encode()), 'c': c})
save(OUT / '04-catalog/cobol-c-oracle.json', {'oracle_sha256': sha(exe.read_bytes()), 'rows': rows})
for row in rows:
    print('C root', row['c']['nodes'][0], 'has_error', row['c']['has_error'])
