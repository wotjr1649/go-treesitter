import json
import subprocess
from receipt import ROOT, OUT, run, save

work = ROOT / '.scratch/full-pass/cobol-baseline-witness'
work.mkdir(exist_ok=False)
overlay = {'Replace': {}}
for path in ('internal/gtsadapter/adapter.go', 'syntax/result.go'):
    backing = work / (path.replace('/', '_') + '.txt')
    backing.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + path], cwd=ROOT))
    overlay['Replace'][str(ROOT / path)] = str(backing)
save(work / 'overlay.json', overlay)
try:
    run('04-catalog/cobol-baseline-witness', ['go', 'test', '-overlay=' + str(work / 'overlay.json'),
        './internal/gtsadapter', '-run', '^TestCobolGrammarOwnedRootSpan$', '-count=1', '-timeout=30s'], timeout=60)
except RuntimeError:
    result = json.loads((OUT / '04-catalog/cobol-baseline-witness.json').read_text(encoding='utf-8'))
    log = (OUT / '04-catalog/cobol-baseline-witness.log').read_text(encoding='utf-8')
    assert result['exit'] == 1 and 'complete COBOL result rejected' in log and 'Outcome:early_stop' in log
    print('Expected baseline rejection retained; C oracle accepts the same input.')
else:
    raise RuntimeError('baseline unexpectedly passed')
