import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

work = ROOT / '.scratch/full-pass'
builds = json.loads((OUT / '01-candidate-c/builds.json').read_text())
official = ROOT / '.scratch/oracle/build-01'
official_build = json.loads((official / 'build.json').read_text())
assert official_build['pins'] == json.loads((ROOT / 'internal/provenance/identities.json').read_text())
samples = {
    'import-type': ('type T = import("pkg").Name;\n', 'type T = string;\n'),
    'typeof-import': ('type T = typeof import("pkg");\n', 'type T = string;\n'),
    'variance': ('type Co<out T> = T; type Contra<in T> = (x: T) => void; type Inv<in out T> = T;\n', 'type Co<T> = T;\n'),
    'call-signatures': ('type Calls = {\n  <T>(value: T): T\n  <U>(value: U): U\n}\n', 'type Calls = { <T>(value: T): T; }\n'),
    'three-calls': ('type Calls = {\n  <T>(): T\n  <U>(): U\n  <V>(): V\n}\n', 'type Calls = { <T>(): T }\n'),
    'nested-calls': ('type Holder = { nested: {\n  <T>(): T\n  <U>(): U\n} }\n', 'type Holder = { nested: { <T>(): T } }\n'),
    'contextual-in': ('type Easing = {\n  default: string\n  in: string\n  out: string\n}\n', 'type Easing = { default: string; in: string; out: string };\n'),
    'optional-in': ('interface Easing {\n  default: string\n  in?: string\n}\n', 'interface Easing { default: string; in?: string };\n'),
    'binary-in-control': ('const result = key\n  in object;\n', 'const result = key in object;\n'),
    'semicolon-control': ('type Easing = { default: string; in: string; out: string };\n', 'type Easing = { default: string };\n'),
    'constructor-control': ('type Factory = {\n  new <T>(): T\n  new <U>(): U\n}\n', 'type Factory = { new <T>(): T };\n'),
    'index-control': ('type Index = {\n  [key: string]: string\n  [key: number]: string\n}\n', 'type Index = { [key: string]: string };\n'),
    'generic-call-control': ('foo\n<number>(1)', 'foo<number>(1)'),
}
cases = []
for ext in ('ts', 'tsx'):
    for name, (after, before) in samples.items():
        start = 0
        while start < min(len(before), len(after)) and before[start] == after[start]:
            start += 1
        old_end, new_end = len(before), len(after)
        while old_end > start and new_end > start and before[old_end - 1] == after[new_end - 1]:
            old_end -= 1
            new_end -= 1
        cases.append({'ID': ext + '-' + name, 'Filename': 'x.' + ext, 'Source': after,
            'Repeat': 20, 'Previous': before, 'Edit': {'StartByte': start,
            'OldEndByte': old_end, 'NewEndByte': new_end}})
save(OUT / '01-candidate-c/cases.json', cases)
probe = work / 'probe.exe'
result = subprocess.run([str(probe)], input=json.dumps(cases).encode(), capture_output=True,
                        env=ENV, timeout=120, check=True)
product = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
save(OUT / '01-candidate-c/product.json', {'binary_sha256': sha(probe.read_bytes()), 'cases': product})
rows = []
for case in cases:
    language = 'typescript' if case['Filename'] == 'x.ts' else 'tsx'
    observations = {}
    for variant in ('official-c', 'regenerated-unpatched-c', 'candidate-c'):
        artifact = (official_build['grammars'][language] if variant == 'official-c'
                    else builds['builds'][variant]['artifacts'][language])
        exe = ((official if variant == 'official-c' else ROOT) / artifact['executable'])
        assert sha(exe.read_bytes()) == artifact['executable_sha256']
        records = []
        for repeat in range(20):
            r = json.loads(subprocess.run([str(exe)], input=case['Source'].encode(),
                capture_output=True, check=True, env=ENV, timeout=15).stdout)
            assert r['input_bytes'] == len(case['Source'].encode()) and r['start'] == 0 and r['end'] == r['input_bytes']
            records.append(r)
        assert all(r == records[0] for r in records), (case['ID'], variant, 'nondeterministic')
        observations[variant] = records[0]
    g = product[case['ID']]
    assert len(g['Observations']) == 20 and all(r == g['Observations'][0] for r in g['Observations'])
    assert g['Observations'][0]['Complete'] and g['IncrementalEqual']
    native = observations['candidate-c']
    first = next((i for i, (a, b) in enumerate(zip(g['Nodes'], native['nodes'])) if a != b), -1)
    if first == -1 and len(g['Nodes']) != len(native['nodes']):
        first = min(len(g['Nodes']), len(native['nodes']))
    row = {'id': case['ID'], 'source_sha256': sha(case['Source'].encode()),
        'go_digest': g['Observations'][0]['Digest'], 'c': observations,
        'equal_candidate_c': first == -1 and (g['Observations'][0]['Error'] or g['Observations'][0]['Missing']) == native['has_error'],
        'first_difference': first, 'incremental_equals_fresh': g['IncrementalEqual'],
        'runs_per_runtime': 20, 'generator_control_equal': observations['official-c']['nodes'] == observations['regenerated-unpatched-c']['nodes']}
    if first >= 0:
        row['first_go'] = g['Nodes'][first] if first < len(g['Nodes']) else None
        row['first_c'] = native['nodes'][first] if first < len(native['nodes']) else None
    rows.append(row)
    print(case['ID'], 'Go/C', row['equal_candidate_c'], 'C-original-error', observations['official-c']['has_error'], 'generator-control', row['generator_control_equal'], flush=True)
save(OUT / '01-candidate-c/comparison.json', {'builds_sha256': sha((OUT / '01-candidate-c/builds.json').read_bytes()),
    'official_build_sha256': sha((official / 'build.json').read_bytes()), 'rows': rows})
if not all(r['equal_candidate_c'] for r in rows):
    raise RuntimeError('candidate C disagreement; all comparisons preserved')
