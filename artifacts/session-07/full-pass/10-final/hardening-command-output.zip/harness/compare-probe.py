"""Bounded, offline probe comparison. Keep raw results, including failures."""
import json
from pathlib import Path
import subprocess
import sys
from receipt import ROOT, OUT, ENV, save, sha

sys.stdout.reconfigure(encoding='utf-8')
candidate, source, name = sys.argv[1:4]
project_c_names = '--project-c-names' in sys.argv[4:]
directory = ROOT / '.scratch/full-pass' / candidate
cases = json.loads((OUT / '06-correctness' / (source + '.json')).read_text(encoding='utf-8'))['cases']
result = subprocess.run([str(directory / 'probe.exe')], input=json.dumps(cases, ensure_ascii=False).encode(),
                        env=ENV, capture_output=True, timeout=90)
rows = []
for case, line in zip(cases, result.stdout.splitlines()):
    g = json.loads(line)
    language = {'.go': 'go', '.ts': 'typescript', '.tsx': 'tsx', '.js': 'javascript', '.jsx': 'javascript'}[Path(case['Filename']).suffix]
    c_result = subprocess.run([str(ROOT / '.scratch/oracle/build-full-pass-v2' / (language + '.exe'))],
                              input=case['Source'].encode(), env=ENV, capture_output=True, timeout=10, check=True)
    c = json.loads(c_result.stdout)
    def nodes(value):
        return [dict(n, Type=n['Type'].split('\0')[0]) for n in value] if project_c_names else value
    rows.append({'id': case['ID'], 'go': g, 'c': c,
                 'fresh_C': nodes(g['Nodes']) == c['nodes'] and all(o['Error'] == c['has_error'] and o['Complete'] for o in g['Observations']),
                 'inc_C': nodes(g['IncrementalNodes']) == c['nodes'] and g['Incremental']['Error'] == c['has_error'] and g['Incremental']['Complete'] if g['Incremental'] else None,
                 'deterministic': all(o == g['Observations'][0] for o in g['Observations'])})
save(OUT / '06-correctness' / (name + '.json'), {
    'cases': cases, 'c_name_projection_only': project_c_names,
    'executable_sha256': sha((directory / 'probe.exe').read_bytes()),
    'overlay_files': {k: sha(Path(v).read_bytes()) for k, v in json.loads((directory / 'overlay.json').read_text())['Replace'].items()},
    'exit': result.returncode, 'stderr': result.stderr.decode(errors='replace'), 'rows': rows})
failed = [(r['id'], r['fresh_C'], r['inc_C']) for r in rows if not (r['fresh_C'] and r['inc_C'] is not False and r['deterministic'])]
print('rows', len(rows), '/', len(cases), 'pass', len(rows)-len(failed), 'failed', failed)
if result.returncode:
    print(result.stderr.decode(errors='replace')[:1000])
