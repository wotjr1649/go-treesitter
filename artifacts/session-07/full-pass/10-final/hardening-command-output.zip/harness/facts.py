import json
import platform
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

def command(*args):
    return subprocess.check_output(args, cwd=ROOT, env=ENV, timeout=30).decode('utf-8').strip()

pins = json.loads((ROOT / 'internal/provenance/identities.json').read_text(encoding='utf-8'))
catalogs = {}
for name in ('cases.json', 'extended-cases.json', 'typescript-contextual-cases.json', 'csharp-recovery-cases.json'):
    p = ROOT / 'testdata/oracle' / name
    cases = json.loads(p.read_text(encoding='utf-8'))
    catalogs[name] = {'sha256': sha(p.read_bytes()), 'inputs': len(cases),
                     'edits': sum(bool(c.get('previous')) for c in cases)}
source_files = command('git', 'ls-files').splitlines()
save(OUT / '00-baseline.json', {
    'root': str(ROOT), 'branch': command('git', 'branch', '--show-current'),
    'start_head': '9e5c90ad4aaf0bcea59d229e6b6f0ab789893a76',
    'start_status': 'clean (observed before all task edits)',
    'go_version': command('go', 'version'),
    'go_env': json.loads(command('go', 'env', '-json', 'GOOS', 'GOARCH', 'CGO_ENABLED', 'GOVERSION', 'GOTOOLCHAIN', 'GOWORK', 'GOFLAGS', 'GOPROXY')),
    'os': platform.platform(), 'architecture': platform.machine(),
    'modules': command('go', 'list', '-modfile=.scratch/full-pass/graph.mod', '-mod=readonly', '-m', 'all').splitlines(),
    'pins_at_receipt_time': pins, 'catalogs': catalogs,
    'references': {name: {'head': command('git', '-C', path, 'rev-parse', 'HEAD'),
                          'status': command('git', '-C', path, 'status', '--short')}
                   for name, path in (('gotreesitter', 'D:/AIDEV/_ref/gotreesitter'), ('tree-sitter', 'D:/AIDEV/_ref/tree-sitter'))},
    'public_patch_ancestry': {commit: subprocess.run(['git', '-C', 'D:/AIDEV/_ref/gotreesitter',
            'merge-base', '--is-ancestor', commit, pins['baseline']['commit']], env=ENV).returncode == 0
            for commit in ('24e1d3b2b4409ee2ffa63e88abba51a40060e76e', '0376556')},
    'runtime_blobs': {lang: sha((ROOT / '.scratch/modcache/github.com/odvcencio/gotreesitter@v0.53.0/grammars/grammar_blobs' / (lang + '.bin')).read_bytes()) for lang in pins['grammars']},
    'release_approved_candidate': None,
    'tracked_source_hashes': {p: sha((ROOT / p).read_bytes()) for p in source_files if p.endswith(('.go', '.c', '.py'))},
})
print('baseline, catalogs, pins, source identity and reference status captured')
