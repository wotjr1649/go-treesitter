import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from receipt import ROOT, OUT, ENV, run, save, sha

name = '10-final'
exe = ROOT / '.scratch/full-pass/catalog-final-main.exe'
gpl = ROOT / '.scratch/full-pass/catalog-final-gpl.exe'
run(name+'/catalog-build', ['go','build','-trimpath','-o',str(exe),'./tools/catalog'])
gplenv = dict(ENV, GOWORK=str(ROOT/'.scratch/full-pass/gpl-test-native.work'))
run(name+'/catalog-gpl-build', ['go','build','-overlay='+str(ROOT/'.scratch/full-pass/catalog-gpl-overlay.json'),
    '-trimpath','-o',str(gpl),'./tools/catalog'], env=gplenv)
cases_path = OUT/'04-catalog/cases.json'
cases = json.loads(cases_path.read_text(encoding='utf-8'))['cases']
assert len(cases) == 206 and len({c['language'] for c in cases}) == 206
def check(c):
    assert sha(c['source'].encode()) == c['sha256']
    binary = gpl if c['language'] in ('caddy','disassembly','jq') else exe
    p = subprocess.run([str(binary),'-language',c['language'],'-repeat','3'],input=c['source'].encode(),
        capture_output=True,env=ENV,timeout=30)
    return dict(language=c['language'],source_sha256=c['sha256'],exit=p.returncode,receipt=json.loads(p.stdout))
with ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(check,cases))
save(OUT/name/'catalog.json',dict(cases_sha256=sha(cases_path.read_bytes()),
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    executables={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in (exe,gpl)},
    repeats=3,parallel_processes=2,rows=rows))
bad=[r['language'] for r in rows if r['exit']]
print('catalog',len(rows),'failed',bad,flush=True)
assert not bad
run(name+'/product',['go','test','./...','-count=1','-timeout=180s','-json'],timeout=240)
run(name+'/private',['python','tools/runtime-bundle/check.py'],timeout=120)
run(name+'/vet',['go','vet','./...'],timeout=180)
run(name+'/oracle-tool-tests',['python','-m','unittest','discover','-s','tools/native-oracle','-p','test_*.py'],timeout=120)
run(name+'/gpl-tests',['go','test','./...','-count=1','-timeout=60s'],cwd=ROOT/'grammars/gpl',env=gplenv)
