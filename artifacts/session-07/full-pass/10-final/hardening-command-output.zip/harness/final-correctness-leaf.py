import json
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

pairs = [('cases','base'),('extended-cases','extended'),('typescript-contextual-cases','ts-contextual'),
         ('csharp-recovery-cases','cs-recovery'),('csharp-order-cases','cs-order'),
         ('csharp-preservation-cases','cs-preservation'),('go-recovery-cases','go-recovery'),
         ('go-keyword-cases','go-keyword'),('runtime-hardening-cases','runtime-hardening')]
exe=ROOT/'.scratch/full-pass/final-correctness-leaf.exe'
run('10-final/oracle/build',['go','build','-trimpath','-o',str(exe),str(ROOT/'.scratch/full-pass/probe.go')])
build=ROOT/'.scratch/oracle/build-full-pass-v2'
identity=json.loads((build/'build.json').read_text(encoding='utf-8'))
for name,row in identity['grammars'].items():
    assert sha((build/row['executable']).read_bytes())==row['executable_sha256']
summary=[]
for catalog,directory in pairs:
    path=ROOT/'testdata/oracle'/(catalog+'.json')
    cases=json.loads(path.read_text(encoding='utf-8'))
    by_id={c['id']:c for c in cases}
    rows=[]
    for offset in range(0,len(cases),100):
        batch=cases[offset:offset+100]
        requests=[]
        for c in batch:
            record=json.loads((ROOT/'testdata/oracle/windows-c-v2'/directory/(c['id']+'.json')).read_text(encoding='utf-8'))
            source=c.get('source') if 'source' in c else (ROOT/c['path']).read_bytes().decode()
            assert sha(source.encode())==c['sha256']
            request=dict(ID=c['id'],Filename=c['filename'],Source=source,Repeat=100 if record['has_error'] else 20)
            if 'previous' in c:
                request.update(Previous=by_id[c['previous']]['source'],Edit=c['edit'])
            requests.append(request)
        process=subprocess.run([str(exe)],input=json.dumps(requests,ensure_ascii=False).encode(),capture_output=True,env=ENV,timeout=180)
        if process.returncode:
            save(OUT/'10-final/oracle'/(directory+'-failure.json'),dict(exit=process.returncode,stderr=process.stderr.decode(errors='replace'),stdout=process.stdout.decode(errors='replace')))
        process.check_returncode()
        for c,request,line in zip(batch,requests,process.stdout.splitlines(),strict=True):
            g=json.loads(line)
            cs=[]
            for _ in range(3):
                p=subprocess.run([str(build/(c['language']+'.exe'))],input=request['Source'].encode(),capture_output=True,env=ENV,timeout=15,check=True)
                cs.append(json.loads(p.stdout))
            cr=cs[0]
            record=json.loads((ROOT/'testdata/oracle/windows-c-v2'/directory/(c['id']+'.json')).read_text(encoding='utf-8'))
            ci=None
            if 'previous' in c:
                e=c['edit'];old=request['Previous'].encode()
                p=subprocess.run([str(build/(c['language']+'.exe')),str(len(old)),str(e['StartByte']),str(e['OldEndByte']),str(e['NewEndByte'])],input=old+request['Source'].encode(),capture_output=True,env=ENV,timeout=15,check=True)
                ci=json.loads(p.stdout)
            want_missing=any(n['Missing'] for n in cr['nodes'])
            passed=(cs[0]==cs[1]==cs[2] and cr['nodes']==record['nodes'] and cr['has_error']==record['has_error']
                    and g['Nodes']==cr['nodes'] and len(g['Observations'])==request['Repeat']
                    and all(o==g['Observations'][0] and o['Complete'] and o['Error']==cr['has_error'] and o['Missing']==want_missing for o in g['Observations']))
            if ci is not None:
                passed &= ci==cr and g['IncrementalEqual'] and g['IncrementalNodes']==cr['nodes'] and g['Incremental']['Complete'] and g['Incremental']['Error']==cr['has_error'] and g['Incremental']['Missing']==want_missing
            rows.append(dict(id=c['id'],source_sha256=c['sha256'],passed=passed,c_deterministic=cs[0]==cs[1]==cs[2],c_incremental_equal=ci==cr if ci else None,go=g))
    save(OUT/'10-final/oracle'/(directory+'.json'),dict(catalog_sha256=sha(path.read_bytes()),
        runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
        executable_sha256=sha(exe.read_bytes()),c_build_sha256=sha((build/'build.json').read_bytes()),rows=rows))
    failures=[r['id'] for r in rows if not r['passed']]
    print(directory,len(rows),'passed',len(rows)-len(failures),'failures',failures,flush=True)
    summary.append(dict(catalog=catalog,count=len(rows),edits=sum('previous' in c for c in cases),failed=failures))
save(OUT/'10-final/oracle/summary.json',dict(catalogs=summary))
assert not any(r['failed'] for r in summary)
