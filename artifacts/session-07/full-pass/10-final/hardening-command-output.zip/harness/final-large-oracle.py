import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

before='package p\n'+''.join(f'var item{i} = {i}\n' for i in range(8192))
after=before+'\n'
end=len(before.encode())
request=dict(ID='large-go-8192-append',Filename='large.go',Source=after,Previous=before,
    Edit=dict(StartByte=end,OldEndByte=end,NewEndByte=end+1),Repeat=3)
goexe=ROOT/'.scratch/full-pass/final-correctness-leaf.exe'
cexe=ROOT/'.scratch/oracle/build-full-pass-v2/go.exe'
g=json.loads(subprocess.run([str(goexe)],input=json.dumps([request]).encode(),capture_output=True,
    env=ENV,timeout=60,check=True).stdout)
c=json.loads(subprocess.run([str(cexe)],input=after.encode(),capture_output=True,env=ENV,timeout=30,check=True).stdout)
ci=json.loads(subprocess.run([str(cexe),str(end),str(end),str(end),str(end+1)],
    input=before.encode()+after.encode(),capture_output=True,env=ENV,timeout=30,check=True).stdout)
passed=g['Nodes']==c['nodes']==g['IncrementalNodes']==ci['nodes'] and ci==c and g['IncrementalEqual'] and g['Incremental']['Complete'] and all(o['Complete'] for o in g['Observations'])
save(OUT/'10-final/oracle/large-go.json',dict(request={k:v for k,v in request.items() if k not in ('Source','Previous')},
    source_sha256=sha(after.encode()),previous_sha256=sha(before.encode()),
    executable_hashes={'go':sha(goexe.read_bytes()),'C':sha(cexe.read_bytes())},
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    nodes=len(c['nodes']),node_digest=sha(json.dumps(c['nodes'],separators=(',',':')).encode()),
    observations=g['Observations'],incremental=g['Incremental'],passed=passed))
assert passed
print('large Go fresh/edit/C: PASS',len(c['nodes']),'nodes')
