import json
from pathlib import Path
import subprocess
import zipfile
from receipt import ROOT, OUT, save, sha

pins = ROOT / 'internal/provenance/identities.json'
current = json.loads(pins.read_text(encoding='utf-8'))
original = subprocess.check_output(['git', 'show', 'HEAD:internal/provenance/identities.json'], cwd=ROOT).decode()
original_object = json.loads(original)
assert {k: v for k, v in current.items() if k != 'runtime'} == original_object
formatted = original.rstrip()
assert formatted.endswith('\n}')
formatted = formatted[:-2] + ',\n  "runtime": ' + json.dumps(current['runtime'], indent=2).replace('\n', '\n  ') + '\n}\n'
assert json.loads(formatted) == current
pins.write_text(formatted, encoding='utf-8', newline='\n')

names = ['runtime-import', 'runtime-inventory', 'bundled-focused', 'bundled-product',
         'bundled-oracle-fixed', 'bundled-consumer-fixed', 'bundled-final-product',
         'bundled-subset', 'bundled-tooling', 'bundled-tamper', 'bundled-vet',
         'bundled-reproduction', 'bundled-campaign']
files = [OUT / (name + '.log') for name in names if (OUT / (name + '.log')).exists()]
files += sorted(p for p in (OUT / '02-product-runtime').glob('*.log'))
files.append(OUT / '02-product-runtime/results.json')
archive = OUT / '02-product-runtime/command-output.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for path in files:
        zipped.writestr(path.relative_to(OUT).as_posix(), path.read_bytes())
save(OUT / '02-product-runtime/output-manifest.json', {
    'archive_sha256': sha(archive.read_bytes()),
    'files': {p.relative_to(OUT).as_posix(): {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in files}})
with zipfile.ZipFile(archive) as zipped:
    for path in files:
        assert zipped.read(path.relative_to(OUT).as_posix()) == path.read_bytes()
manifest = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
crlf = [name for name in manifest['files'] if name.endswith(('.go', '.json')) and b'\r\n' in (ROOT / 'internal/runtime' / name).read_bytes()]
print('archived', len(files), 'outputs; runtime CRLF text files', len(crlf))
if crlf:
    raise ValueError('runtime text normalization would change identified bytes')
