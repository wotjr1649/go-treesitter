import json
from pathlib import Path
import subprocess
from receipt import ROOT, ENV, save, run

base = ROOT / '.scratch/full-pass/recovery-reuse-dependency'
dest = ROOT / '.scratch/full-pass/recovery-final-review-v2'
dest.mkdir()
overlay = json.loads((base / 'overlay.json').read_text(encoding='utf-8'))
for target, origin in list(overlay['Replace'].items()):
    if target.endswith('.go'):
        path = dest / Path(target).name
        path.write_bytes(Path(origin).read_bytes())
        overlay['Replace'][target] = str(path)

def edit(name, before, after):
    path = dest / name
    text = path.read_text(encoding='utf-8')
    assert text.count(before) == 1, (name, before)
    path.write_text(text.replace(before, after), encoding='utf-8', newline='\n')

edit('runtime_profiles.go',
     '// The canonical compact corpus certifies Go\'s converged-path split drops\n\t// against the production parser and the tree-sitter C oracle.\n\t// The owned EOF bundle requires its executed recovery route before publication.',
     '// Go uses the tables converted from the pinned C grammar. Compact-route\n\t// certificates for the different grammargen blob do not transfer to it.')
edit('embedded_loader.go',
     '\tif name == "go" && lang != nil && len(lang.ExternalSymbols) == 0 {',
     '\t// The C-derived Go tables encode ASI internally. The literal NUL\n\t// terminal has an empty type name in the C API\'s NUL-terminated string.\n\tif name == "go" && lang != nil && len(lang.ExternalSymbols) == 0 {')
edit('parser_result_go.go',
     '\tif lang != nil && !lang.GeneratedByGrammargen {',
     '\t// These repairs apply to the Go grammar port, not the pinned C tables.\n\tif lang != nil && !lang.GeneratedByGrammargen {')
edit('parser_recover_c.go',
     '\t//   - javascript: the port exceeds the W5 incremental replace ceilings\n\t//     by about 2.8 times (TestW5JavaScriptFamilyTransientErrorGate).\n', '')
edit('parser_recover_c.go',
     '// EOF is symbol 0, so callers must pass anyLookahead explicitly instead of\n// overloading lookaheadSym == 0. The caller seed supplies reusable initial',
     '// C also uses the all-symbol closure when lookahead is EOF (symbol zero).\n// The caller seed supplies reusable initial')
edit('parser_recover_c.go',
     '// cRecoverSkipsSharedGoNewline identifies the Go port\'s scanner-only newline\n// token. C\'s error-mode DFA treats those bytes as skipped whitespace; explicit',
     '// cRecoverSkipsSharedGoNewline identifies a shared Go newline terminator.\n// C\'s error-mode DFA treats those bytes as skipped whitespace; explicit')
edit('parser_recover_c.go',
     '\t// Exact-span requirement: this is what keeps the shared-token loop in\n\t// lockstep. A shorter or longer re-lex would leave this stack at a\n\t// different byte offset than its siblings.',
     '\t// JS-family recovery can split an internal token into shorter tokens.\n\t// The dispatch loop replays its remainder before advancing the shared\n\t// stream. Other grammars and external scanner tokens require exact spans.')
edit('parser.go',
     '// Go recovery uses the same C version ordering with or without subtree reuse.',
     '// Go and TSX recovery use the same C version order with or without reuse.')
edit('parser.go',
     '\t\t// where the recovery machinery actually ran; the walk itself only\n\t\t// happens when the root still claims an error.',
     '\t\t// where the recovery machinery actually ran. Inspect the raw ledger\n\t\t// first: invisible MISSING terminals still contribute C error cost.')
edit('parser.go',
     '\t\t// with zero ERROR/MISSING descendants is the only case where',
     '\t\t// with zero ERROR/MISSING descendants in both raw and visible trees is\n\t\t// the only case where')

# C lexers can match rune zero at EOF without an explicit `if (eof)` branch.
# Keep contiguous and included-range lexers on the same transition rule.
path = dest / 'lexer_included_ranges.go'
path.write_bytes((ROOT / 'internal/runtime/lexer_included_ranges.go').read_bytes())
overlay['Replace'][str(ROOT / 'internal/runtime/lexer_included_ranges.go')] = str(path)
edit('lexer.go', '''			eofState := st.EOF
			if eofState < 0 {
				for _, tr := range st.Transitions {
					if tr.Lo <= 0 && tr.Hi >= 0 {
						eofState = int(tr.NextState)
						break
					}
				}
			}''', '\t\t\teofState := lexerEOFState(st)')
edit('lexer_included_ranges.go',
     '\t\t\tif st.EOF >= 0 && eofHops <= len(l.states) {\n\t\t\t\tcurState = int32(st.EOF)',
     '\t\t\tif eofState := lexerEOFState(st); eofState >= 0 && eofHops <= len(l.states) {\n\t\t\t\tcurState = int32(eofState)')
path = dest / 'lexer.go'
with path.open('a', encoding='utf-8', newline='\n') as stream:
    stream.write('''
// A generated C DFA sees rune zero at EOF. An explicit EOF branch takes
// precedence; otherwise a transition containing zero can accept a zero-width
// terminal. Callers bound EOF hops and never advance the physical position.
func lexerEOFState(state *LexState) int {
	if state.EOF >= 0 {
		return state.EOF
	}
	for _, transition := range state.Transitions {
		if transition.Lo <= 0 && transition.Hi >= 0 {
			return int(transition.NextState)
		}
	}
	return -1
}
''')
subprocess.run(['gofmt', '-w', *map(str, dest.glob('*.go'))], env=ENV, timeout=30, check=True)
save(dest / 'overlay.json', overlay)
run('recovery-final-review-build', ['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
