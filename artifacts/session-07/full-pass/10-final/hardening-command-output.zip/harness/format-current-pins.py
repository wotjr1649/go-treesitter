import json
import subprocess
from receipt import ROOT
path=ROOT/'internal/provenance/identities.json'
current=json.loads(path.read_text(encoding='utf-8'))
old=subprocess.check_output(['git','show','HEAD:internal/provenance/identities.json'],cwd=ROOT).decode()
previous=json.loads(old)
needle='    "manifest_sha256": '+json.dumps(previous['runtime']['manifest_sha256'])
replacement='    "manifest_sha256": '+json.dumps(current['runtime']['manifest_sha256'])+',\n    "grammar_blobs": '+json.dumps(current['runtime']['grammar_blobs'])
assert old.count(needle)==1
new=old.replace(needle,replacement)
assert json.loads(new)==current
path.write_text(new,encoding='utf-8',newline='\n')
