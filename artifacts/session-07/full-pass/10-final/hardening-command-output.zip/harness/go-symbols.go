package main
import("fmt"; "github.com/wotjr1649/go-treesitter/internal/runtime/grammars")
func main(){l:=grammars.GoLanguage();for i,s:=range l.SymbolNames {if i<10 || s=="_automatic_semicolon" || s=="" || s=="\x00" {fmt.Printf("%d %q %+v\n",i,s,l.SymbolMetadata[i])}}}
