import difflib
import json
from pathlib import Path

root = Path.cwd()
name = 'grammars/runtime/blob_source.go'
old = (root / 'internal/runtime' / name).read_text(encoding='utf-8')
new = old.replace('// Its source takes precedence over individual providers, including read errors.',
                  '// An explicitly registered blob takes precedence over the aggregate catalog.')
block = '\tif read != nil {\n\t\treturn grammarBlob{data: read()}, nil\n\t}\n'
assert new.count(block) == 1
new = new.replace(block, '')
new = new.replace('\tif catalog != nil {', block + '\tif catalog != nil {', 1)
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), 'a/' + name, 'b/' + name))
path = root / 'tools/runtime-bundle/patches/catalog-optional-blob-providers.patch'
with path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(patch)
path = root / 'tools/runtime-bundle/source.json'
data = json.loads(path.read_text(encoding='utf-8'))
data['patches'].append('catalog-optional-blob-providers.patch')
path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')
