import json
import re
from pathlib import Path
from receipt import ROOT

packages = json.loads((ROOT / 'artifacts/session-07/full-pass/02-product-runtime/package-inventory.json').read_text(encoding='utf-8'))
base = ROOT / '.scratch/session07-runtime'
imports, builds, embeds, effects = set(), set(), [], []
for package in packages:
    rel = package['ImportPath'].removeprefix('github.com/odvcencio/gotreesitter').lstrip('/')
    folder = base / rel
    print('PACKAGE', rel or '.', 'other:', [p.name for p in folder.iterdir() if p.is_file() and p.suffix in ('.s', '.h', '.syso', '.c')])
    for p in sorted(folder.glob('*.go')):
        if p.name.endswith('_test.go'):
            continue
        code = p.read_text(encoding='utf-8')
        for block in re.findall(r'(?m)^import\s+(?:\([^)]*\)|[^\n]+)', code):
            imports.update(re.findall(r'"([^"\n]+)"', block))
        builds.update(re.findall(r'(?m)^//go:build (.+)$', code))
        for pattern in re.findall(r'(?m)^//go:embed (.+)$', code):
            embeds.append((p.relative_to(base).as_posix(), pattern))
        for line in code.splitlines():
            if re.search(r'(exec\.(Command|LookPath)|os\.(WriteFile|Create|OpenFile|Remove|Mkdir|Rename)|net\.(Listen|Dial)|http\.(Get|Post|Listen)|go:linkname)', line):
                effects.append((p.relative_to(base).as_posix(), line.strip()))
print('IMPORTS', sorted(imports))
print('SPECIAL BUILD TAGS', sorted(b for b in builds if 'grammar' not in b))
print('EMBED PATTERNS', sorted(set(pattern for _, pattern in embeds)))
print('EFFECTS', effects)
