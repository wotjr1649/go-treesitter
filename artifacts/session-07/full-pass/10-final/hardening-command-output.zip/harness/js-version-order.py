import json
from pathlib import Path
from receipt import ROOT,save,run

base=ROOT/'.scratch/full-pass/recovery-js-round-order'
dest=ROOT/'.scratch/full-pass/js-version-order-v2'
dest.mkdir()
o=json.loads((base/'overlay.json').read_text(encoding='utf-8'))
for filename in ['parser.go','parser_recover_c.go','grammars/runtime/runtime_profiles.go']:
 key=str(ROOT/'internal/runtime'/filename)
 s=Path(o['Replace'][key]).read_text(encoding='utf-8')
 if filename=='parser.go':
  needle='language.Name == "go" || language.Name == "tsx")'
  assert s.count(needle)==1
  s=s.replace(needle,'language.Name == "go" || language.Name == "tsx" || language.Name == "javascript")')
 elif filename=='parser_recover_c.go':
  s=s.replace('p.language.Name != "go" && j < len(*stacks)', '(p.language.Name == "javascript" || p.language.Name == "typescript" || p.language.Name == "tsx") && j < len(*stacks)')
 else:
  needle='\t"javascript": {\n'
  assert s.count(needle)==1
  s=s.replace(needle,needle+'\t\tcompactPackedGSSVersionOrder: true,\n')
 p=dest/Path(filename).name;p.write_text(s,encoding='utf-8',newline='\n');o['Replace'][key]=str(p)
save(dest/'overlay.json',o)
run('js-version-order-v2-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
