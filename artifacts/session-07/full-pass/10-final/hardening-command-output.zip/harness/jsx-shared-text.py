import json
from pathlib import Path
from receipt import ROOT,save,run

base=ROOT/'.scratch/full-pass/recovery-leaf-cost';dest=ROOT/'.scratch/full-pass/jsx-shared-text';dest.mkdir()
o=json.loads((base/'overlay.json').read_text(encoding='utf-8'))
p=dest/'parser_dfa_token_source.go';s=(ROOT/'internal/runtime/parser_dfa_token_source.go').read_text(encoding='utf-8')
needle='\textSupport := d.countGLRActionSupport(extTok.Symbol)'
assert s.count(needle)==1
s=s.replace(needle, '''	// Preserve the JSX version's full external text token. Sibling code
	// versions can split it through the internal DFA; choosing only a shorter
	// punctuation token would irreversibly discard the JSX interpretation.
	if statelessJSXTextToken(d.language, extTok) {
		return Token{}, 0, 0, 0, false
	}
'''+needle)
s+='''
func statelessJSXTextToken(language *Language, token Token) bool {
	if language == nil || !token.ExternalScannerToken || int(token.Symbol) >= len(language.SymbolNames) ||
		language.SymbolNames[token.Symbol] != extNameJSXText ||
		(language.Name != "javascript" && language.Name != "typescript" && language.Name != "tsx") {
		return false
	}
	scanner, ok := language.ExternalScanner.(StatelessExternalScanner)
	return ok && scanner.ExternalScannerIsStateless()
}
'''
p.write_text(s,encoding='utf-8',newline='\n');o['Replace'][str(ROOT/'internal/runtime/parser_dfa_token_source.go')]=str(p)
key=str(ROOT/'internal/runtime/parser_recover_c.go');s=Path(o['Replace'][key]).read_text(encoding='utf-8')
needle='|| tok.ExternalScannerToken || relexed.StartByte < tok.StartByte'
assert s.count(needle)==1
s=s.replace(needle,'|| (tok.ExternalScannerToken && !statelessJSXTextToken(lang, tok)) || relexed.StartByte < tok.StartByte')
p=dest/'parser_recover_c.go';p.write_text(s,encoding='utf-8',newline='\n');o['Replace'][key]=str(p);save(dest/'overlay.json',o)
run('jsx-shared-text-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
