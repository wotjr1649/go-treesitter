import json
from receipt import ROOT, save, run
p=ROOT/'.scratch/full-pass/large-entry-trace'
s=(p/'parser.go').read_text(encoding='utf-8').replace('import (','import (\n"os"',1)
(p/'parser-v2.go').write_text(s,encoding='utf-8',newline='\n')
d=json.loads((p/'overlay.json').read_text(encoding='utf-8'))
d['Replace'][str(ROOT/'internal/runtime/parser.go')]=str(p/'parser-v2.go')
save(p/'overlay-v2.json',d)
run('large-entry-trace-v2-build',['go','build','-overlay='+str(p/'overlay-v2.json'),'-o',str(p/'probe-v2.exe'),str(ROOT/'.scratch/full-pass/large-profile.go')])
run('07-resources/large-entry-trace',[str(p/'probe-v2.exe'),'8192','-'],timeout=30)
