import json
import subprocess
from receipt import ROOT, OUT, ENV, save, run, sha
dest=ROOT/'.scratch/full-pass/large-entry-trace';dest.mkdir()
replace={}
p=ROOT/'internal/runtime/glr.go';s=p.read_text(encoding='utf-8')
s=s.replace('"os"','"os"\n"runtime/debug"',1)
needle='\t\t\ts.slabs = append(s.slabs, stackEntrySlab{data: make([]stackEntry, capacity)})'
assert s.count(needle)==1
s=s.replace(needle,'\t\t\tif capacity > 65536 { fmt.Fprintf(os.Stderr,"ENTRY capacity=%d request=%d used=%d\\n",capacity,n,s.usedTotal);debug.PrintStack() }\n'+needle)
q=dest/'glr.go';q.write_text(s,encoding='utf-8',newline='\n');replace[str(p)]=str(q)
p=ROOT/'internal/runtime/parser.go';s=p.read_text(encoding='utf-8')
needle='\ttree := p.parseInternal(source, ts, reuse, oldTree, arenaClass, timing, 0, 0, maxMergePerKeyOverride, false)'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n\tif tree != nil { fmt.Fprintf(os.Stderr,"INC-ATTEMPT %+v\\n",tree.ParseRuntime()) }')
q=dest/'parser.go';q.write_text(s,encoding='utf-8',newline='\n');replace[str(p)]=str(q)
save(dest/'overlay.json',dict(Replace=replace))
run('large-entry-trace-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/large-profile.go')])
run('07-resources/large-entry-trace',[str(dest/'probe.exe'),'8192','-'],timeout=30)
