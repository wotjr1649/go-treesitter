package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"runtime/pprof"
	"strconv"
	"time"

	treesitter "github.com/wotjr1649/go-treesitter"
	"github.com/wotjr1649/go-treesitter/syntax"
)

func main() {
	if len(os.Args) != 3 {
		panic("COUNT OUTPUT-PREFIX")
	}
	count, err := strconv.Atoi(os.Args[1])
	if err != nil || count < 1 || count > 10000 {
		panic("count")
	}
	var source bytes.Buffer
	source.WriteString("package p\n")
	for i := range count {
		fmt.Fprintf(&source, "var item%d = %d\n", i, i)
	}
	p := treesitter.New()
	parse := func(label string, req syntax.Request) syntax.Result {
		runtime.GC()
		var before, after runtime.MemStats
		runtime.ReadMemStats(&before)
		start := time.Now()
		r, err := p.Parse(context.Background(), req)
		elapsed := time.Since(start)
		runtime.ReadMemStats(&after)
		if r.Tree == nil || !r.Complete() || err != nil {
			panic(fmt.Sprintf("parse: %v %+v", err, r.Diagnostics))
		}
		if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"phase": label, "count": count, "bytes": len(req.Source), "nanoseconds": elapsed.Nanoseconds(), "allocated": after.TotalAlloc - before.TotalAlloc, "allocs": after.Mallocs - before.Mallocs, "diagnostics": r.Diagnostics}); err != nil {
			panic(err)
		}
		runtime.GC()
		if os.Args[2] != "-" {
			f, err := os.OpenFile(os.Args[2]+"-"+label+".pprof", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
			if err != nil {
				panic(err)
			}
			if err := pprof.Lookup("allocs").WriteTo(f, 0); err != nil {
				panic(err)
			}
			if err := f.Close(); err != nil {
				panic(err)
			}
		}
		return r
	}
	r := parse("fresh", syntax.Request{Filename: "large.go", Source: source.Bytes(), Timeout: 10 * time.Second})
	defer r.Tree.Close()
	after := append(bytes.Clone(source.Bytes()), '\n')
	end := uint32(source.Len())
	inc := parse("incremental", syntax.Request{Filename: "large.go", Source: after, Previous: r.Tree, Edit: &syntax.Edit{StartByte: end, OldEndByte: end, NewEndByte: end + 1}, Timeout: 10 * time.Second})
	inc.Tree.Close()
}
