from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import urllib.request

OUT = Path('artifacts/session-07/full-pass/05-licenses/crosscheck')
OUT.mkdir(exist_ok=False)
SOURCES = {
    'authzed': ('mleonidas/tree-sitter-authzed', '83e5c26a8687eb4688fe91d690c735cc3d21ad81'),
    'brightscript': ('ajdelcimmuto/tree-sitter-brightscript', '253fdfaa23814cb46c2d5fc19049fa0f2f62c6da'),
    'cooklang': ('addcninblue/tree-sitter-cooklang', '4ebe237c1cf64cf3826fc249e9ec0988fe07e58e'),
    'corn': ('jakestanger/tree-sitter-corn', '464654742cbfd3a3de560aba120998f1d5dfa844'),
    'eex': ('connorlay/tree-sitter-eex', 'f742f2fe327463335e8671a87c0b9b396905d1d1'),
    'elsa': ('glapa-grossklag/tree-sitter-elsa', '0a66b2b3f3c1915e67ad2ef9f7dbd2a84820d9d7'),
    'facility': ('FacilityApi/tree-sitter-facility', 'e4bfd3e960de9f4b4648acb1c92e9b95b47d8cfb'),
    'tmux': ('Freed-Wu/tree-sitter-tmux', '75d1b995b0c23400ac8e49db757a2e0386f9fa8f'),
    'eds': ('uyha/tree-sitter-eds', '26d529e6cfecde391a03c21d1474eb51e0285805'),
}

def fetch(item):
    name, repo, commit, path = item
    url = f'https://api.github.com/repos/{repo}/git/trees/{commit}?recursive=1' if path == 'tree.json' else f'https://raw.githubusercontent.com/{repo}/{commit}/{path}'
    request = urllib.request.Request(url, headers={'User-Agent': 'go-treesitter-license-crosscheck'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(4 * 1024 * 1024 + 1)
    if len(data) > 4 * 1024 * 1024:
        raise ValueError('source size exceeded')
    target = OUT / (name + '-' + path.replace('/', '-'))
    with target.open('xb') as stream:
        stream.write(data)
    row = {'grammar': name, 'source': url, 'path': target.name, 'sha256': hashlib.sha256(data).hexdigest()}
    if path == 'tree.json':
        tree = json.loads(data)
        assert not tree.get('truncated') and tree['sha'] == commit
        row['notice_paths'] = [x['path'] for x in tree['tree'] if any(s in x['path'].lower() for s in ('license', 'licence', 'copying', 'copyright', 'notice'))]
    return row

items = [(name, *identity, path) for name, identity in SOURCES.items() for path in ('Cargo.toml', 'tree.json')]
items += [('elsa', *SOURCES['elsa'], 'grammar.js')]
with ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(fetch, items))
with (OUT / 'inventory.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(rows, stream, indent=2)
    stream.write('\n')
print(json.dumps([{r['grammar']: r['notice_paths']} for r in rows if 'notice_paths' in r]))
