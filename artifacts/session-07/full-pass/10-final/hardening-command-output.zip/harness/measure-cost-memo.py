import random
from receipt import ROOT, OUT, save, run, sha
tasks=[]
rng=random.Random(728)
for seed in range(1,6):
    names=['uncached','memo'];rng.shuffle(names)
    tasks.extend((name,seed) for name in names)
paths={'uncached':ROOT/'.scratch/full-pass/bench-candidate.exe','memo':ROOT/'.scratch/full-pass/recovery-cost-memo/test.exe'}
save(OUT/'07-performance/memo-plan.json',dict(tasks=tasks,iterations=100,executables={k:sha(v.read_bytes()) for k,v in paths.items()},
    claim='focused C# recovery cost measurement; full candidate comparison follows adoption'))
for name,seed in tasks:
    run('07-performance/memo-'+name+'-'+str(seed),[str(paths[name]),'-test.run=^$',
        '-test.bench=^BenchmarkRelease$/^cs-recovery$/^full$','-test.benchtime=100x','-test.benchmem','-test.timeout=45s',
        '-release-seed='+str(seed)],cwd=ROOT/'internal/gtsadapter',timeout=60)
