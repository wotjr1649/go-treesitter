import json
import random
from receipt import ROOT, OUT, ENV, save, run, sha
dest=ROOT/'.scratch/full-pass/raw-child-memo'
overlay=json.loads((dest/'overlay.json').read_text(encoding='utf-8'))
overlay['Replace'][str(ROOT/'internal/runtime/recovery_hardening_test.go')]=str(ROOT/'tools/runtime-bundle/testdata/recovery_hardening_test.go')
save(dest/'private-overlay.json',overlay)
run('raw-child-memo-private',['go','test','-overlay='+str(dest/'private-overlay.json'),'./internal/runtime',
    '-run','^Test(RecoveryRawLeafCost|SharedClosedRecoveryPrefix|RecoveryAcceptanceOrder|EOFTransitions)$','-count=1','-timeout=30s','-json'])
tasks=[]
rng=random.Random(1065)
for seed in range(1,6):
    names=['before','after'];rng.shuffle(names)
    tasks.extend((name,seed) for name in names)
paths={'before':ROOT/'.scratch/full-pass/bench-final.exe','after':dest/'test.exe'}
save(OUT/'10-final/performance/raw-child-plan.json',dict(tasks=tasks,iterations=150,executables={k:sha(v.read_bytes()) for k,v in paths.items()}))
for name,seed in tasks:
    run('10-final/performance/raw-child-'+name+'-'+str(seed),[str(paths[name]),'-test.run=^$',
        '-test.bench=^BenchmarkRelease$/^(tsx|cs-recovery)$/^(delete|full)$','-test.benchtime=150x',
        '-test.benchmem','-test.timeout=60s','-release-seed='+str(seed)],cwd=ROOT/'internal/gtsadapter',timeout=75)
