"""Resolve public module metadata in a task-only modfile; execute no packages."""
from receipt import ROOT, ENV, run

for src, dst in (('go.mod', 'graph.mod'), ('go.sum', 'graph.sum')):
    path = ROOT / '.scratch/full-pass' / dst
    with path.open('xb') as stream:
        stream.write((ROOT / src).read_bytes())
env = ENV | {'GOPROXY': 'https://proxy.golang.org', 'GOSUMDB': 'sum.golang.org',
             'GOPRIVATE': '', 'GONOPROXY': '', 'GONOSUMDB': ''}
run('00-module-graph', ['go', 'list', '-modfile=.scratch/full-pass/graph.mod', '-mod=mod', '-m', '-json', 'all'], timeout=60, env=env)
