import json
from pathlib import Path
import subprocess
from receipt import ROOT, OUT, ENV, run, save, sha

work = ROOT / '.scratch/full-pass/csharp-preserve-errors'
work.mkdir(exist_ok=False)
base = json.loads((ROOT / '.scratch/full-pass/csharp-pending-02/overlay.json').read_text(encoding='utf-8'))
original = ROOT / 'internal/runtime/parser_result_csharp.go'
source = original.read_text(encoding='utf-8')
needle = 'func normalizeCSharpCompatibility(root *Node, source []byte, p *Parser, lang *Language) {'
assert source.count(needle) == 1
source = source.replace(needle, needle + '\n\tif root != nil && root.HasError() { return }', 1)
backing = work / 'csharp.go.txt'
backing.write_text(source, encoding='utf-8', newline='\n')
base['Replace'][str(original)] = str(backing)
overlay = work / 'overlay.json'
save(overlay, base)
exe = work / 'preserve-errors.exe'
run('03-csharp-preserve-errors/build', ['go', 'build', '-trimpath', '-overlay=' + str(overlay), '-o', str(exe), './.scratch/full-pass/probe.go'], timeout=120)
prior = json.loads((OUT / '03-csharp-order/comparison.json').read_text(encoding='utf-8'))
requests = [{'ID': r['id'], 'Filename': 'x.cs', 'Source': r['source'], 'Repeat': 1} for r in prior['rows']]
result = subprocess.run([str(exe)], input=json.dumps(requests).encode(), capture_output=True, env=ENV, check=True, timeout=120)
actual = {r['ID']: r for r in map(json.loads, result.stdout.splitlines())}
rows = []
for row in prior['rows']:
    g = actual[row['id']]
    rows.append({'id': row['id'], 'source_sha256': row['source_sha256'], 'equal_c': g['Nodes'] == row['c']['nodes'], 'go': g})
    print(row['id'], rows[-1]['equal_c'], len(g['Nodes']), len(row['c']['nodes']))
save(OUT / '03-csharp-preserve-errors/comparison.json', {
    'candidate_sha256': sha(exe.read_bytes()), 'input_receipt_sha256': sha((OUT / '03-csharp-order/comparison.json').read_bytes()),
    'overlays': {name: sha(Path(path).read_bytes()) for name, path in base['Replace'].items()}, 'rows': rows})
