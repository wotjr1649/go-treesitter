import json
import subprocess
import zipfile
from pathlib import PurePosixPath
from receipt import ROOT, OUT, ENV, save, run, sha

dest=ROOT/'.scratch/full-pass/performance-baseline'
archive=ROOT/'.scratch/full-pass/performance-baseline.zip'
assert not dest.exists() and not archive.exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,env=ENV).decode().strip()
subprocess.run(['git','archive','--format=zip','--output='+str(archive),commit,'--','go.mod','go.sum','*.go','internal','syntax','testdata/newtonsoft','tools/measure'],cwd=ROOT,env=ENV,timeout=90,check=True)
with zipfile.ZipFile(archive) as z:
    assert sum(x.file_size for x in z.infolist())<512*1024*1024
    for info in z.infolist():
        path=PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts and ':' not in info.filename and '\\' not in info.filename
        if info.is_dir(): continue
        target=dest.joinpath(*path.parts)
        assert target.resolve().is_relative_to(dest.resolve())
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f: f.write(z.read(info))
benchmark=ROOT/'internal/gtsadapter/benchmark_test.go'
(dest/'internal/gtsadapter/benchmark_test.go').write_bytes(benchmark.read_bytes())
save(OUT/'07-performance/plan.json',dict(baseline_commit=commit,
    baseline_archive_sha256=sha(archive.read_bytes()),
    baseline_runtime_sha256=sha((dest/'internal/provenance/runtime.json').read_bytes()),
    candidate_runtime_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    benchmark_sha256=sha(benchmark.read_bytes()),seeds=[1,2,3,4,5],iterations_per_benchmark=40,
    gomaxprocs=4,order='each pair randomized with fixed seed 20260923; cases/modes shuffled per release-seed',
    analysis='paired ratios, medians and full range; exact two-sided sign test across five samples; no favorable reruns',
    regression_policy='large changes require profiling; correctness takes priority; no absolute latency SLO exists'))
for name,cwd in [('baseline',dest),('candidate',ROOT)]:
    run('07-performance/build-'+name,['go','test','-c','-o',str(ROOT/'.scratch/full-pass'/('bench-'+name+'.exe')),'./internal/gtsadapter'],cwd=cwd,timeout=180)
