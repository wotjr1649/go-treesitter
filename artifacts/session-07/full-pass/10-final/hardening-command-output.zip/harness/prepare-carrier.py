import difflib
import json
import zipfile
from receipt import ROOT, sha, save

archive = ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'
baseline = json.loads((ROOT / 'internal/provenance/identities.json').read_text(encoding='utf-8'))['baseline']
packages = ['.', 'internal/luapattern', 'internal/parsercorephase0', 'grammars',
            'grammars/runtime', 'grammars/internal/standaloneregistry', 'grammars/internal/pythonruntime']
assets = ['LICENSE', 'grammars/languages.lock', 'testdata/result_compat_ownership_v1.json']
from pathlib import PurePosixPath
with zipfile.ZipFile(archive) as zipped:
    files = []
    prefix = baseline['module'] + '@' + baseline['version'] + '/'
    for name in zipped.namelist():
        path = PurePosixPath(name.removeprefix(prefix))
        if (str(path.parent) in packages and path.suffix == '.go' and not path.name.endswith('_test.go') or
                str(path) in assets or str(path.parent) == 'grammars/grammar_blobs' and path.suffix == '.bin'):
            files.append(str(path))
save(ROOT / 'tools/runtime-bundle/source.json', {
    'baseline': baseline, 'archive_sha256': sha(archive.read_bytes()),
    'internal_module': 'github.com/wotjr1649/go-treesitter/internal/runtime',
    'packages': packages, 'assets': assets, 'file_count': len(files),
    'patches': ['KR-0001b-jsx-text.patch']})
patch = []
for name in ('grammars/runtime/javascript_scanner.go', 'grammars/runtime/tsx_scanner.go'):
    original = (ROOT / '.scratch/session07-runtime' / name).read_text(encoding='utf-8').splitlines(keepends=True)
    fixed = (ROOT / '.scratch/kr0001b-candidate' / name).read_text(encoding='utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(original, fixed, fromfile='a/' + name, tofile='b/' + name))
path = ROOT / 'tools/runtime-bundle/patches/KR-0001b-jsx-text.patch'
path.parent.mkdir(parents=True, exist_ok=True)
with path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(''.join(patch))
print(len(files), 'files selected')
