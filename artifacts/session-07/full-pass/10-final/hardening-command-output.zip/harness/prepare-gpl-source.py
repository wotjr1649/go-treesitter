import json
from pathlib import Path, PurePosixPath
import shutil
import zipfile
from receipt import ROOT, OUT, ENV, run, save, sha

source = ROOT / 'grammars/gpl/sources'
archive = ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'
prefix = 'github.com/odvcencio/gotreesitter@v0.53.0/'
packages = {'.', 'internal/luapattern', 'internal/parsercorephase0', 'internal/grammarpatch', 'cmd/ts2go'}
manifest = {}
with zipfile.ZipFile(archive) as original, zipfile.ZipFile(source / 'ts2go-source.zip', 'x', zipfile.ZIP_DEFLATED) as output:
    for name in sorted(original.namelist()):
        rel = PurePosixPath(name.removeprefix(prefix))
        selected = str(rel.parent) in packages and rel.suffix == '.go' and not rel.name.endswith('_test.go')
        selected |= str(rel) in ('LICENSE', 'go.mod', 'go.sum', 'testdata/result_compat_ownership_v1.json', 'grammars/grammar_blobs/go.bin')
        if not selected:
            continue
        data = original.read(name)
        output.writestr(str(rel), data)
        manifest[str(rel)] = sha(data)
save(source / 'ts2go-source.json', {'module_archive_sha256': sha(archive.read_bytes()), 'files': manifest})
shutil.copyfile(OUT / '05-licenses/acquisition/golang-x-sync-v0.11.0.zip', source / 'golang-x-sync-v0.11.0.zip')
work = ROOT / '.scratch/full-pass/gpl-source-reproduction-v2'
work.mkdir(exist_ok=False)

def extract(archive, output, strip=0):
    with zipfile.ZipFile(archive) as zipped:
        total = 0
        seen = set()
        for info in zipped.infolist():
            p = PurePosixPath(info.filename)
            if info.is_dir():
                continue
            if p.is_absolute() or '..' in p.parts or '\\' in str(p) or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('unsafe source path')
            p = PurePosixPath(*p.parts[strip:])
            if not p.parts or str(p).lower() in seen:
                raise ValueError('duplicate source path')
            seen.add(str(p).lower())
            total += info.file_size
            if total > 100 * 1024 * 1024:
                raise ValueError('source size limit')
            target = output / str(p)
            target.resolve().relative_to(output.resolve())
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(zipped.read(info))

extract(source / 'ts2go-source.zip', work / 'converter')
extract(source / 'golang-x-sync-v0.11.0.zip', work / 'sync', 3)
# A task-local workspace supplies the vendored public build dependency offline.
workspace = work / 'go.work'
workspace.write_text('go 1.27.1\n\nuse (\n' + json.dumps(str(work / 'converter')) + '\n' +
                     json.dumps(str(work / 'sync')) + '\n)\n', encoding='utf-8', newline='\n')
env = dict(ENV, GOWORK=str(workspace))
run('gpl-converter-build-v2', ['go', 'build', '-o', str(work / 'ts2go.exe'), './cmd/ts2go'], 120, cwd=work / 'converter', env=env)
rows = []
for name in ('caddy', 'disassembly', 'jq'):
    extract(source / (name + '.zip'), work / name, 1)
    target = work / 'generated' / name
    target.mkdir(parents=True)
    run('gpl-rebuild-' + name, [str(work / 'ts2go.exe'), '-input', str(work / name / 'src/parser.c'),
                              '-output', str(target / (name + '.go')), '-name', name], 60)
    actual = sha((target / 'grammar_blobs' / (name + '.bin')).read_bytes())
    expected = sha((ROOT / 'grammars/gpl/internal/gtsadapter/grammar_blobs' / (name + '.bin')).read_bytes())
    rows.append({'grammar': name, 'generated_sha256': actual, 'origin_blob_sha256': expected, 'equal': actual == expected})
save(OUT / '05-licenses/blob-source-reproduction.json', rows)
print(json.dumps(rows))
