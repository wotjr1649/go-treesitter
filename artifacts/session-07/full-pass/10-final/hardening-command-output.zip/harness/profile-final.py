from receipt import ROOT, run
for case,mode,count in [('tsx','delete',300),('cs-recovery','full',200),('go','query',1000000)]:
    for name,binary in [('baseline','bench-baseline.exe'),('candidate','bench-final.exe')]:
        cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
        profile=ROOT/'.scratch/full-pass'/f'final-{case}-{mode}-{name}.pprof'
        run(f'10-final/performance/profile-{case}-{mode}-{name}',[str(ROOT/'.scratch/full-pass'/binary),
            '-test.run=^$',f'-test.bench=^BenchmarkRelease$/^{case}$/^{mode}$',
            f'-test.benchtime={count}x','-test.benchmem','-test.timeout=60s','-test.cpuprofile='+str(profile)],cwd=cwd,timeout=75)
        run(f'10-final/performance/profile-{case}-{mode}-top-{name}',
            ['go','tool','pprof','-top','-cum','-nodecount=35',str(profile)],timeout=30)
