from receipt import ROOT, run
for name in ('baseline','candidate'):
    cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
    profile=ROOT/'.scratch/full-pass'/('recovery-'+name+'.pprof')
    run('07-performance/profile-'+name,[str(ROOT/'.scratch/full-pass'/('bench-'+name+'.exe')),
        '-test.run=^$','-test.bench=^BenchmarkRelease$/^cs-recovery$/^full$',
        '-test.benchtime=200x','-test.benchmem','-test.timeout=45s','-test.cpuprofile='+str(profile)],cwd=cwd,timeout=60)
    run('07-performance/profile-top-'+name,['go','tool','pprof','-top','-nodecount=25',str(profile)],timeout=30)
