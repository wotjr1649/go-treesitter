"""Public-only requests; no credentials, repository bytes, or derived queries."""
import json
import urllib.request
from receipt import ROOT, OUT, save, sha

urls=[f'https://api.github.com/repos/odvcencio/gotreesitter/issues/{n}' for n in (1064,1065,728,454,1242)]
urls+=['https://api.github.com/repos/tree-sitter/go-tree-sitter/issues?state=all&per_page=100',
       'https://api.github.com/repos/odvcencio/gotreesitter/issues?state=open&per_page=100']
rows=[]
for i,url in enumerate(urls):
    request=urllib.request.Request(url,headers={'User-Agent':'public-source-review','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(request,timeout=20) as response:
        assert response.url.startswith('https://api.github.com/')
        data=response.read(2_000_001)
    assert len(data)<=2_000_000
    payload=json.loads(data)
    items=payload if isinstance(payload,list) else [payload]
    filtered=[{k:item.get(k) for k in ('number','title','state','created_at','updated_at','closed_at','html_url','body')} for item in items]
    save(ROOT/'.scratch/full-pass/public-audit'/f'{i}.json',filtered)
    rows.append(dict(url=url,response_sha256=sha(data),items=[{k:item[k] for k in ('number','title','state','updated_at','html_url')} for item in filtered]))
save(OUT/'09-audit/public-sources.json',rows)
for row in rows:
    for item in row['items']:
        print(item['number'],item['state'],item['title'].encode('ascii','backslashreplace').decode())
