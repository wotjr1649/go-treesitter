from receipt import ROOT, save, run

dest=ROOT/'.scratch/full-pass/raw-child-memo'
dest.mkdir()
path=ROOT/'internal/runtime/parser_reduce.go'
text=path.read_text(encoding='utf-8')
start=text.index('func (p *Parser) rawStackEntryErrorCost(')
at=text.index('\t\t_, childCount, _ := rawStackWalkEntryHeader(arena, item)',start)
code='''		// A captured edge may reference an older raw shape of a live Node.
		// Reuse only an aggregate for this arena, shape and node version.
		if n := stackEntryNode(item.entry); n != nil && n.symbol != errorSymbol &&
			n.ownerArena == arena && (!item.shapeRefKnown || item.shapeRef == n.rawShape) && len(p.cNodeMemoCache) > 0 {
			if slot := p.cNodeMemoPrimaryHit(n); slot != nil && slot.hasCost && slot.ver == n.equivVersion {
				cost += slot.cost
				continue
			}
		}
'''
text=text[:at]+code+text[at:]
(dest/'parser_reduce.go').write_text(text,encoding='utf-8',newline='\n')
save(dest/'overlay.json',{'Replace':{str(path):str(dest/'parser_reduce.go')}})
run('raw-child-memo-build',['go','test','-overlay='+str(dest/'overlay.json'),'-c','-o',str(dest/'test.exe'),'./internal/gtsadapter'])
run('raw-child-memo-correctness',[str(dest/'test.exe'),'-test.count=1','-test.timeout=120s','-test.v'],cwd=ROOT/'internal/gtsadapter',timeout=150)
