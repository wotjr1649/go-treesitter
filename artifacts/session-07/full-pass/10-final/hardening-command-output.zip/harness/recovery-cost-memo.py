from receipt import ROOT, save, run

dest=ROOT/'.scratch/full-pass/recovery-cost-memo'
dest.mkdir()
path=ROOT/'internal/runtime/parser_recover_c.go'
s=path.read_text(encoding='utf-8')
early='''	if p != nil && n != nil && n.symbol != errorSymbol && n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
		return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
	}

'''
assert s.count(early)==1
s=s.replace(early,'')
start=s.index('func (p *Parser) cNodeErrorCost(n *Node) uint32 {')
end=s.index('// cNodeErrorCostAndVisibleSubtreeCount',start)
body=s[start:end]
body=body.replace('if len(n.children) == 0 && n.symbol != errorSymbol {','hasRawCost := n.symbol != errorSymbol && n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef\n\tif len(n.children) == 0 && n.symbol != errorSymbol && !hasRawCost {',1)
body=body.replace('''		if n.rawShape != 0 && n.rawShape != rawShapeZeroChildRef {
			return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
		}
''','',1)
body=body.replace('''	if len(p.cNodeMemoCache) == 0 {
		return cNodeErrorCostLang(p.language, n)
	}''','''	if len(p.cNodeMemoCache) == 0 {
		if hasRawCost {
			return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
		}
		return cNodeErrorCostLang(p.language, n)
	}''',1)
pos=body.index('\tvar cost uint32\n')
endcost=body.index('\t// Re-fetch the slot:',pos)
old=body[pos:endcost]
new='''	var cost uint32
	if hasRawCost {
		// Raw shapes preserve hidden missing leaves. Cache their cost with
		// the same node/version lifetime as visible recovery aggregates.
		cost = p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n))
	} else {
'''+old[len('\tvar cost uint32\n'):]+ '\t}\n'
body=body[:pos]+new+body[endcost:]
s=s[:start]+body+s[end:]
needle='return p.rawStackEntryErrorCost(n.ownerArena, newStackEntryNode(n.parseState, n)), p.cNodeVisibleSubtreeCount(n)'
assert s.count(needle)==1
s=s.replace(needle,'return p.cNodeErrorCost(n), p.cNodeVisibleSubtreeCount(n)')
p=dest/'parser_recover_c.go';p.write_text(s,encoding='utf-8',newline='\n')
save(dest/'overlay.json',{'Replace':{str(path):str(p)}})
run('recovery-cost-memo-build',['go','test','-overlay='+str(dest/'overlay.json'),'-c','-o',str(dest/'test.exe'),'./internal/gtsadapter'])
