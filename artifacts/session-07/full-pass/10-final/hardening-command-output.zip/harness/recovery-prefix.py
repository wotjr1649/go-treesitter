import json
from pathlib import Path
import subprocess
from receipt import ROOT, ENV, OUT, save, run

base = ROOT / '.scratch/full-pass/recovery-reviewed'
dest = ROOT / '.scratch/full-pass/recovery-prefix'
dest.mkdir()
overlay = json.loads((base / 'overlay.json').read_text())
p = dest / 'incremental.go'
s = (base / 'incremental.go').read_text(encoding='utf-8')
needle = '\t\tnextState, truncateDepth, ok := p.reuseNonLeafTargetStateOnStack(s, n)'
assert s.count(needle) == 1
s = s.replace(needle, '''		if !reuseLeadingPrefixMatches(n, lookahead) {
			continue
		}
''' + needle)
needle = 'func (p *Parser) reuseTargetState(state StateID, n *Node, lookahead Token) (StateID, bool) {\n'
assert s.count(needle) == 1
s = s.replace(needle, '''// The first token owns the lexer's proof of skipped source padding. An edit
// can add that padding without touching the token bytes. Reparse its first
// shift if the old subtree lacks this proof; reuse must not erase it.
func reuseLeadingPrefixMatches(n *Node, lookahead Token) bool {
	return !lookahead.lexerSkippedPrefix() || lookahead.lexerSkippedPrefixStart != 0 ||
		n.hasLeadingLexerSkippedPrefixAtSourceStart()
}

''' + needle + '''	if !reuseLeadingPrefixMatches(n, lookahead) {
		return 0, false
	}
''')
p.write_text(s, encoding='utf-8', newline='\n')
subprocess.run(['gofmt', '-w', str(p)], env=ENV, timeout=30, check=True)
overlay['Replace'][str(ROOT / 'internal/runtime/incremental.go')] = str(p)
save(dest / 'overlay.json', overlay)
run('recovery-prefix-build', ['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
