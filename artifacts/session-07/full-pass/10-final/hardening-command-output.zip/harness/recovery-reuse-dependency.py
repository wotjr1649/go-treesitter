import json
from pathlib import Path
from receipt import ROOT, ENV, save, run

base = ROOT / '.scratch/full-pass/recovery-prefix'
dest = ROOT / '.scratch/full-pass/recovery-reuse-dependency'
dest.mkdir()
overlay = json.loads((base / 'overlay.json').read_text(encoding='utf-8'))
p = dest / 'incremental.go'
s = (base / 'incremental.go').read_text(encoding='utf-8')
needle = '\t\tif !reuseLeadingPrefixMatches(n, lookahead) {\n'
assert s.count(needle) == 1
s = s.replace(needle, '''		// Interior reductions depend on lookahead beyond their visible span.
		// The compact producer records that extent; classic nodes without a
		// receipt must replay their leaves rather than assume the same reduce.
		lookaheadBytes, hasDependency := compactReuseDependencyForNode(n)
		dependencyEnd := uint64(n.EndByte()) + uint64(lookaheadBytes)
		if !hasDependency || dependencyEnd > uint64(len(idx.newSource)) ||
			idx.rightBoundaryTouchedByEdit(uint32(dependencyEnd)) ||
			!idx.nodeBytesUnchanged(n.StartByte(), uint32(dependencyEnd)) {
			idx.rejectStaleNonLeafBoundary++
			continue
		}
''' + needle)
p.write_text(s,encoding='utf-8',newline='\n')
overlay['Replace'][str(ROOT/'internal/runtime/incremental.go')]=str(p)
save(dest/'overlay.json',overlay)
run('recovery-reuse-dependency-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
