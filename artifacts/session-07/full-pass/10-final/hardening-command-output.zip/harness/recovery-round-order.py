import json
from pathlib import Path
from receipt import ROOT, save, run

base=ROOT/'.scratch/full-pass/recovery-final-review-v2'
dest=ROOT/'.scratch/full-pass/recovery-round-order'
dest.mkdir()
overlay=json.loads((base/'overlay.json').read_text(encoding='utf-8'))
target=str(ROOT/'internal/runtime/parser_recover_c.go')
s=Path(overlay['Replace'][target]).read_text(encoding='utf-8')
needle='\t\tres, forked, reason := p.cRecover(stacks, v, source, tok, nodeCount, arena, entryScratch, gssScratch, trackChildErrors)'
assert s.count(needle)==1
s=s.replace(needle,'\t\tbeforeRecover := len(*stacks)\n'+needle)
needle='\t\tif forked {\n\t\t\tneedsRedispatch = true\n\t\t}'
assert s.count(needle)==1
s=s.replace(needle, '''		if forked {
			// handle_error runs at the end of C's version round. Its new
			// strategy-1 forks first run in the next round, after the absorber.
			for j := beforeRecover; j < len(*stacks); j++ {
				fork := &(*stacks)[j]
				if fork.cRecoverPendingToken == nil {
					replay := tok
					fork.cRecoverPendingToken = &replay
				}
				fork.shifted = true
			}
			needsRedispatch = true
		}''')
needle='if (p.language.Name == "javascript" || p.language.Name == "typescript" || p.language.Name == "tsx") && electionToken.StartByte >= tok.StartByte && electionToken.EndByte != tok.EndByte && electionToken.EndByte > electionToken.StartByte {'
assert s.count(needle)==1
s=s.replace(needle, 'if (p.language.Name == "go" || p.language.Name == "javascript" || p.language.Name == "typescript" || p.language.Name == "tsx") && electionToken.StartByte >= tok.StartByte && (electionToken.Symbol != tok.Symbol || electionToken.EndByte != tok.EndByte) && electionToken.EndByte > electionToken.StartByte {')
p=dest/'parser_recover_c.go';p.write_text(s,encoding='utf-8',newline='\n')
overlay['Replace'][target]=str(p)
save(dest/'overlay.json',overlay)
run('recovery-round-order-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
