import importlib.util
import json
from pathlib import Path
from receipt import ROOT, OUT, save, sha

spec = importlib.util.spec_from_file_location('carrier', ROOT / 'tools/runtime-bundle/import.py')
carrier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(carrier)
archive = ROOT / '.scratch/modcache/cache/download/github.com/odvcencio/gotreesitter/@v/v0.53.0.zip'
work = ROOT / '.scratch/full-pass/reproduced-runtime'
actual = carrier.build(archive, work)
expected = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
assert actual == expected
for name in expected['files']:
    assert (work / name).read_bytes() == (ROOT / 'internal/runtime' / name).read_bytes(), name
rejected = []
try:
    carrier.build(archive, work)
except ValueError as error:
    assert 'new task-local directory' in str(error)
    rejected.append('existing-output')
else:
    raise AssertionError('existing output accepted')
bad = ROOT / '.scratch/full-pass/wrong-runtime.zip'
with bad.open('xb') as stream:
    stream.write(b'not the pinned archive')
destination = ROOT / '.scratch/full-pass/rejected-runtime'
try:
    carrier.build(bad, destination)
except ValueError as error:
    assert 'archive hash differs' in str(error)
    rejected.append('changed-archive')
else:
    raise AssertionError('changed archive accepted')
assert not destination.exists()
save(OUT / '02-product-runtime/reproduction.json', {'files': len(expected['files']),
    'manifest_equal': True, 'every_file_equal': True, 'rejected': rejected,
    'manifest_sha256': sha((ROOT / 'internal/provenance/runtime.json').read_bytes())})
print('reproduced', len(expected['files']), 'exact files; rejected:', rejected)
