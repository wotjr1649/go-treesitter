import json
from receipt import ROOT, OUT, save, sha

receipt = json.loads((OUT / '04-catalog/cobol-c-oracle.json').read_text(encoding='utf-8'))
runtime = ROOT / 'internal/runtime/grammars/grammar_blobs/cobol.bin'
inputs = ROOT / '.scratch/full-pass/additional-grammars/cobol'
save(ROOT / 'testdata/oracle/catalog-cobol.json', {
    'runtime_commit': 'f5afe475deb7c0bae6407fb776c76824f717bb61',
    'grammar_commit': 'e99dbdc3d800d5fa2796476efd60af91f6b43d93',
    'blob_sha256': sha(runtime.read_bytes()),
    'source_hashes': {name: sha((inputs / name).read_bytes()) for name in ('src/parser.c', 'src/scanner.c', 'src/tree_sitter/parser.h', 'LICENSE')},
    'driver_sha256': sha((ROOT / 'tools/native-oracle/driver.c').read_bytes()),
    'build_receipt': 'artifacts/session-07/full-pass/04-catalog/build-cobol-oracle.json',
    'oracle_sha256': receipt['oracle_sha256'], 'rows': receipt['rows']})
