import json
import re
from pathlib import Path
from receipt import ROOT, OUT, save, sha

names = ['ts-split-pending-campaign', 'go-c-eof-expanded-cases',
         'leading-prefix-cases', 'ts-string-expanded-cases',
         'bare-amp-cases', 'jsx-hash-cases', 'tsx-paren-cases']
languages = {'.go': 'go', '.ts': 'typescript', '.tsx': 'tsx',
             '.js': 'javascript', '.jsx': 'javascript'}
cases, origins, seen, ids = [], {}, set(), set()
for name in names:
    for row in json.loads((OUT / '06-correctness' / (name + '.json')).read_text(encoding='utf-8'))['cases']:
        row = dict(row)
        language = languages[Path(row['Filename']).suffix]
        if name == 'bare-amp-cases':
            start = row['Source'].encode().index(b'&') + 1
            row['Previous'] = row['Source'].replace('&', '&amp;', 1)
            row['Edit'] = dict(StartByte=start, OldEndByte=start+4, NewEndByte=start)
        key = json.dumps([row['Filename'], row['Source'], row.get('Previous'), row.get('Edit')], sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        case = {'id': re.sub('[^A-Za-z0-9_-]', '-', row['ID']), 'language': language,
                'filename': row['Filename'], 'group': name, 'source': row['Source'],
                'sha256': sha(row['Source'].encode())}
        if case['id'] in ids:
            case['id'] += '-' + sha(key.encode())[:8]
        ids.add(case['id'])
        if 'Previous' in row:
            origin_key = (row['Filename'], row['Previous'])
            if origin_key not in origins:
                origin = dict(id='RH-before-' + sha(json.dumps(origin_key).encode())[:16],
                              language=language, filename=row['Filename'], group='clean',
                              source=row['Previous'], sha256=sha(row['Previous'].encode()))
                origins[origin_key] = origin
                cases.append(origin)
            case.update(previous=origins[origin_key]['id'], edit=row['Edit'])
        cases.append(case)
save(ROOT / 'testdata/oracle/runtime-hardening-cases.json', cases)
save(OUT / '06-correctness/runtime-hardening-inventory.json', {
    'inputs': {name: sha((OUT / '06-correctness' / (name + '.json')).read_bytes()) for name in names},
    'catalog_sha256': sha((ROOT / 'testdata/oracle/runtime-hardening-cases.json').read_bytes()),
    'count': len(cases), 'edits': sum('edit' in c for c in cases), 'origins': len(origins)})
print('Retained', len(cases), 'cases,', sum('edit' in c for c in cases), 'edits')
