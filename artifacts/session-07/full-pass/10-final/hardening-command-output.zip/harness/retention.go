// Windows-only measurement executable; no product dependency or background worker.
package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"syscall"
	"time"
	"unsafe"

	treesitter "github.com/wotjr1649/go-treesitter"
	"github.com/wotjr1649/go-treesitter/syntax"
)

type memoryCounters struct {
	Size, PageFaults                                                     uint32
	PeakWorkingSet, WorkingSet, PeakPagedPool, PagedPool                 uintptr
	PeakNonPagedPool, NonPagedPool, Pagefile, PeakPagefile, PrivateUsage uintptr
}

var memoryInfo = syscall.NewLazyDLL(filepath.Join(os.Getenv("SystemRoot"), "System32", "kernel32.dll")).NewProc("K32GetProcessMemoryInfo")
var encoder = json.NewEncoder(os.Stdout)
var opened, closed, peakArena, peakScratch, peakDepth, totalParses int64
var started = time.Now()

func checkpoint(name string, cycle int, collect bool) {
	if collect {
		runtime.GC()
		runtime.GC()
	}
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	rss := memoryCounters{}
	rss.Size = uint32(unsafe.Sizeof(rss))
	ok, _, err := memoryInfo.Call(^uintptr(0), uintptr(unsafe.Pointer(&rss)), uintptr(rss.Size))
	if ok == 0 {
		panic(err)
	}
	if opened != closed {
		panic("unclosed measurement tree")
	}
	if err := encoder.Encode(struct {
		Phase                                                       string
		Cycle                                                       int
		Milliseconds                                                int64
		HeapAlloc, HeapObjects, HeapSys, TotalAlloc, Mallocs, Frees uint64
		WorkingSet, PeakWorkingSet, PrivateUsage                    uintptr
		Goroutines                                                  int
		Opened, Closed, Parses, PeakArena, PeakScratch, PeakDepth   int64
	}{name, cycle, time.Since(started).Milliseconds(), m.HeapAlloc, m.HeapObjects, m.HeapSys,
		m.TotalAlloc, m.Mallocs, m.Frees, rss.WorkingSet, rss.PeakWorkingSet, rss.PrivateUsage,
		runtime.NumGoroutine(), opened, closed, totalParses, peakArena, peakScratch, peakDepth}); err != nil {
		panic(err)
	}
}

type input struct {
	Name, Filename string
	Source         []byte
	Recovery       bool
}

func main() {
	checkpoint("cold-process", 0, true)
	var inputs []input
	for _, c := range []struct{ ext, format string }{
		{"go", "func f%d() int { return %d }\n"}, {"py", "def f%d():\n    return %d\n"},
		{"js", "const value%d = %d;\n"}, {"jsx", "const View%d = () => <p>{%d}</p>;\n"},
		{"ts", "const value%d: number = %d;\n"}, {"tsx", "const View%d = () => <p>{%d}</p>;\n"},
		{"cs", "class C%d { public int F() => %d; }\n"},
	} {
		var source bytes.Buffer
		if c.ext == "go" {
			source.WriteString("package p\n")
		}
		for i := range 128 {
			fmt.Fprintf(&source, c.format, i, i)
		}
		inputs = append(inputs, input{c.ext, "memory." + c.ext, source.Bytes(), false})
	}
	var large bytes.Buffer
	large.WriteString("package p\n")
	for i := range 8192 {
		fmt.Fprintf(&large, "var item%d = %d\n", i, i)
	}
	inputs = append(inputs, input{"go-large", "memory.go", large.Bytes(), false})
	source, err := os.ReadFile("testdata/newtonsoft/JsonTextReader-excerpt.cs")
	if err != nil {
		panic(err)
	}
	inputs = append(inputs, input{"cs-recovery", "memory.cs", source, true})
	for _, c := range inputs {
		if err := encoder.Encode(map[string]any{"input": c.Name, "bytes": len(c.Source), "sha256": fmt.Sprintf("%x", sha256.Sum256(c.Source))}); err != nil {
			panic(err)
		}
	}
	p := treesitter.New()
	parse := func(req syntax.Request) syntax.Result {
		r, err := p.Parse(context.Background(), req)
		totalParses++
		if r.Tree != nil {
			opened++
		}
		if err != nil || !r.Complete() {
			if r.Tree != nil {
				r.Tree.Close()
				closed++
			}
			panic(fmt.Sprintf("incomplete parse: %v %+v", err, r.Diagnostics))
		}
		peakArena = max(peakArena, r.ArenaBytes)
		peakScratch = max(peakScratch, r.ScratchBytes)
		peakDepth = max(peakDepth, int64(r.PeakStackDepth))
		return r
	}
	cycle := func() {
		for _, c := range inputs {
			r := parse(syntax.Request{Filename: c.Filename, Source: c.Source, Timeout: 5 * time.Second})
			if !c.Recovery {
				if r.Outcome != syntax.AcceptedClean {
					r.Tree.Close()
					closed++
					panic("clean workload changed")
				}
				after := append(bytes.Clone(c.Source), '\n')
				end := uint32(len(c.Source))
				inc := parse(syntax.Request{Filename: c.Filename, Source: after, Previous: r.Tree,
					Edit: &syntax.Edit{StartByte: end, OldEndByte: end, NewEndByte: end + 1}, Timeout: 5 * time.Second})
				inc.Tree.Close()
				closed++
			}
			r.Tree.Close()
			closed++
		}
	}
	cycle()
	checkpoint("warm", 1, true)
	for block := 1; block <= 12; block++ {
		for range 16 {
			cycle()
		}
		checkpoint("steady", 1+block*16, true)
	}
	debug.FreeOSMemory()
	checkpoint("after-scavenge", 193, false)
}
