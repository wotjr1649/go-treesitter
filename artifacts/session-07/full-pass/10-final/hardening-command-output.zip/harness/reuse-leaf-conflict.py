from receipt import ROOT,save,run
p=ROOT/'internal/runtime/incremental.go'
s=p.read_text(encoding='utf-8')
needle='if action == nil || len(action.Actions) == 0 {'
assert s.count(needle)==1
s=s.replace(needle,'if action == nil || len(action.Actions) != 1 {')
dest=ROOT/'.scratch/full-pass/reuse-leaf-conflict';dest.mkdir()
q=dest/'incremental.go';q.write_text(s,encoding='utf-8',newline='\n')
save(dest/'overlay.json',{'Replace':{str(p):str(q)}})
run('reuse-leaf-conflict-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/large-profile.go')])
run('07-resources/reuse-leaf-conflict',[str(dest/'probe.exe'),'8192','-'],timeout=30)
