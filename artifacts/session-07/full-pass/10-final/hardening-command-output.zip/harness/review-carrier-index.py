import hashlib
import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

manifest = json.loads((ROOT / 'internal/provenance/runtime.json').read_text(encoding='utf-8'))
indexed = subprocess.check_output(['git', 'ls-files', '--stage', '-z', '--', 'internal/runtime'], cwd=ROOT).split(b'\0')
count = 0
for record in indexed:
    if not record:
        continue
    metadata, path = record.decode().split('\t')
    mode, expected, stage = metadata.split()
    assert mode == '100644' and stage == '0'
    data = (ROOT / path).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == expected, path
    assert sha(data) == manifest['files'][path.removeprefix('internal/runtime/')]['sha256'], path
    count += 1
assert count == len(manifest['files'])
check = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, env=ENV, capture_output=True)
warnings = check.stdout.decode()
assert not check.stderr
heads = [line for line in warnings.splitlines() if not line.startswith('+')]
assert len(heads) == 13
assert heads[0] == 'internal/runtime/grammars/linguist_gen.go:1475: new blank line at EOF.'
assert all(line.startswith('tools/runtime-bundle/patches/KR-0001b-jsx-text.patch:') and line.endswith('space before tab in indent.') for line in heads[1:])
assert manifest['files']['grammars/linguist_gen.go']['origin_sha256'] == manifest['files']['grammars/linguist_gen.go']['sha256']
save(OUT / '02-product-runtime/index-review.json', {'runtime_files': count,
     'index_equals_manifest': True, 'diff_check_exit': check.returncode,
     'warnings': heads, 'classification': 'One unchanged upstream generated EOF blank; twelve unified-diff context marker lines. No own-source whitespace warning.'})
print('index matches all', count, 'runtime files; known literal/upstream whitespace warnings:', len(heads))
