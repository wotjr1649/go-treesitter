"""Prepare a bounded, formatted candidate without changing product files."""
import json
from pathlib import Path
import subprocess
from receipt import ROOT, ENV, save

base = ROOT / '.scratch/full-pass/combined-recovery-order'
dest = ROOT / '.scratch/full-pass/recovery-reviewed'
dest.mkdir()
overlay = json.loads((base / 'overlay.json').read_text())
for target, origin in list(overlay['Replace'].items()):
    if not target.endswith('.go'):
        continue
    path = dest / Path(target).name
    path.write_bytes(Path(origin).read_bytes())
    overlay['Replace'][target] = str(path)

p = dest / 'parser_recover_c.go'
s = p.read_text(encoding='utf-8')
a = s.index('\tvar rawChildren []rawShapeChild\n')
b = s.index('\troot.dynamicPrecedence', a)
s = s[:a] + '''	// Accept replaces the root's visible children, but its raw ledger must
	// retain invisible MISSING terminals and their recovery cost.
	item := rawStackWalkEntry{entry: newStackEntryNode(cand.parseState, cand)}
	_, rootChildCount, _ := rawStackWalkEntryHeader(arena, item)
	count := rootChildCount + len(nodes) - 1
	if count > rawShapeMaxExactChildCount {
		return ParseStopNodeLimit
	}
	ref, shape := arena.allocRawShape()
	if shape == nil {
		return ParseStopMemoryBudget
	}
	shape.symbol, shape.productionID = cand.symbol, cand.productionID
	shape.childRange = arena.allocRawShapeChildren(count)
	rawChildren := arena.rawShapeChildren(shape)
	if len(rawChildren) != count {
		return ParseStopMemoryBudget
	}
	out := 0
	for i, node := range nodes {
		if i != rootIdx {
			rawChildren[out] = newRawShapeChild(newStackEntryNode(node.parseState, node))
			out++
			continue
		}
		for j := 0; j < rootChildCount; j++ {
			if j&63 == 0 {
				if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
					return reason
				}
			}
			child, ok := rawStackWalkChildAt(arena, item, j)
			if !ok {
				return ParseStopNoStacksAlive
			}
			edge := newRawShapeChild(child.entry)
			edge.packedEntry.state = StateID(rawStackWalkEntryRef(child))
			rawChildren[out] = edge
			out++
		}
	}
	arena.storeRawShapeHash(ref, rawShapeComputeContentHash(arena, ref, cand.symbol, cand.productionID, uint16(count), rawChildren))
	root.rawShape = ref
''' + s[b:]
p.write_text(s, encoding='utf-8', newline='\n')

p = dest / 'parser.go'
s = p.read_text(encoding='utf-8')
needle = '\t\t\ts := &stacks[si]\n\t\t\tif stackRelexActive {'
assert s.count(needle) == 1
s = s.replace(needle, '''			if pendingSteps > 0 {
				if reason := p.parseStopReasonNow(); parseStopReasonIsTerminal(reason) {
					return finalize(stacks, reason)
				}
				if nodeCount > maxNodes {
					return finalize(stacks, ParseStopNodeLimit)
				}
				if stacks[si].depth() > maxDepth {
					return finalize(stacks, ParseStopStackDepthLimit)
				}
				if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
					return finalize(stacks, reason)
				}
			}
''' + needle, 1)
p.write_text(s, encoding='utf-8', newline='\n')
subprocess.run(['gofmt', '-w', *[str(p) for p in dest.glob('*.go')]], env=ENV, timeout=30, check=True)
save(dest / 'overlay.json', overlay)
