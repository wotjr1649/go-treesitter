import random
from receipt import ROOT, OUT, save, run, sha

tasks=[]
rng=random.Random(20260923)
for seed in range(1,6):
    pair=['baseline','candidate'];rng.shuffle(pair)
    tasks.extend((name,seed) for name in pair)
save(OUT/'07-performance/execution-order.json',dict(tasks=tasks,
    executables={name:sha((ROOT/'.scratch/full-pass'/('bench-'+name+'.exe')).read_bytes()) for name in ('baseline','candidate')},
    supplemental_analysis='paired log-ratio t interval (df=4, 95%) with normality caveat, alongside exact sign test and complete range'))
for name,seed in tasks:
    cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
    run('07-performance/'+name+'-'+str(seed),[str(ROOT/'.scratch/full-pass'/('bench-'+name+'.exe')),
        '-test.run=^$','-test.bench=^BenchmarkRelease$','-test.benchtime=40x','-test.benchmem',
        '-test.timeout=180s','-release-seed='+str(seed)],timeout=195,cwd=cwd)
