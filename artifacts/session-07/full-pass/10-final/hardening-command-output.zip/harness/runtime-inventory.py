import json
from pathlib import Path
import subprocess
from receipt import ROOT, OUT, ENV, save

raw = subprocess.check_output(['go', 'list', '-deps', '-json', './internal/gtsadapter'],
                              cwd=ROOT, env=ENV, timeout=60).decode()
decoder, offset, packages = json.JSONDecoder(), 0, []
while offset < len(raw):
    offset += len(raw[offset:]) - len(raw[offset:].lstrip())
    if offset == len(raw):
        break
    package, offset = decoder.raw_decode(raw, offset)
    if package['ImportPath'].startswith('github.com/odvcencio/gotreesitter'):
        packages.append(package)
save(OUT / '02-product-runtime/package-inventory.json', packages)
for package in packages:
    folder = Path(package['Dir'])
    sources = [p for p in folder.glob('*.go') if not p.name.endswith('_test.go')]
    embeds = package.get('EmbedFiles', [])
    print(package['ImportPath'], len(sources), 'Go files,', len(embeds), 'embedded files,',
          sum(p.stat().st_size for p in sources) + sum((folder / p).stat().st_size for p in embeds), 'bytes')
