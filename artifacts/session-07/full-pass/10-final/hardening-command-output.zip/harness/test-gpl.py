from receipt import ROOT, ENV, run

work = ROOT / '.scratch/full-pass/gpl-test.work'
with work.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write('go 1.27.1\n\nuse (\n    "' + ROOT.as_posix() + '"\n    "' + (ROOT / 'grammars/gpl').as_posix() + '"\n)\n')
env = dict(ENV, GOWORK=str(work))
run('gpl-optional-focused', ['go', 'test', './grammars/gpl/...', '-count=1', '-timeout=60s', '-json'], 120, env=env)
