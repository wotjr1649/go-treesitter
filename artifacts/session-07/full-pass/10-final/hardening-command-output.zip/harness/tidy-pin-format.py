import json
import subprocess
from receipt import ROOT

path = ROOT / 'internal/provenance/identities.json'
patch = json.loads(path.read_text())['oracle']['typescript_patch']
before = subprocess.check_output(['git', 'show', 'HEAD:internal/provenance/identities.json'], cwd=ROOT).decode()
needle = '    "build_flags": ["-std=c11", "-fPIC", "-O2"]'
assert before.count(needle) == 1
replacement = needle + ',\n    "typescript_patch": {\n' + ',\n'.join(
    '      ' + json.dumps(key) + ': ' + json.dumps(value) for key, value in patch.items()) + '\n    }'
path.write_text(before.replace(needle, replacement), encoding='utf-8', newline='\n')
