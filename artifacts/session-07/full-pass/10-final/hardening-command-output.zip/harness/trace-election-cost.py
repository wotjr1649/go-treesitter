import json,subprocess
from receipt import ROOT, OUT, ENV, save, run, sha

base=ROOT/'.scratch/full-pass/prefix-trace'
dest=ROOT/'.scratch/full-pass/prefix-cost-trace'
dest.mkdir()
overlay=json.loads((base/'overlay.json').read_text(encoding='utf-8'))
target=str(ROOT/'internal/runtime/parser_recover_c.go')
from pathlib import Path
s=Path(overlay['Replace'][target]).read_text(encoding='utf-8')
needle='\t\t\tif p.cBetterVersionExists(*stacks, m0, false, newCost) {'
assert s.count(needle)==1
s=s.replace(needle, '''			if p.glrTrace {
				fmt.Printf("ELECT pos=%d sym=%d current=%d depth=%d state=%d entrypos=%d entrydepth=%d cost=%d better=%v action=%d\\n", pos,electionSym,curCost,d,entry.state,entry.posBytes,entry.depth,newCost,p.cBetterVersionExists(*stacks,m0,false,newCost),p.lookupActionIndex(entry.state,electionSym))
			}
'''+needle)
p=dest/'parser_recover_c.go';p.write_text(s,encoding='utf-8',newline='\n')
overlay['Replace'][target]=str(p)
save(dest/'overlay.json',overlay)
run('prefix-cost-trace-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
case={'ID':'js-cost','Filename':'x.js','Source':'\x85const value = 1;\n','Repeat':1}
r=subprocess.run([str(dest/'probe.exe')],input=json.dumps([case]).encode(),env=ENV,capture_output=True,timeout=20,check=True)
p=dest/'go.log';p.write_bytes(r.stdout+r.stderr)
save(OUT/'06-correctness/prefix-cost-trace.json',{'case':case,'sha256':sha(p.read_bytes())})
print('\n'.join(line for line in r.stdout.decode().splitlines() if line.startswith('ELECT'))[:6000])
