import json, subprocess
from receipt import ROOT, OUT, ENV, save, run, sha

base=ROOT/'.scratch/full-pass/recovery-final-review-v2'
dest=ROOT/'.scratch/full-pass/prefix-trace'
dest.mkdir()
overlay=json.loads((base/'overlay.json').read_text(encoding='utf-8'))
overlay['Replace'][str(ROOT/'internal/gtsadapter/adapter.go')]=str(ROOT/'.scratch/full-pass/go-second-trace/adapter.go')
save(dest/'overlay.json',overlay)
run('prefix-trace-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
allcases=json.loads((OUT/'06-correctness/leading-prefix-cases.json').read_text(encoding='utf-8'))['cases']
rows=[]
for id,lang,cdir in [('prefix-x.go-6','go','go-second-trace'),('prefix-x.js-8','javascript','js-amp-trace')]:
 case=next(c for c in allcases if c['ID']==id)
 case=dict(case,Repeat=1)
 case.pop('Previous');case.pop('Edit')
 result=subprocess.run([str(dest/'probe.exe')],input=json.dumps([case]).encode(),env=ENV,capture_output=True,timeout=20,check=True)
 path=dest/(lang+'-go.log');path.write_bytes(result.stdout+result.stderr)
 c=subprocess.run([str(ROOT/'.scratch/full-pass'/cdir/'c.exe')],input=case['Source'].encode(),env=ENV,capture_output=True,timeout=10,check=True)
 cp=dest/(lang+'-c.log');cp.write_bytes(c.stderr)
 rows.append({'case':case,'go_log_sha256':sha(path.read_bytes()),'c_log_sha256':sha(cp.read_bytes()),'go_bytes':path.stat().st_size,'c_bytes':cp.stat().st_size})
save(OUT/'06-correctness/prefix-recovery-trace.json',{'rows':rows})
print(rows)
