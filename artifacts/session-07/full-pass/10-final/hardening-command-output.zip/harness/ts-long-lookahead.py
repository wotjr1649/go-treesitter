from receipt import ROOT, save, run

dest=ROOT/'.scratch/full-pass/ts-long-lookahead'
dest.mkdir()
src=ROOT/'internal/runtime/parser_recover_c.go'
s=src.read_text(encoding='utf-8')
needle=' || relexed.EndByte > tok.EndByte || relexed.EndByte <= relexed.StartByte'
assert s.count(needle)==1
s=s.replace(needle,' || relexed.EndByte <= relexed.StartByte')
p=dest/'parser_recover_c.go';p.write_text(s,encoding='utf-8',newline='\n')
save(dest/'overlay.json',{'Replace':{str(src):str(p)}})
run('ts-long-lookahead-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
