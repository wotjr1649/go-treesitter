import json
import subprocess
from receipt import ROOT, OUT, ENV, save, run, sha

dest = ROOT / '.scratch/full-pass/ts-string-final-trace'
dest.mkdir()
s = (ROOT/'internal/gtsadapter/adapter.go').read_text(encoding='utf-8')
old = (ROOT/'.scratch/full-pass/go-second-trace/adapter.go').read_text(encoding='utf-8')
assert 'p.SetGLRTrace(true)' in old
# This copy differs from the reviewed adapter only in opt-in diagnostic logging.
s = s.replace('p := gts.NewParser(lang)', 'p := gts.NewParser(lang)\n\t\tp.SetGLRTrace(true)\n\t\tp.SetLogger(func(kind gts.ParserLogType, message string) { fmt.Println("LOGGER", kind, message) })')
assert 'p.SetGLRTrace(true)' in s
(dest/'adapter.go').write_text(s,encoding='utf-8',newline='\n')
save(dest/'overlay.json',{'Replace':{str(ROOT/'internal/gtsadapter/adapter.go'):str(dest/'adapter.go')}})
run('ts-string-final-trace-go-build',['go','build','-overlay='+str(dest/'overlay.json'),'-o',str(dest/'probe.exe'),str(ROOT/'.scratch/full-pass/probe.go')])
runtime = ROOT / '.scratch/oracle/runtime/lib'
source = ROOT / '.scratch/full-pass/builds/candidate-c/typescript/src'
command = ['C:/msys64/ucrt64/bin/gcc.exe','-std=c11','-O2',
           '-I'+str(runtime/'include'),'-I'+str(runtime/'src'),'-I'+str(source),
           '-DORACLE_LANGUAGE=tree_sitter_typescript',str(ROOT/'.scratch/full-pass/go-second-trace/driver.c'),
           str(runtime/'src/lib.c'),str(source/'parser.c'),str(source/'scanner.c'),'-o',str(dest/'c.exe')]
run('ts-string-final-trace-c-build',command)
case=json.loads((OUT/'06-correctness/ts-string-expanded-cases.json').read_text(encoding='utf-8'))['cases'][0]
case=dict(case,Repeat=1);case.pop('Previous');case.pop('Edit')
g=subprocess.run([str(dest/'probe.exe')],input=json.dumps([case]).encode(),capture_output=True,env=ENV,timeout=15,check=True)
c=subprocess.run([str(dest/'c.exe')],input=case['Source'].encode(),capture_output=True,env=ENV,timeout=15,check=True)
(dest/'go.log').write_bytes(g.stdout+g.stderr)
(dest/'c.log').write_bytes(c.stderr)
(dest/'c.json').write_bytes(c.stdout)
save(OUT/'06-correctness/ts-string-final-trace.json',{'case':case,'go_log_sha256':sha(g.stdout+g.stderr),'c_log_sha256':sha(c.stderr),'c_tree_sha256':sha(c.stdout)})
