import json
from receipt import ROOT, OUT, ENV, run, save, sha

path=ROOT/'.github/workflows/windows.yml'
workflow=json.loads(path.read_text(encoding='utf-8'))
assert workflow['permissions']=={'contents':'read'}
product=workflow['jobs']['product'];race=workflow['jobs']['race']
assert product['env']=={'CGO_ENABLED':'0'} and race['env']=={'CGO_ENABLED':'1'}
assert product['strategy']['matrix']['include']==[
    {'runner':'windows-latest','arch':'amd64'},{'runner':'windows-11-arm','arch':'arm64'}]
assert product['timeout-minutes']==race['timeout-minutes']==15
for job in (product,race):
    assert job['steps'][0]['with']['persist-credentials'] is False
assert any('./native-consumer.exe' in step.get('run','') for step in product['steps'])
run('10-final/native-consumer-build',['go','build','-trimpath','-o','.scratch/full-pass/native-consumer.exe','./testdata/consumer'])
run('10-final/native-consumer',[str(ROOT/'.scratch/full-pass/native-consumer.exe')],timeout=30)
save(OUT/'10-final/workflow-review.json',dict(workflow_sha256=sha(path.read_bytes()),
    reviewed_runner_documentation='https://docs.github.com/en/actions/reference/runners/github-hosted-runners',
    reviewed_date='2026-09-23',native_amd64='PASS',native_arm64='NOT_RUN',hosted_ci='NOT_RUN',
    boundary='local workflow preparation only; no push, workflow dispatch or remote write',
    checks='JSON, native runner matrix, read-only permissions, credential persistence disabled, bounded jobs, product/race lane separation'))
