import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

exe=ROOT/'.scratch/full-pass/release-packaging/consumer-probe.exe'
rows=[]
for catalog,sub in [('cases','base'),('typescript-contextual-cases','ts-contextual'),('csharp-recovery-cases','cs-recovery'),('csharp-preservation-cases','cs-preservation')]:
    cases=json.loads((ROOT/'testdata/oracle'/(catalog+'.json')).read_text(encoding='utf-8'))
    byid={c['id']:c for c in cases};requests=[]
    for c in cases:
        source=c['source'] if 'source' in c else (ROOT/c['path']).read_text(encoding='utf-8')
        assert sha(source.encode())==c['sha256']
        r=dict(ID=c['id'],Filename=c['filename'],Source=source,Repeat=3)
        if 'previous' in c: r.update(Previous=byid[c['previous']]['source'],Edit=c['edit'])
        requests.append(r)
    p=subprocess.run([str(exe)],input=json.dumps(requests,ensure_ascii=False).encode(),capture_output=True,env=ENV,timeout=90,check=True)
    for c,line in zip(cases,p.stdout.splitlines(),strict=True):
        g=json.loads(line)
        cr=json.loads((ROOT/'testdata/oracle/windows-c-v2'/sub/(c['id']+'.json')).read_text(encoding='utf-8'))
        passed=g['Nodes']==cr['nodes'] and all(o==g['Observations'][0] and o['Complete'] and o['Error']==cr['has_error'] for o in g['Observations'])
        if 'previous' in c: passed &= g['IncrementalEqual'] and g['Incremental']['Complete'] and g['IncrementalNodes']==cr['nodes']
        rows.append(dict(id=c['id'],source_sha256=c['sha256'],passed=passed,observations=g['Observations'],incremental=g['Incremental']))
save(OUT/'11-release/packaging/oracle.json',dict(executable_sha256=sha(exe.read_bytes()),module_zip_sha256=sha((ROOT/'.scratch/full-pass/release-packaging/main-v0.0.1.zip').read_bytes()),
    rows=rows,records=len(rows),edits=sum(r['incremental'] is not None for r in rows)))
assert all(r['passed'] for r in rows)
print('whole-ZIP consumer/C records',len(rows),'all PASS')
