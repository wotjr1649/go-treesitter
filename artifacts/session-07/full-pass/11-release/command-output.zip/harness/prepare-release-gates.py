from receipt import ROOT, OUT, save, sha
import subprocess

base=ROOT/'.scratch/full-pass'
scripts={
 'release-correctness.py':('final-correctness-leaf.py',{'10-final':'11-release','final-correctness-leaf.exe':'release-correctness.exe'}),
 'release-checks.py':('final-checks.py',{'10-final':'11-release','catalog-final-':'catalog-release-'}),
 'release-resources.py':('final-resources.py',{'10-final':'11-release','bench-final.exe':'bench-release.exe','retention-final.exe':'retention-release.exe'}),
 'release-large-oracle.py':('final-large-oracle.py',{'10-final':'11-release','final-correctness-leaf.exe':'release-correctness.exe'}),
 'analyze-release-benchmarks.py':('analyze-final-benchmarks.py',{'10-final':'11-release'}),
}
for name,(origin,replacements) in scripts.items():
    text=(base/origin).read_text(encoding='utf-8')
    for before,after in replacements.items(): text=text.replace(before,after)
    with (base/name).open('x',encoding='utf-8',newline='\n') as stream: stream.write(text)
save(OUT/'11-release/plan.json',dict(candidate_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    scripts={name:sha((base/name).read_bytes()) for name in scripts},
    correctness='688 retained fresh C records, 439 edits, repeated 20 clean / 100 error Go parses and three fresh C parses',
    catalog='206, three fresh / edit / pre-cancel / input budget / close',
    fuzz='60 seconds each incremental agreement and bounded parse, parallel=2',
    resources='193 cycles, 3281 trees, 12 checkpoints; separate race diagnostics',
    performance='five paired randomized seeds, 40 timed operations in 59 modes, GOMAXPROCS=4',
    packaging='official x/mod CreateFromVCS/CheckZip for v0.0.1, fresh file-proxy consumers, no replace',
    native_arm64='NOT_RUN; no native host available',hosted_ci='NOT_RUN; no authorized remote write'))
