from receipt import run
for target,name in [('FuzzIncrementalAgreement','edit'),('FuzzBoundedParse','bounded')]:
    run('11-release/fuzz-'+name,['go','test','./internal/gtsadapter','-run=^$',
        '-fuzz=^'+target+'$','-fuzztime=60s','-parallel=2','-timeout=120s'],timeout=150)
