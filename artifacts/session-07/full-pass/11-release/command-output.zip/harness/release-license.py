import json
from receipt import ROOT, OUT, run, save, sha

catalog=json.loads((ROOT/'LICENSES/catalog.json').read_text(encoding='utf-8'))
rows=catalog['rows'];assert len(rows)==206
for row in rows:
    for key in ('notice','metadata'):
        if isinstance(row.get(key),dict) and 'path' in row[key] and 'sha256' in row[key]:
            assert sha((ROOT/row[key]['path']).read_bytes())==row[key]['sha256'],row['grammar']
try:
    run('11-release/license-gate',['python','tools/licenses/check.py'],timeout=30)
except RuntimeError:
    check=json.loads((OUT/'11-release/license-gate.log').read_text(encoding='utf-8'))
    receipt=json.loads((OUT/'11-release/license-gate.json').read_text(encoding='utf-8'))
    assert receipt['exit']==1 and check['status']=='BLOCKED_EXTERNAL'
    assert {r['grammar'] for r in check['unresolved_declarations']}=={'brightscript','cooklang'}
    save(OUT/'11-release/license-summary.json',dict(status='BLOCKED_EXTERNAL',
        inventory_sha256=sha((ROOT/'LICENSES/catalog.json').read_bytes()),
        grammars=206,unresolved=check['unresolved_declarations'],
        resolution='Upstream rights holders must clarify the conflicting ISC/MIT declarations and provide an applicable notice; no license is invented here.'))
else:
    raise AssertionError('expected recorded unresolved declarations; investigate a stale blocker')
