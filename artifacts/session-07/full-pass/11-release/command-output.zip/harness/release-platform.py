import json
import platform
from receipt import ROOT, OUT, ENV, run, save, sha

folder=ROOT/'.scratch/full-pass/release-platform'
folder.mkdir()
run('11-release/platform/environment',['go','env','-json','GOOS','GOARCH','CGO_ENABLED','GOVERSION','GOTOOLCHAIN'])
run('11-release/platform/build',['go','build','./...'])
run('11-release/platform/dependencies',['go','list','-deps','-json','./testdata/consumer'])
raw=(OUT/'11-release/platform/dependencies.log').read_text(encoding='utf-8')
decoder=json.JSONDecoder();rows=[]
while raw.strip():
    row,end=decoder.raw_decode(raw.lstrip());raw=raw.lstrip()[end:];rows.append(row)
assert not any(r.get('CgoFiles') or r.get('ImportPath')=='runtime/cgo' for r in rows)
targets=[('windows','amd64','consumer-amd64.exe'),('windows','arm64','consumer-arm64.exe'),
    ('linux','amd64','consumer-linux'),('darwin','arm64','consumer-darwin'),('wasip1','wasm','consumer.wasm')]
artifacts=[]
for goos,arch,name in targets:
    path=folder/name
    run('11-release/platform/'+goos+'-'+arch,['go','build','-trimpath','-o',str(path),'./testdata/consumer'],
        timeout=180,env=dict(ENV,GOOS=goos,GOARCH=arch))
    artifacts.append(dict(goos=goos,goarch=arch,path=str(path.relative_to(ROOT)),sha256=sha(path.read_bytes()),bytes=path.stat().st_size,
        execution='PASS' if (goos,arch)==('windows','amd64') else 'NOT_RUN'))
run('11-release/platform/native',[str(folder/'consumer-amd64.exe')],timeout=30)
run('11-release/platform/pe',['go','run','.scratch/cgo-audit-2026-09-22/inspect_pe.go',str(folder/'consumer-amd64.exe'),str(folder/'consumer-arm64.exe')])
pe=[json.loads(line) for line in (OUT/'11-release/platform/pe.log').read_text(encoding='utf-8').splitlines()]
assert [r['Machine'] for r in pe]==[34404,43620]
assert all([x.lower() for x in r['Libraries']]==['kernel32.dll'] for r in pe)
save(OUT/'11-release/platform/summary.json',dict(host_class='local Windows workstation',platform=platform.platform(),machine=platform.machine(),
    dependency_packages=len(rows),cgo_files=0,runtime_cgo=False,artifacts=artifacts,
    pe_imports='kernel32.dll only',native_windows_amd64='PASS',native_windows_arm64='NOT_RUN',hosted_ci='NOT_RUN'))
