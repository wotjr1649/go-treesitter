import random
from receipt import ROOT, OUT, run, save, sha

paths={'baseline':ROOT/'.scratch/full-pass/bench-baseline.exe','candidate':ROOT/'.scratch/full-pass/bench-release.exe'}
tasks=[];rng=random.Random(202609231)
for seed in range(1,6):
    names=['baseline','candidate'];rng.shuffle(names)
    tasks.extend((name,seed) for name in names)
save(OUT/'11-release/performance/lookup-plan.json',dict(tasks=tasks,query_iterations=1000000,index_iterations=1000,
    reason='The 40-operation query/index samples had wide intervals; predeclare a longer fixed sample, retain both series.',
    binaries={name:sha(path.read_bytes()) for name,path in paths.items()}))
for mode,count in [('query',1000000),('index',1000)]:
    for name,seed in tasks:
        cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
        run(f'11-release/performance/lookup-{mode}-{name}-{seed}',[str(paths[name]),'-test.run=^$',
            '-test.bench=^BenchmarkRelease$/./^'+mode+'$',f'-test.benchtime={count}x','-test.benchmem',
            '-test.timeout=60s','-release-seed='+str(seed)],cwd=cwd,timeout=75)
for case,mode in [('tsx','delete'),('go','replace')]:
    for name in ('baseline','candidate'):
        cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
        profile=ROOT/'.scratch/full-pass'/f'release-{case}-{mode}-{name}.pprof'
        run(f'11-release/performance/profile-{case}-{mode}-{name}',[str(paths[name]),'-test.run=^$',
            f'-test.bench=^BenchmarkRelease$/^{case}$/^{mode}$','-test.benchtime=300x','-test.benchmem',
            '-test.timeout=60s','-test.cpuprofile='+str(profile)],cwd=cwd,timeout=75)
        run(f'11-release/performance/profile-{case}-{mode}-top-{name}',
            ['go','tool','pprof','-top','-cum','-nodecount=30',str(profile)],timeout=30)
