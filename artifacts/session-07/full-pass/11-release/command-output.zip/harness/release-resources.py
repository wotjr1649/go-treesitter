import json
import random
from receipt import ROOT, OUT, ENV, run, save, sha

subset='grammar_subset,grammar_subset_go,grammar_subset_python,grammar_subset_javascript,grammar_subset_typescript,grammar_subset_tsx,grammar_subset_c_sharp'
run('11-release/subset',['go','test','-tags',subset,'./...','-count=1','-timeout=120s','-json'])
raceenv=dict(ENV,CGO_ENABLED='1',CC='C:/msys64/ucrt64/bin/gcc.exe')
run('11-release/race',['go','test','-race','./syntax','./internal/gtsadapter',
    '-run','^Test(IndependentWorkers|Index.*|Cancellation.*|RuntimeTimeoutReleasesPartialTree)$',
    '-count=1','-timeout=180s','-json'],timeout=240,env=raceenv)
run('11-release/bench-build',['go','test','-c','-o','.scratch/full-pass/bench-release.exe','./internal/gtsadapter'])
run('11-release/retention-build',['go','build','-trimpath','-o','.scratch/full-pass/retention-release.exe','.scratch/full-pass/retention.go'])
tasks=[]
rng=random.Random(20260923)
for seed in range(1,6):
    pair=['baseline','candidate'];rng.shuffle(pair)
    tasks.extend((name,seed) for name in pair)
exes={'baseline':ROOT/'.scratch/full-pass/bench-baseline.exe','candidate':ROOT/'.scratch/full-pass/bench-release.exe'}
save(OUT/'11-release/performance/plan.json',dict(tasks=tasks,iterations=40,GOMAXPROCS=4,
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    baseline_commit='2e18f90a4f5205edf3091771141126bc87d5e86c',
    binaries={k:sha(v.read_bytes()) for k,v in exes.items()},
    analysis='paired log ratio 95% t interval (df=4), normality caveat; exact sign test; all samples retained'))
for name,seed in tasks:
    cwd=ROOT/'.scratch/full-pass/performance-baseline/internal/gtsadapter' if name=='baseline' else ROOT/'internal/gtsadapter'
    run('11-release/performance/'+name+'-'+str(seed),[str(exes[name]),'-test.run=^$',
        '-test.bench=^BenchmarkRelease$','-test.benchtime=40x','-test.benchmem',
        '-test.timeout=180s','-release-seed='+str(seed)],timeout=195,cwd=cwd)
save(OUT/'11-release/resources/plan.json',dict(cycles=193,parses_per_cycle=17,checkpoints=12,
    gc_at_checkpoints=2,timeout_seconds=300,concurrent_measurement_processes=1,
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    binary_sha256=sha((ROOT/'.scratch/full-pass/retention-release.exe').read_bytes()),
    harness_sha256=sha((ROOT/'.scratch/full-pass/retention.go').read_bytes())))
run('11-release/resources/retention',[str(ROOT/'.scratch/full-pass/retention-release.exe')],timeout=300)
