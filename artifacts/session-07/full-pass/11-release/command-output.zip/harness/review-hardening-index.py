import hashlib
import json
import subprocess
from receipt import ROOT, OUT, ENV, save, sha

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,env=ENV)
paths=git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0')
assert paths and not any(p.startswith(('.scratch/','.github/','artifacts/private/','docs/prompts/')) for p in paths)
assert not any(p.endswith(('.exe','.pprof','.pem','.key')) for p in paths)
assert 'parser_test.go' not in paths and 'testdata/consumer/main.go' not in paths
manifest=json.loads((ROOT/'internal/provenance/runtime.json').read_text(encoding='utf-8'))
entries=git('ls-files','--stage','-z','--','internal/runtime').split(b'\0')
count=0
for entry in entries:
    if not entry: continue
    meta,path=entry.decode().split('\t')
    mode,oid,stage=meta.split()
    assert mode=='100644' and stage=='0'
    data=(ROOT/path).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,path
    assert sha(data)==manifest['files'][path.removeprefix('internal/runtime/')]['sha256'],path
    count+=1
assert count==len(manifest['files'])==1508
check=subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,env=ENV,capture_output=True)
assert not check.stderr
warnings=[line for line in check.stdout.decode().splitlines() if line and not line.startswith('+')]
binary_patch_eof='tools/runtime-bundle/patches/recovery-lookahead-and-eof.patch:10959: new blank line at EOF.'
assert all(line==binary_patch_eof or (line.startswith('tools/runtime-bundle/patches/') and ('space before tab' in line or 'trailing whitespace' in line)) for line in warnings)
save(OUT/'10-final/index-review.json',dict(staged_paths=len(paths),runtime_files=count,
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    carrier_index_matches_manifest=True,whitespace_warning_count=len(warnings),
    whitespace_classification='Only literal unified-diff context markers in maintained patches; no product-source warning',
    source_review='10-final/review.md; 09-audit/review.md',
    original_failure_preserved='raw-child-product.json',passing_rerun='raw-child-product-final.json'))
print('reviewed',len(paths),'staged paths;',count,'carrier files; literal patch whitespace warnings',len(warnings))
