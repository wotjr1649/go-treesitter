import collections
import json
import math
import re
import statistics as s
from receipt import ROOT, OUT, save, sha

base=OUT/'11-release'
catalogs=json.loads((base/'oracle/summary.json').read_text(encoding='utf-8'))['catalogs']
assert not any(c['failed'] for c in catalogs)
fallbacks=collections.Counter()
for path in (base/'oracle').glob('*.json'):
    if path.name in ('summary.json','build.json','large-go.json'): continue
    for row in json.loads(path.read_text(encoding='utf-8'))['rows']:
        assert row['passed']
        g=row['go']
        for mode,o in [('fresh',g['Observations'][0]),('edit',g['Incremental'])]:
            if o and (o['Fallback'] or o['Reuse']):
                fallbacks[(mode,o['Route'],o['Fallback'],o['Reuse'])]+=1
save(base/'fallbacks.json',[dict(mode=k[0],route=k[1],fallback=k[2],reuse_reason=k[3],cases=v) for k,v in sorted(fallbacks.items())])
tests={}
for name in ('product','subset','race','private'):
    data=[json.loads(line) for line in (base/(name+'.log')).read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    failed=[r.get('Test',r.get('Package')) for r in data if r.get('Action')=='fail']
    skipped=[r.get('Test',r.get('Package')) for r in data if r.get('Action')=='skip']
    assert not failed
    tests[name]=dict(passed_tests=sum(r.get('Action')=='pass' and 'Test' in r for r in data),failed=failed,skipped=skipped)
fuzz={}
for name in ('edit','bounded'):
    data=(base/('fuzz-'+name+'.log')).read_text(encoding='utf-8')
    assert '\nPASS\n' in data
    fuzz[name]=dict(executions=int(re.findall(r'execs: (\d+)',data)[-1]),duration_seconds=60,parallel=2)
memory=[json.loads(line) for line in (base/'resources/retention.log').read_text(encoding='utf-8').splitlines()]
checkpoints=[r for r in memory if r.get('Phase')=='steady'];end=memory[-1]
assert len(checkpoints)==12 and end['Opened']==end['Closed']==3281 and all(r['Goroutines']==1 for r in checkpoints)
memory_result=dict(cycles=193,parses=3281,seconds=end['Milliseconds']/1000,
    post_gc_heap_range=[min(r['HeapAlloc'] for r in checkpoints),max(r['HeapAlloc'] for r in checkpoints)],
    peak_working_set=end['PeakWorkingSet'],after_scavenge_working_set=end['WorkingSet'],
    peak_arena=end['PeakArena'],peak_scratch=end['PeakScratch'],peak_stack_depth=end['PeakDepth'],
    tree_open_close_equal=True,goroutines=1,total_allocated=end['TotalAlloc'])
lookup={}
for mode,count in [('query',1000000),('index',1000)]:
    variants={v:{} for v in ('baseline','candidate')}
    for v in variants:
        for seed in range(1,6):
            for line in (base/'performance'/f'lookup-{mode}-{v}-{seed}.log').read_text(encoding='utf-8').splitlines():
                if not line.startswith('BenchmarkRelease/'):continue
                fields=line.split();key=fields[0].removeprefix('BenchmarkRelease/').rsplit('-',1)[0]
                assert int(fields[1])==count
                variants[v].setdefault(key,[]).append({fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)})
    for key in variants['baseline']:
        a=[r['ns/op'] for r in variants['baseline'][key]];b=[r['ns/op'] for r in variants['candidate'][key]]
        ratio=[math.log(y/x) for x,y in zip(a,b)]
        half=2.776445105*s.stdev(ratio)/math.sqrt(5);mean=s.mean(ratio)
        lookup[key]=dict(before=a,after=b,before_median=s.median(a),after_median=s.median(b),
            median_ratio=s.median(b)/s.median(a),paired_log_t95=[math.exp(mean-half),math.exp(mean+half)],
            candidate_bytes=[r['B/op'] for r in variants['candidate'][key]],candidate_allocs=[r['allocs/op'] for r in variants['candidate'][key]])
save(base/'performance/lookup-comparison.json',dict(rows=lookup,samples=5,caveat='same five-pair log-ratio normality caveat as primary comparison'))
summary=dict(candidate_commit='23d6885ebe8709616614c89ffb6511ea815fb23f',
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    c_records=sum(c['count'] for c in catalogs),edits=sum(c['edits'] for c in catalogs),large_go_nodes=57348,
    catalog_basic=206,tests=tests,fuzz=fuzz,memory=memory_result,
    external_consumer_c_records=100,external_consumer_module_counts=[2,3],
    cgo=json.loads((base/'platform/summary.json').read_text(encoding='utf-8')),
    unresolved=['brightscript/cooklang ISC/MIT declaration conflicts','native Windows ARM64 host unavailable','hosted CI: no configured remote or explicit push authority'],
    verdict='BLOCKED_EXTERNAL')
save(base/'summary.json',summary)
print(json.dumps({k:summary[k] for k in ('c_records','edits','tests','fuzz','memory','verdict')},indent=2))
for name in ('ts/query','jsx/index'):
    row=lookup[name];print(name,row['before_median'],row['after_median'],row['median_ratio'],row['paired_log_t95'])
