import json
import zipfile
from receipt import ROOT, OUT, save, sha

paths={}
for path in OUT.rglob('*.log'):
    receipt=path.with_suffix('.json')
    if receipt.exists():
        row=json.loads(receipt.read_text(encoding='utf-8'))
        if isinstance(row,dict) and 'log_sha256' in row:
            assert sha(path.read_bytes())==row['log_sha256'],str(path)
    paths['logs/'+path.relative_to(OUT).as_posix()]=path
for pattern in ('*.py','*.go','*.c'):
    for path in (ROOT/'.scratch/full-pass').glob(pattern):
        paths['harness/'+path.name]=path
manifest={}
destination=OUT/'11-release/command-output.zip'
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(paths.items()):
        data=path.read_bytes();archive.writestr(name,data)
        manifest[name]=dict(bytes=len(data),sha256=sha(data))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert all(sha(archive.read(name))==row['sha256'] for name,row in manifest.items())
profiles={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in (ROOT/'.scratch/full-pass').glob('*.pprof')}
save(destination.with_suffix('.json'),dict(archive_sha256=sha(destination.read_bytes()),entries=manifest,
    local_profiles_not_in_git=profiles,profile_policy='Only locations/hashes and text summaries retained in Git; raw profiles stay local.'))
print('complete logs/harnesses',len(paths),'archive bytes',destination.stat().st_size,'profile hashes',len(profiles))
