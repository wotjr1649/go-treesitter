import collections
import json
import re
import subprocess
from receipt import ROOT, OUT, save, sha

summary=json.loads((OUT/'11-release/summary.json').read_text(encoding='utf-8'))
identity=json.loads((OUT/'11-release/identity.json').read_text(encoding='utf-8'))
assert summary['c_records']==688 and summary['edits']==439 and identity['distinct_language_source_pairs']==584
for path,digest in (identity['production_files']|identity['test_files']).items():
    assert sha((ROOT/path).read_bytes())==digest,path
rows=json.loads((ROOT/'LICENSES/catalog.json').read_text(encoding='utf-8'))['rows']
basis=collections.Counter(r['basis'] for r in rows)
assert basis['original_notice']==197 and len(rows)==206,basis
large=json.loads((OUT/'11-release/oracle/large-go.json').read_text(encoding='utf-8'))
assert large['passed'] and large['nodes']==57348
assert all(o['Complete'] and not o['Error'] and not o['Missing'] for o in large['observations']+[large['incremental']])
changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()
assert sorted(changed)==['README.md','docs/reports/release-critical-status.md'],changed
for path in ('README.md','docs/reports/release-critical-status.md','artifacts/session-07/full-pass/11-release/review.md'):
    data=(ROOT/path).read_text(encoding='utf-8')
    assert '688' in data and ('439' in data or path=='README.md')
    for target in re.findall(r'\]\(([^)]+)\)',data):
        if target.startswith(('https://','http://')):continue
        if '12-closure' in target:continue # Constructed immediately after the closing document commit.
        assert ((ROOT/path).parent/target.split('#')[0]).exists(),(path,target)
save(OUT/'11-release/closing-review.json',dict(source_and_test_hashes_unchanged=True,
    changed_tracked_files=changed,license_evidence_basis=dict(basis),
    documentation_counts_and_existing_links='PASS',future_link='12-closure package receipts created next',
    final_diff_review='Only README/status correction and append-only evidence; no runtime, API, fixture, threshold or gate change'))
print('closing documentation/source review PASS')
