import json
import shutil
import subprocess
import zipfile
from receipt import ROOT, OUT, ENV, save, run, sha

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,env=ENV).decode().strip()
assert head=='d880651517afc0793a9d7132838ca1c3b1a69809'
base=ROOT/'.scratch/full-pass/closure-packaging'
base.mkdir()
modules=[('github.com/wotjr1649/go-treesitter','','main'),('github.com/wotjr1649/go-treesitter/grammars/gpl','grammars/gpl','gpl')]
rows=[]
for module,subdir,label in modules:
    output=base/(label+'-v0.0.1.zip')
    run('12-closure/packaging/zip-'+label,[str(ROOT/'.scratch/full-pass/modulezip.exe'),module,str(ROOT),head,subdir,str(output)],timeout=120)
    prefix=module+'@v0.0.1/'
    with zipfile.ZipFile(output) as zipped:
        names=[n.removeprefix(prefix) for n in zipped.namelist()]
        assert len(names)==len(set(names)) and all(n.startswith(prefix) for n in zipped.namelist())
        assert 'LICENSE' in names and 'go.mod' in names
        assert not any(n.startswith(('artifacts/','.scratch/')) for n in names)
        if label=='main':
            assert not any(n.startswith('grammars/gpl/') for n in names)
            assert len([n for n in names if n.startswith('internal/runtime/grammars/grammar_blobs/') and n.endswith('.bin')])==203
            for path in ('LICENSES/catalog.json','tools/runtime-bundle/grammars/go-source.zip','tools/runtime-bundle/grammars/go.json','internal/provenance/runtime.json'):
                assert sha(zipped.read(prefix+path))==sha((ROOT/path).read_bytes())
        else:
            assert len([n for n in names if n.endswith('.bin')])==3
            assert any('sources/' in n and n.endswith('.zip') for n in names)
        mod=zipped.read(prefix+'go.mod')
    proxy=base/'proxy'/module/'@v';proxy.mkdir(parents=True)
    shutil.copyfile(output,proxy/'v0.0.1.zip')
    (proxy/'v0.0.1.mod').write_bytes(mod)
    (proxy/'v0.0.1.info').write_text(json.dumps({'Version':'v0.0.1','Time':'2026-09-22T00:00:00Z'})+'\n',encoding='utf-8')
    (proxy/'list').write_text('v0.0.1\n',encoding='utf-8')
    rows.append(dict(module=module,version='v0.0.1',candidate_commit=head,path=str(output.relative_to(ROOT)),
        sha256=sha(output.read_bytes()),bytes=output.stat().st_size,entries=len(names)))
save(OUT/'12-closure/packaging/artifacts.json',dict(modules=rows,tool_sha256=sha((ROOT/'.scratch/full-pass/modulezip.exe').read_bytes())))
for optional in (False,True):
    label='gpl' if optional else 'main'
    consumer=base/('consumer-'+label);consumer.mkdir()
    mod='module example.com/release-consumer\n\ngo 1.27.1\n\nrequire github.com/wotjr1649/go-treesitter v0.0.1\n'
    if optional: mod+='require github.com/wotjr1649/go-treesitter/grammars/gpl v0.0.1\n'
    (consumer/'go.mod').write_text(mod,encoding='utf-8',newline='\n')
    shutil.copyfile(ROOT/('testdata/consumer-gpl/main.go' if optional else 'testdata/consumer/main.go'),consumer/'main.go')
    env=dict(ENV,GOMODCACHE=str(consumer/'cache'),GOPROXY=(base/'proxy').as_uri(),GONOPROXY='none',GOPRIVATE='',GONOSUMDB='')
    assert not (consumer/'cache').exists()
    run('12-closure/packaging/consumer-'+label,['go','run','-mod=mod','.'],cwd=consumer,env=env,timeout=180)
    run('12-closure/packaging/graph-'+label,['go','list','-m','-json','all'],cwd=consumer,env=env,timeout=60)
    raw=(OUT/'12-closure/packaging'/('graph-'+label+'.log')).read_text(encoding='utf-8')
    decoder=json.JSONDecoder(); graph=[]
    while raw.strip():
        item,end=decoder.raw_decode(raw.lstrip());graph.append(item);raw=raw.lstrip()[end:]
    assert len(graph)==(3 if optional else 2) and not any('Replace' in r for r in graph)
    if not optional:
        probe=consumer/'probe';probe.mkdir();shutil.copyfile(ROOT/'.scratch/full-pass/probe.go',probe/'main.go')
        run('12-closure/packaging/probe-build',['go','build','-mod=readonly','-trimpath','-o',str(base/'consumer-probe.exe'),'./probe'],cwd=consumer,env=env,timeout=180)
save(OUT/'12-closure/packaging/consumer-summary.json',dict(candidate_commit=head,main='PASS',gpl='PASS',
    module_counts=[2,3],replace_directives=0,empty_module_caches=True,proxy='task-local file proxy; no network',
    scope='whole official module ZIPs; seven core routes, NUL index, JSX/TSX fix, Go edit/fresh equality, errors, cancel, GPL three grammars'))
