from receipt import ROOT
script=(ROOT/'.scratch/full-pass/release-packaging.py').read_text(encoding='utf-8')
script=script.replace('23d6885ebe8709616614c89ffb6511ea815fb23f','d880651517afc0793a9d7132838ca1c3b1a69809')
script=script.replace('release-packaging','closure-packaging').replace('11-release','12-closure')
with (ROOT/'.scratch/full-pass/closure-packaging.py').open('x',encoding='utf-8',newline='\n') as stream:stream.write(script)
script=(ROOT/'.scratch/full-pass/consumer-correctness.py').read_text(encoding='utf-8')
script=script.replace('release-packaging','closure-packaging').replace('11-release','12-closure')
with (ROOT/'.scratch/full-pass/closure-consumer-correctness.py').open('x',encoding='utf-8',newline='\n') as stream:stream.write(script)
