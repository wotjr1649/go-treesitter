import json
import subprocess
from receipt import ROOT, OUT, save, sha

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().strip('\0').split('\0')
production={p:sha((ROOT/p).read_bytes()) for p in tracked if p in ('go.mod','go.sum','parser.go') or
    (p.startswith(('syntax/','internal/','tools/runtime-bundle/','grammars/gpl/','LICENSES/')) and not p.endswith('_test.go'))}
tests={p:sha((ROOT/p).read_bytes()) for p in tracked if p.endswith('_test.go') or p.startswith(('testdata/','tools/native-oracle/'))}
counts=[]
for c in json.loads((OUT/'11-release/oracle/summary.json').read_text(encoding='utf-8'))['catalogs']:
    counts.extend(json.loads((ROOT/'testdata/oracle'/(c['catalog']+'.json')).read_text(encoding='utf-8')))
inputs={}
for ext,fmt in [('go','func f%d() int { return %d }\n'),('py','def f%d():\n    return %d\n'),('js','const value%d = %d;\n'),
    ('jsx','const View%d = () => <p>{%d}</p>;\n'),('ts','const value%d: number = %d;\n'),('tsx','const View%d = () => <p>{%d}</p>;\n'),('cs','class C%d { public int F() => %d; }\n')]:
    data=(('package p\n' if ext=='go' else '')+''.join(fmt%(i,i) for i in range(128))).encode()
    inputs[ext]=dict(bytes=len(data),sha256=sha(data))
source=(ROOT/'testdata/newtonsoft/JsonTextReader-excerpt.cs').read_bytes()
inputs['cs-recovery']=dict(bytes=len(source),sha256=sha(source))
save(OUT/'11-release/identity.json',dict(tested_commit=head,go='go1.27.1 windows/amd64',
    source_at_test='clean production/test files; untracked evidence only',
    origin=json.loads((ROOT/'internal/provenance/identities.json').read_text(encoding='utf-8')),
    production_files=production,test_files=tests,
    production_digest=sha(json.dumps(production,sort_keys=True,separators=(',',':')).encode()),
    test_manifest_digest=sha(json.dumps(tests,sort_keys=True,separators=(',',':')).encode()),
    benchmark_inputs=inputs,registered_records=len(counts),
    distinct_language_source_pairs=len({(c['language'],c['sha256']) for c in counts})))
print('bound production/test files',len(production),len(tests),'distinct language/source pairs',len({(c['language'],c['sha256']) for c in counts}))
