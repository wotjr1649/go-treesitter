import json
import subprocess
import zipfile
from receipt import ROOT, OUT, save, sha

identity=json.loads((OUT/'11-release/identity.json').read_text(encoding='utf-8'))
for path,digest in (identity['production_files']|identity['test_files']).items():
    assert sha((ROOT/path).read_bytes())==digest,path
old=ROOT/'.scratch/full-pass/release-packaging'
new=ROOT/'.scratch/full-pass/closure-packaging'
changed={}
for module in ('main','gpl'):
    with zipfile.ZipFile(old/(module+'-v0.0.1.zip')) as a,zipfile.ZipFile(new/(module+'-v0.0.1.zip')) as b:
        assert a.namelist()==b.namelist()
        differences=[n for n in a.namelist() if a.read(n)!=b.read(n)]
    changed[module]=differences
assert changed['main']==[
    'github.com/wotjr1649/go-treesitter@v0.0.1/README.md',
    'github.com/wotjr1649/go-treesitter@v0.0.1/docs/reports/release-critical-status.md'],changed
assert not changed['gpl'] and (old/'gpl-v0.0.1.zip').read_bytes()==(new/'gpl-v0.0.1.zip').read_bytes()
closing=json.loads((OUT/'12-closure/packaging/oracle.json').read_text(encoding='utf-8'))
assert closing['records']==100 and all(r['passed'] for r in closing['rows'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
save(OUT/'12-closure/final-candidate.json',dict(candidate_commit=head,
    tested_code_commit=identity['tested_commit'],production_digest=identity['production_digest'],
    test_manifest_digest=identity['test_manifest_digest'],production_and_tests_byte_identical=True,
    changed_module_zip_entries=changed,closing_consumer_c_records=100,
    runtime_manifest_sha256=sha((ROOT/'internal/provenance/runtime.json').read_bytes()),
    artifacts=json.loads((OUT/'12-closure/packaging/artifacts.json').read_text(encoding='utf-8'))['modules'],
    verdict='BLOCKED_EXTERNAL',remaining=['Native Windows ARM64/hosted CI require a target and execution authority; no origin is configured.',
    'Brightscript/Cooklang upstream ISC/MIT declarations remain unresolved.'],
    remote_writes=0,published_tags=0))
manifest={}
archive_path=OUT/'12-closure/command-output.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((OUT/'12-closure').rglob('*.log')):
        data=path.read_bytes()
        receipt=json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        assert sha(data)==receipt['log_sha256']
        name=path.relative_to(OUT/'12-closure').as_posix();archive.writestr(name,data)
        manifest[name]=sha(data)
    for name in ('prepare-closure.py','closure-packaging.py','closure-consumer-correctness.py','verify-closure.py','check-closing-docs.py','release-identity.py','archive-release.py'):
        data=(ROOT/'.scratch/full-pass'/name).read_bytes();archive.writestr('harness/'+name,data);manifest['harness/'+name]=sha(data)
with zipfile.ZipFile(archive_path) as archive:
    assert all(sha(archive.read(name))==digest for name,digest in manifest.items())
save(archive_path.with_suffix('.json'),dict(sha256=sha(archive_path.read_bytes()),entries=manifest))
entries={str(p.relative_to(OUT).as_posix()):sha(p.read_bytes()) for folder in ('11-release','12-closure') for p in (OUT/folder).rglob('*') if p.is_file() and p.suffix!='.log'}
with (OUT/'12-closure/MANIFEST.sha256').open('x',encoding='utf-8',newline='\n') as stream:
    stream.writelines(digest+'  '+path+'\n' for path,digest in sorted(entries.items()))
print('final candidate',head,'production/test identity and whole-ZIP consumption PASS;',len(entries),'evidence hashes')
